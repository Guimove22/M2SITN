/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2go;

/**
 *
 * @author Zomb
 */
public class Personne {
    private String first_name;
    private String middle_name;
    private String last_name;
    private String gender;
    private String phone;
    private String email;
    private String street;
    private String city;
    private String pobox;
    private boolean contact;
    private int id;
    
    static int i=1;
    
    public Personne(String first_name, String middle_name, String last_name, String gender, String phone, String email, String street, String city, String pobox, boolean contact){
        this.first_name=first_name;
        this.middle_name=middle_name;
        this.last_name=last_name;
        this.gender=gender;
        this.phone=phone;
        this.email=email;
        this.street=street;
        this.city=city;
        this.pobox=pobox;
        this.contact=contact;
        id=i++;
    }

    public String getFirst_name() {
        return first_name;
    }

    public String getMiddle_name() {
        return middle_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public String getGender() {
        return gender;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getStreet() {
        return street;
    }

    public String getCity() {
        return city;
    }

    public String getPobox() {
        return pobox;
    }

    public boolean isContact() {
        return contact;
    }

    public int getId() {
        return id;
    }

    public static int getI() {
        return i;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public void setMiddle_name(String middle_name) {
        this.middle_name = middle_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setPobox(String pobox) {
        this.pobox = pobox;
    }

    public void setContact(boolean contact) {
        this.contact = contact;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static void setI(int i) {
        Personne.i = i;
    }
    
    
    
    
    
    
}
