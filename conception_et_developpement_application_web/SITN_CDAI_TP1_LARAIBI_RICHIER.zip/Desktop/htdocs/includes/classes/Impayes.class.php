<?php
class ImpayesAuto{
	// ATTRIBUTS
	protected $annee;
	protected $trimestre;
	protected $ID_Metier;
	protected $Metier;
	protected $nom_slug;
	protected $presentes;
	protected $payes;
	protected $impayes;
	

	//Metier
	//nom_slug
	//annee
	//trimestre
	//presentes
	//payes
	//impayes


public function __construct($tab=array()){
		if(!empty($tab)){
			foreach($tab as $key => $val)$tab["$key"]=htmlentities($val, ENT_QUOTES, "UTF-8");
			
			if(isset($tab["ID_Metier"])){$this->ID_Metier=$tab["ID_Metier"];}
			if(isset($tab["Metier"])){$this->Metier=$tab["Metier"];}
			if(isset($tab["nom_slug"])){$this->nom_slug=$tab["nom_slug"];}
			if(isset($tab["annee"])){$this->annee=$tab["annee"];}
			if(isset($tab["trimestre"])){$this->trimestre=$tab["trimestre"];}
			if(isset($tab["presentes"])){$this->presentes=$tab["presentes"];}
			if(isset($tab["payes"])){$this->payes=$tab["payes"];}
			if(isset($tab["impayes"])){$this->impayes=$tab["impayes"];}
			
			
		}
	}
	// METHODE LOAD DB
	public function load_db(){
		global $connexion;
		$req = "SELECT * FROM ImpayesGeneral WHERE ID_Metier=:ID_Metier AND Trimestre=:Trimestre AND Annee=:Annee";
		$requete = $connexion->prepare($req);
		$requete->execute(array("ID_Metier"=>$this->ID_Metier,"Trimestre"=>$this->Trimestre,"Annee"=>$this->Annee));
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$tab = $requete->fetch();
		if (empty($tab)) {return false;}
	
		$this->ID_Metier=$tab["ID_Metier"];
		$this->Metier=$tab["Metier"];
		$this->nom_slug=$tab["nom_slug"];
		$this->annee=$tab["annee"];
		$this->trimestre=$tab["trimestre"];
		$this->presentes=$tab["presentes"];
		$this->payes=$tab["payes"];
		$this->impayes=$tab["impayes"];
		$this->listeOffres=getListeOffresImpayes($this->Metier,$this->annee,$this->trimestre);

		return true;
	}


	// METHODE ADD DB
	public function add_db(){
		global $connexion;
		$req = "INSERT INTO ImpayesGeneral (ID_Metier,Metier,nom_slug,annee,trimestre,presentes,payes,impayes) VALUES (ID_Metier,Metier,nom_slug,annee,trimestre,presentes,payes,impayes)";
		$requete = $connexion->prepare($req);
		$tab=array("ID_Metier"=>$this->ID_Metier,"Metier"=>$this->Metier,"nom_slug"=>$this->nom_slug,"annee"=>$this->annee,"trimestre"=>$this->trimestre,"presentes"=>$this->presentes,"payes"=>$this->payes,"impayes"=>$this->impayes);
		if($requete->execute($tab)){
			$requete->CloseCursor();
			$this->ID_Metier=$connexion->lastInsertId();
			return $this->ID_Metier;
		}
		else
			return false;
	}
	
	// METHODE EDIT DB
	public function edit_db(){
		global $connexion;
		$req = "UPDATE ImpayesGeneral SET Metier=:Metier, nom_slug=:nom_slug WHERE ID_Metier=:ID_Metier";
		$requete = $connexion->prepare($req);
		$tab=array("ID_Metier"=>$this->ID_Metier,  "Metier"=>$this->Metier, "nom_slug"=>$this->nom_slug);
		if($requete->execute($tab)){
			$requete->CloseCursor();
			return true;
		}
		else
			return false;
	}
	
	// METHODE DELETE DB
	public function del_db(){
		global $connexion;
		$req = "DELETE FROM Filiales WHERE ID_Metier=:ID_Metier";
		$requete = $connexion->prepare($req);
		$tab=array("ID_Metier"=>$this->ID_Metier);
		if($requete->execute($tab)){
			$requete->CloseCursor();
			return true;
		}
		else
			return false;
	}
	
	// EDIT_OBJECT
	public function edit_object($tab=array()){
		if(!empty($tab)){
			foreach($tab as $key => $val)$tab["$key"]=htmlentities($val, ENT_QUOTES, "UTF-8");
			if(isset($tab["ID_Metier"]) && $tab["ID_Metier"] != ""){$this->ID_Metier=$tab["ID_Metier"];}
			if(isset($tab["Metier"]) && $tab["Metier"] != ""){$this->Metier=$tab["Metier"];}
			if(isset($tab["nom_slug"]) && $tab["nom_slug"] != ""){$this->nom_slug=$tab["nom_slug"];}
		}
	}

	// GETTERS
	//public function getID_Metier(){return html_entity_decode($this->ID_Metier);}
	
	public function getID_Metier(){return html_entity_decode($this->ID_Metier);}
	public function getmetier(){return html_entity_decode($this->Metier);}
	public function getnom_slug(){return html_entity_decode($this->nom_slug);}
	public function getannee(){return html_entity_decode($this->annee);}
	public function gettrimestre(){return html_entity_decode($this->trimestre);}
	public function getpresentes(){return html_entity_decode($this->presentes);}
	public function getpayes(){return html_entity_decode($this->payes);}
	public function getimpayes(){return html_entity_decode($this->impayes);}

	// SETTERS
	
	public function setID_Metier($a){$this->ID_Metier=($a);}
	public function setMetier($a){$this->Metier=($a);}
	public function setnom_slug($a){$this->nom_slug=($a);}
	public function setannee($a){$this->annee=($a);}
	public function settrimestre($a){$this->trimestre=($a);}
	public function setpresentes($a){$this->presentes=($a);}
	public function setpayes($a){$this->payes=($a);}
	public function setimpayes($a){$this->impayes=($a);}

	// INPUTS
	public function getID_MetierInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input type="hidden" name="ID" '.$attributs.' value="'.$this->ID.'" />';}
	public function getNomInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="Metier" '.$attributs.' value="'.$this->Metier.'" />';}
	public function getNomSlugInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="nom_slug" '.$attributs.' value="'.$this->nom_slug.'" />';}




}

?>
