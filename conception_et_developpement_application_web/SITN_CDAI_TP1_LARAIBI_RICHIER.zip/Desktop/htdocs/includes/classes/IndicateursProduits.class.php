<?php
class IndicateursProduitsAuto{
	// ATTRIBUTS


	protected $Filiale;
	protected $Produit;
	protected $ID_Produit;
	protected $Mois;
	protected $Annee;
	protected $ChiffresAffaires;
	protected $AffairesNouvelles;
	protected $SortieDeContrats;
	protected $ProductionNette;
	protected $Portefeuille;
	protected $SinistreSurPrime;
	protected $Source;	



	

	// CONSTRUCTEUR
	public function __construct($tab=array()){
		if(!empty($tab)){
			//foreach($tab as $key => $val)$tab["$key"]=htmlentities($val, ENT_QUOTES, "UTF-8");
			if(isset($tab["Filiale"])){$this->Filiale=$tab["Filiale"];}
			if(isset($tab["Produit"])){$this->Produit=$tab["Produit"];}
			if(isset($tab["ID_Produit"])){$this->ID_Produit=$tab["ID_Produit"];}
			if(isset($tab["Mois"])){$this->Mois=$tab["Mois"];}
			if(isset($tab["Annee"])){$this->Annee=$tab["Annee"];}
			if(isset($tab["ChiffresAffaires"])){$this->ChiffresAffaires=$tab["ChiffresAffaires"];}
			if(isset($tab["AffairesNouvelles"])){$this->AffairesNouvelles=$tab["AffairesNouvelles"];}
			if(isset($tab["SortieDeContrats"])){$this->SortieDeContrats=$tab["SortieDeContrats"];}
			if(isset($tab["ProductionNette"])){$this->ProductionNette=$tab["ProductionNette"];}
			if(isset($tab["Portefeuille"])){$this->Portefeuille=$tab["Portefeuille"];}
			if(isset($tab["SinistreSurPrime"])){$this->SinistreSurPrime=$tab["SinistreSurPrime"];}
			if(isset($tab["Source	"])){$this->Source	=$tab["Source	"];}
		}

	}

	//METHODE LOAD DB
	public function load_db(){
		global $connexion;
		//echo "ID_Produit ".$this->ID_Produit,"<br>annee ".$this->Annee,"<br>mois " .$this->Mois."<br>"	;
		$req = "SELECT * FROM IndicateursProduits WHERE ID_Produit=:ID_Produit AND Annee = :annee AND Mois = :mois";
		$requete = $connexion->prepare($req);
		$requete->execute(array("ID_Produit"=>$this->ID_Produit,"annee"=>$this->Annee,"mois" =>$this->Mois));
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$tab = $requete->fetch();
		if (empty($tab)) {echo "ErreurChargement IndicateursProduits <br>";return false;}
		
		$this->Filiale=$tab["Filiale"]; 				
		$this->Produit=$tab["Produit"]; 				
		$this->ID_Produit=$tab["ID_Produit"];
		$this->Mois=$tab["Mois"];					
		$this->Annee=$tab["Annee"];					
		$this->ChiffresAffaires=$tab["ChiffresAffaires"];
		$this->AffairesNouvelles=$tab["AffairesNouvelles"];
		$this->SortieDeContrats=$tab["SortieDeContrats"];
		$this->ProductionNette=$tab["ProductionNette"];
		$this->Portefeuille=$tab["Portefeuille"];
		$this->SinistreSurPrime=$tab["SinistreSurPrime"];
		$this->Source=$tab["Source"];

		return true;
	}
	
	// METHODE ADD DB
	public function add_db(){
		global $connexion;
		$req = "INSERT INTO IndicateursProduits (
							Filiale,
							Produit,
							ID_Produit,
							Mois,
							Annee,
							ChiffresAffaires,
							AffairesNouvelles,
							SortieDeContrats,
							ProductionNette,
							Portefeuille,
							SinistreSurPrime,
							Source
							)
							VALUES (
									:Filiale,
									:Produit,
									:ID_Produit,
									:Mois,
									:Annee,
									:ChiffresAffaires,
									:AffairesNouvelles,
									:SortieDeContrats,
									:ProductionNette,
									:Portefeuille,
									:SinistreSurPrime,
									:Source	)";
		$requete = $connexion->prepare($req);
		$tab=array(			"Filiale"=>$this->Filiale,
							"Produit"=>$this->Produit,
							"ID_Produit"=>$this->ID_Produit,
							"Mois"=>$this->Mois,
							"Annee"=>$this->Annee,
							"ChiffresAffaires"=>$this->ChiffresAffaires,
							"AffairesNouvelles"=>$this->AffairesNouvelles,
							"SortieDeContrats"=>$this->SortieDeContrats,			
							"ProductionNette"=>$this->ProductionNette,
							"Portefeuille"=>$this->Portefeuille,
							"SinistreSurPrime"=>$this->SinistreSurPrime,
							"Source	"=>$this->Source	,
							);
		if($requete->execute($tab)){
			$requete->CloseCursor();
			$this->ID_Produit=$connexion->lastInsertId();
			return $this->ID_Produit;
		}
		else
			return false;
	}
							
							
							
							
							
							
							
							
							
							
							
							

	// METHODE EDIT DB
	public function edit_db(){
		global $connexion;
		$req = "UPDATE IndicateursProduits SET
											Filiale=:Filiale,
											Produit=:Produit,
											ID_Produit=:ID_Produit,
											Mois=:Mois,
											Annee=:Annee,
											ChiffresAffaires=:ChiffresAffaires,
											AffairesNouvelles=:AffairesNouvelles,
											SortieDeContrats=:SortieDeContrats,
											ProductionNette=:ProductionNette,
											Portefeuille=:Portefeuille,
											SinistreSurPrime=:SinistreSurPrime,
											Source=:Source
											 WHERE ID_Produit=:ID_Produit AND Annee=:Annee AND Mois=:Mois";
		$requete = $connexion->prepare($req);
		$tab=array(			"ID_Produit"=>$this->ID_Produit,
							"Filiale"=>$this->Filiale,
							"Annee"=>$this->Annee,
							"Mois"=>$this->Mois,
							"ChiffresAffaires"=>$this->ChiffresAffaires,
							"CommissionsDeCourtage"=>$this->CommissionsDeCourtage,
							"ParticipationAuxBenefices"=>$this->ParticipationAuxBenefices,			
							"PrimesAcquises"=>$this->PrimesAcquises,
							"Sinistres"=>$this->Sinistres,
							"CommissionsApporteurs"=>$this->CommissionsApporteurs,
							"Reassurance"=>$this->Reassurance,
							"ResultatFinancier"=>$this->ResultatFinancier,
							"ProduitNetAssurance"=>$this->ProduitNetAssurance,
							"ProduitNetBancaire"=>$this->ProduitNetBancaire,
							"CoutDuRisque"=>$this->CoutDuRisque,
							"ResultatExploitation"=>$this->ResultatExploitation,
							"ResultatNet"=>$this->ResultatNet,
							"ResultatNetParDuGroupe"=>$this->ResultatNetParDuGroupe,
							"Charges"=>$this->Charges,
							"ResultatBrutExploitation"=>$this->ResultatBrutExploitation,			
							"CoefficientExploitation"=>$this->CoefficientExploitation,
							"Effectifs"=>$this->Effectifs,
							"MeeDeCNP"=>$this->MeeDeCNP,
							"RatioSinistresSurPrimes"=>$this->RatioSinistresSurPrimes,
							"RatioSsurPMoinsCumul"=>$this->RatioSsurPMoinsCumul,
							"Source"=>$this->Source);		if($requete->execute($tab)){
			$requete->CloseCursor();
			return true;
		}
		else
			return false;
	}
	
	// METHODE DELETE DB
	public function del_db(){
		global $connexion;
		$req = "DELETE FROM IndicateursProduits WHERE ID_Produit=:ID_Produit AND Annee=:Annee AND Mois=:Mois";
		$requete = $connexion->prepare($req);
		$tab=array("ID_Produit"=>$this->ID_Produit, "Annee"=>$this->Annee,"Mois"=>$this->Mois);
		if($requete->execute($tab)){
			$requete->CloseCursor();
			return true;
		}
		else
			return false;
	}
	
	// EDIT_OBJECT
	public function edit_object($tab=array()){
		if(!empty($tab)){
			foreach($tab as $key => $val)$tab["$key"]=htmlentities($val, ENT_QUOTES, "UTF-8");
			if(isset($tab["Filiale"]) && $tab["Filiale"]!= ""){$this->Filiale=$tab["Filiale"];}
			if(isset($tab["Produit"]) && $tab["Produit"]!= ""){$this->Produit=$tab["Produit"];}
			if(isset($tab["ID_Produit"]) && $tab["ID_Produit"]!= ""){$this->ID_Produit=$tab["ID_Produit"];}
			if(isset($tab["Mois"]) && $tab["Mois"]!= ""){$this->Mois=$tab["Mois"];}
			if(isset($tab["Annee"]) && $tab["Annee"]!= ""){$this->Annee=$tab["Annee"];}
			if(isset($tab["ChiffresAffaires"]) && $tab["ChiffresAffaires"]!= ""){$this->ChiffresAffaires=$tab["ChiffresAffaires"];}
			if(isset($tab["AffairesNouvelles"]) && $tab["AffairesNouvelles"]!= ""){$this->AffairesNouvelles=$tab["AffairesNouvelles"];}
			if(isset($tab["SortieDeContrats"]) && $tab["SortieDeContrats"]!= ""){$this->SortieDeContrats=$tab["SortieDeContrats"];}
			if(isset($tab["ProductionNette"]) && $tab["ProductionNette"]!= ""){$this->ProductionNette=$tab["ProductionNette"];}
			if(isset($tab["Portefeuille"]) && $tab["Portefeuille"]!= ""){$this->Portefeuille=$tab["Portefeuille"];}
			if(isset($tab["SinistreSurPrime"]) && $tab["SinistreSurPrime"]!= ""){$this->SinistreSurPrime=$tab["SinistreSurPrime"];}
			if(isset($tab["Source"]) && $tab["Source"]!= ""){$this->Source=$tab["Source"];}
		}
	}

	// GETTERS
	public function getFiliale(){return html_entity_decode($this->Filiale);}
	public function getProduit(){return html_entity_decode($this->Produit);}
	public function getID_Produit(){return html_entity_decode($this->ID_Produit);}
	public function getMois(){return html_entity_decode($this->Mois);}
	public function getAnnee(){return html_entity_decode($this->Annee);}
	public function getChiffresAffaires(){return html_entity_decode($this->ChiffresAffaires);}
	public function getAffairesNouvelles(){return html_entity_decode($this->AffairesNouvelles);}
	public function getSortieDeContrats(){return html_entity_decode($this->SortieDeContrats);}
	public function getProductionNette(){return html_entity_decode($this->ProductionNette);}
	public function getPortefeuille(){return html_entity_decode($this->Portefeuille);}
	public function getSinistreSurPrime(){return html_entity_decode($this->SinistreSurPrime);}
	public function getSource(){return html_entity_decode($this->Source);}	
	

	// SETTERS
	public function setFiliale($a){$this->Filiale=($a);}
	public function setProduit($a){$this->Produit=($a);}
	public function setID_Produit($a){$this->ID_Produit=($a);}
	public function setMois($a){$this->Mois=($a);}
	public function setAnnee($a){$this->Annee=($a);}
	public function setChiffresAffaires($a){$this->ChiffresAffaires=($a);}
	public function setAffairesNouvelles($a){$this->AffairesNouvelles=($a);}
	public function setSortieDeContrats($a){$this->SortieDeContrats=($a);}
	public function setProductionNette($a){$this->ProductionNette=($a);}
	public function setPortefeuille($a){$this->Portefeuille=($a);}
	public function setSinistreSurPrime($a){$this->SinistreSurPrime=($a);}
	public function setSource($a){$this->Source=($a);}	
	
	

	// INPUTS
	public function getIdInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input type="hidden" name="ID_Produit" '.$attributs.' value="'.$this->ID_Produit.'" />';}
	public function getIdOptionInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="id_option" '.$attributs.' value="'.$this->id_option.'" />';}
	public function getDescriptionInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="Description" '.$attributs.' value="'.$this->Description.'" />';}
	public function getEnStockInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="en_stock" '.$attributs.' value="'.$this->en_stock.'" />';}
	public function getPrixInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="prix" '.$attributs.' value="'.$this->prix.'" />';}
	public function getUniteInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="unite" '.$attributs.' value="'.$this->unite.'" />';}
}
?>