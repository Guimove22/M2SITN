<?php
class FilialeAuto{
	// ATTRIBUTS

	protected $ID; // PRIMARY KEY;
	protected $Nom;
	protected $nom_slug;
	
	
	// CONSTRUCTEUR
	public function __construct($tab=array()){
		if(!empty($tab)){
			foreach($tab as $key => $val)$tab["$key"]=htmlentities($val, ENT_QUOTES, "UTF-8");
			if(isset($tab["ID_Filiale"])){$this->ID=$tab["ID_Filiale"];}
			if(isset($tab["Nom"])){$this->Nom=$tab["Nom"];}
			if(isset($tab["nom_slug"])){$this->nom_slug=$tab["nom_slug"];}
			
		}
	}

	// METHODE LOAD DB
	public function load_db(){
		global $connexion;
		$req = "SELECT * FROM Filiales WHERE ID_Filiale=:ID";
		$requete = $connexion->prepare($req);
		$requete->execute(array("ID"=>$this->ID));
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$tab = $requete->fetch();
		if (empty($tab)) {return false;}
		$this->ID=$tab["ID_Filiale"];
		$this->Nom=$tab["Nom"];
		$this->nom_slug=$tab["nom_slug"];
		return true;
	}
	
	// METHODE ADD DB
	public function add_db(){
		global $connexion;
		$req = "INSERT INTO Filiales (ID, , Nom, nom_slug) VALUES (:ID,  :Nom, :nom_slug)";
		$requete = $connexion->prepare($req);
		$tab=array("ID"=>$this->ID,  "Nom"=>$this->Nom, "nom_slug"=>$this->nom_slug);
		if($requete->execute($tab)){
			$requete->CloseCursor();
			$this->ID=$connexion->lastInsertId();
			return $this->ID;
		}
		else
			return false;
	}
	
	// METHODE EDIT DB
	public function edit_db(){
		global $connexion;
		$req = "UPDATE Filiales SET Nom=:Nom, nom_slug=:nom_slug WHERE ID=:ID";
		$requete = $connexion->prepare($req);
		$tab=array("ID"=>$this->ID,  "Nom"=>$this->Nom, "nom_slug"=>$this->nom_slug);
		if($requete->execute($tab)){
			$requete->CloseCursor();
			return true;
		}
		else
			return false;
	}
	
	// METHODE DELETE DB
	public function del_db(){
		global $connexion;
		$req = "DELETE FROM Filiales WHERE ID=:ID";
		$requete = $connexion->prepare($req);
		$tab=array("ID"=>$this->ID);
		if($requete->execute($tab)){
			$requete->CloseCursor();
			return true;
		}
		else
			return false;
	}
	
	// EDIT_OBJECT
	public function edit_object($tab=array()){
		if(!empty($tab)){
			foreach($tab as $key => $val)$tab["$key"]=htmlentities($val, ENT_QUOTES, "UTF-8");
			if(isset($tab["ID"]) && $tab["ID"] != ""){$this->ID=$tab["ID"];}
			if(isset($tab["Nom"]) && $tab["Nom"] != ""){$this->Nom=$tab["Nom"];}
			if(isset($tab["nom_slug"]) && $tab["nom_slug"] != ""){$this->nom_slug=$tab["nom_slug"];}
		}
	}

	// GETTERS
	//public function getID(){return html_entity_decode($this->ID);}
	public function getID(){return html_entity_decode($this->ID);}
	public function getNom(){return html_entity_decode($this->Nom);}
	public function getNomSlug(){return html_entity_decode($this->nom_slug);}

	// SETTERS
	public function setID($a){$this->ID=($a);}
	public function setNom($a){$this->Nom=($a);}
	public function setNomSlug($a){$this->nom_slug=($a);}

	// INPUTS
	public function getIDInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input type="hidden" name="ID" '.$attributs.' value="'.$this->ID.'" />';}
	public function getNomInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="Nom" '.$attributs.' value="'.$this->Nom.'" />';}
	public function getNomSlugInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="nom_slug" '.$attributs.' value="'.$this->nom_slug.'" />';}

}
?>