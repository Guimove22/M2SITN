<?php

class Impayes extends ImpayesAuto
{  
	public function __construct($tab=array()) 
	{
    	parent::__construct($tab);
	}

	


}

?>