<?php

class IndicateursProduits extends IndicateursProduitsAuto
{  
	public function __construct($tab=array()) 
	{
    	parent::__construct($tab);
	}


	public function getListeIndicateursComplet(){

		$tab= array('Filiale',
					'Produit',
					'ID_Produit',
					'Mois',
					'Annee',
					'ChiffresAffaires',
					'AffairesNouvelles',
					'SortieDeContrats',
					'ProductionNette',
					'Portefeuille',
					'SinistreSurPrime',
					'Source');

		return $tab;
	}

	public function getListeIndicateurs(){

		$tab= array('Produit',
					'ChiffresAffaires',
					'AffairesNouvelles',
					'SortieDeContrats',
					'ProductionNette',
					'Portefeuille',
					'SinistreSurPrime',
					'Source');

		return $tab;
	}

	public function getIndic($ind){

		return $this->$ind;
	}
	
}
?>