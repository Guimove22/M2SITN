<?php

class Filiale extends FilialeAuto
{  
	public function __construct($tab=array()) 
	{
    	parent::__construct($tab);
	}

	// OVERIDE METHODE LOAD DB
	public function load_db(){
		global $connexion;
		if($this->nom_slug != "")
		{
			$req = "SELECT * FROM Filiales WHERE nom_slug=:nom_slug";
			$requete = $connexion->prepare($req);
			$requete->execute(array("nom_slug"=>$this->nom_slug));
		}
		else
		{	

			$req = "SELECT * FROM Filiales WHERE ID_Filiale=:ID";
			$requete = $connexion->prepare($req);
			//echo "ID :  ".$this->ID."     :";
			$requete->execute(array("ID"=>$this->ID));
		}
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$tab = $requete->fetch();

		if (empty($tab)){ return false;}
		$this->ID=$tab["ID_Filiale"];
		$this->Nom=$tab["Nom"];
		$this->nom_slug=$tab["nom_slug"]; 
		return true;
	}


	public function getIndicateursFiliales($annee,$mois){
		global $connexion;
		
		
		$req = "SELECT * FROM IndicateursFiliales WHERE ID_Filiale = :ID AND Annee = :annee AND Mois = :mois ";
		
		$requete = $connexion->prepare($req);
		$requete->execute(array('ID'=>$this->getID(),'annee'=>$annee,'mois'=>$mois));
		$tab = $requete->fetchAll();

		//var_dump($tab);

		$return=new IndicateursFiliales($tab);
		
		
		return $return;
	
	}



	public function getListeProduits($annee,$mois){
		global $connexion;
		
		
		$req = "SELECT ID_produit, Produit FROM IndicateursProduits WHERE  Filiale = :Filiale AND Annee = :annee AND Mois = :mois ";
			
		
		$requete = $connexion->prepare($req);
		$requete->execute(array('Filiale'=>$this->getNom(),'annee'=>$annee,'mois'=>$mois));
		

		
		while($tab = $requete->fetch()){
			$return[]=$tab;
		}
		
		if (isset($return)){
			return $return;
		}else{
			return "-";
		}
	
	}



	public function tableauRecap($annee,$mois){	
		//echo $annee.$mois.$this->getID();;

		//Annee N
		$config=array("ID_Filiale"=>$this->getID(),"Annee"=>$annee,"Mois"=>$mois);
		$Indic = new IndicateursFiliales($config);
		$Indic->load_db();

		////Annee N-1
		$configN=array("ID_Filiale"=>$this->getID(),"Annee"=>($annee-1),"Mois"=>$mois);
		$IndicN = new IndicateursFiliales($configN);
		$IndicN->load_db();

		////Annee Budget
		$configBudget=array("ID_Filiale"=>$this->getID(),"Annee"=>($annee-1000),"Mois"=>$mois);
		$IndicBudget = new IndicateursFiliales($configBudget);
		$IndicBudget->load_db();
		//*/
		$anneeNmoins1=$annee-1;

		$tab= '<table class="table table-bordered table-hover table-striped">

		      <thead>
		        <tr>
		          <th>'.$this->getNom().'</th>
		          <th>'.$mois.'/'.$annee.'</th>
		          <th>'.$mois.'/'.$anneeNmoins1.'</th>
		          <th> Budget '.$annee.'</th>
		        </tr>
		      </thead>

		      <tbody>
		        <tr>
		          <td>Chiffres d\'Affaires <small>(en M€)</small></td>
		          <td class="eurosAdroite">'.$Indic->getChiffresAffaires().' €</td>
		          <td class="eurosAdroite">'.$IndicN->getChiffresAffaires().' €</td>
		          <td class="eurosAdroite">'.$IndicBudget->getChiffresAffaires().' €</td>
		        </tr>
		        
   		        '. /*<tr>
   		        		          <td>S/P</td>
   		        		          <td class="eurosAdroite">'.$Indic->getRatioSinistresSurPrimes().'</td>
   		        		          <td class="eurosAdroite">'.$IndicN->getRatioSinistresSurPrimes().'</td>
   		        		          <td class="eurosAdroite">'.$IndicBudget->getRatioSinistresSurPrimes().'</td>
   		        		        </tr>'//

   		        <tr>
		          <td>Résultat Net</td>
		          <td class="eurosAdroite">'.$Indic->getResultatNet().'</td>
		          <td class="eurosAdroite">'.$IndicN->getResultatNet().'</td>
		          <td class="eurosAdroite">'.$IndicBudget->getResultatNet().'</td>
		        </tr>//*/

		        ' <tr>
		          <td>Affaires Nouvelles</td>
		          <td class="eurosAdroite">'.$Indic->getAffairesNouvelles().'</td>
		          <td class="eurosAdroite">'.$IndicN->getAffairesNouvelles().'</td>
		          <td class="eurosAdroite">'.$IndicBudget->getAffairesNouvelles().'</td>
		        </tr>

   		        <tr>
		          <td>Sorties de Contrats</td>
		          <td class="eurosAdroite">'.$Indic->getSortiesDeContrats().'</td>
		          <td class="eurosAdroite">'.$IndicN->getSortiesDeContrats().'</td>
		          <td class="eurosAdroite">'.$IndicBudget->getSortiesDeContrats().'</td>
		        </tr>

   		        <tr>
		          <td>Production Nette</td>
		          <td class="eurosAdroite">'.$Indic->getProductionNette().'</td>
		          <td class="eurosAdroite">'.$IndicN->getProductionNette().'</td>
		          <td class="eurosAdroite">'.$IndicBudget->getProductionNette().'</td>
		        </tr>

   		        <tr>
		          <td>Portefeuille</td>
		          <td class="eurosAdroite">'.$Indic->getPortefeuille().'</td>
		          <td class="eurosAdroite">'.$IndicN->getPortefeuille().'</td>
		          <td class="eurosAdroite">'.$IndicBudget->getPortefeuille().'</td>
		        </tr>

   		       

   		       
		      </tbody>
		 
  
		</table>';
		//echo '#';
		//var_dump($Indic->getPortefeuille());
		
		//echo '#';

   return $tab;
	}












	public function getListeOptions(){
		global $connexion;
		
		$req = "SELECT * FROM boiscab_options WHERE ID_produit=:IDproduit ORDER BY Nom";
		$requete = $connexion->prepare($req);
		$requete->execute(array("IDproduit"=>$this->ID));
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$return=array(); 
		while($tab = $requete->fetch()){
			$return[]=new Option($tab);
		}
		return $return;
	
	}
	
	public function getPathToImageFolder(){
		return Site::getPathSite().'/dev/img/produits'.$this->getUrl();
	}
	
	public function getImagesSrc(){
		$return = array();
		$tab = array_diff(scandir($this->getPathToImageFolder()), array('..', '.', '.DS_Store'));
		foreach($tab as $path){
			//$temp = split('/dev', $path);
			$return[] = '/img/produits'.$this->getUrl().'/'.$path;
		}
		return $return;
	}
	
	public function hasImage(){ 
		return sizeof($this->getImagesSrc())==0?false:true;
	}

	public function getUrl(){
		
		$scat = new SousCategorie(array("ID"=>$this->Id_Sous_Categorie));
		$scat->load_db();
		$cat = new Categorie(array("ID"=>$scat->getIDCategorie()));
		$cat->load_db();
		return "/".$cat->getNomSlug()."/".$scat->getNomSlug()."/".$this->getNomSlug();
	}
}

?>