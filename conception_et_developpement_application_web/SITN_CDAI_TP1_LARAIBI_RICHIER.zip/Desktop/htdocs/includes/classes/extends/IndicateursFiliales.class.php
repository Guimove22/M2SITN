<?php

class IndicateursFiliales extends IndicateursFilialesAuto
{  
	public function __construct($tab=array()) 
	{
    	parent::__construct($tab);
	}
	public function getResultatNet(){

		return number_format((double)html_entity_decode($this->ResultatNet),0,',',' ').'€';

	}


	public function getRatioSinistresSurPrimes(){
		if (($this->ID_Filiale == 1) ||  ($this->ID_Filiale == 3)|| ($this->ID_Filiale == 4)|| ($this->ID_Filiale == 5) ) {
			return html_entity_decode($this->RatioSinistresSurPrimes);
		}else{
			global $connexion;
			$req = "SELECT  Sinistres/PrimesAcquises AS `SP` FROM  IndicateursFiliales WHERE ID_Filiale=:ID_Filiale AND Annee=:Annee AND MOIS=:Mois GROUP BY Filiale";
			
			$requete = $connexion->prepare($req);
			$tab=array("ID_Filiale"=>$this->ID_Filiale, "Annee"=>$this->Annee,"Mois"=>$this->Mois);
			
			$res=array();
			if($requete->execute($tab)){
				
				$res=$requete->fetchAll();
			}

			if($res){
				
				//return $res[0]["SP"];
				return number_format($res[0]["SP"]*100,1,',',' ').'%';
			}else{
				return "-";
			}
			

		}
	
	}
	
	

	public function getChiffresAffaires(){
		$resultat="";
		if (($this->ID_Filiale == 2)||(($this->ID_Filiale == 3)&&($this->Annee<2014))) {

			global $connexion;
			$req = "SELECT  SUM(ChiffresAffaires) AS`CA` FROM  IndicateursProduits Join Filiales on Filiales.Nom = IndicateursProduits.Filiale WHERE ID_Filiale=:ID_Filiale AND Annee=:Annee AND MOIS=:Mois GROUP BY Filiale";
			
			$requete = $connexion->prepare($req);
			$tab=array("ID_Filiale"=>$this->ID_Filiale, "Annee"=>$this->Annee,"Mois"=>$this->Mois);
			
			$res=array();
			if($requete->execute($tab)){
				
				$res=$requete->fetchAll();
			}

			
			if($res){
				$resultat = $res[0]["CA"];
			}else{
				$resultat = "-";
			}
			
		}else{
			$resultat = html_entity_decode($this->ChiffresAffaires);
		}
			$id=$this->ID_Filiale;
			$unite=1;
			$round=0;
			switch ($id) {
			    case 1:
			        $unite=1000000;
			        $round=1;
			        break;
			    case 2:
			        $unite=1;
			        $round=0;
			        break;
			    case 3:
			        ;
			        break;
			    case 4:
			        $unite=1;
			        break;
			    case 5:
			        $unite=1;
			        break;
			}

			return number_format($resultat/$unite,$round,',','.');

	}

	public function getAffairesNouvelles(){
		global $connexion;
		$req = "SELECT  SUM(AffairesNouvelles) AS`AffNouv` FROM  IndicateursProduits Join Filiales on Filiales.Nom = IndicateursProduits.Filiale WHERE ID_Filiale=:ID_Filiale AND Annee=:Annee AND MOIS=:Mois GROUP BY Filiale";
		
		$requete = $connexion->prepare($req);
		$tab=array("ID_Filiale"=>$this->ID_Filiale, "Annee"=>$this->Annee,"Mois"=>$this->Mois);
			
		$res=array();
		if($requete->execute($tab)){
			
			$res=$requete->fetchAll();
		}

		if($res){
			$id=$this->ID_Filiale;
			$unite=1;
			$round=0	;
			switch ($id) {
			    case 1:
			        $unite=1;
			        $round=0;
			        break;
			    case 2:
			        $unite=1;
			        $round=0;
			        break;
			    case 3:
			        $unite=1;
			        break;
			    case 4:
			        $unite=1;
			        break;
			    case 5:
			        $unite=1;
			        break;
			}

			//return $res[0]["AffNouv"];
			
			return number_format($res[0]["AffNouv"]/$unite,$round,',','.');
			
		}
		else{
			return  "-";
		}
		
	}

	public function getSortiesDeContrats(){
		global $connexion;
		$req = "SELECT  SUM(SortieDeContrats) AS`SortieContrats` FROM  IndicateursProduits Join Filiales on Filiales.Nom = IndicateursProduits.Filiale WHERE ID_Filiale=:ID_Filiale AND Annee=:Annee AND MOIS=:Mois GROUP BY Filiale";
		
		$requete = $connexion->prepare($req);
		$tab=array("ID_Filiale"=>$this->ID_Filiale, "Annee"=>$this->Annee,"Mois"=>$this->Mois);
		
		$res=array();
		if($requete->execute($tab)){
			
			$res=$requete->fetchAll();
		}

		
		if($res){
			$id=$this->ID_Filiale;
			$unite=1;
			$round=0	;
			switch ($id) {
			    case 1:
			        $unite=1;
			        $round=0;
			        break;
			    case 2:
			        $unite=1;
			        $round=0;
			        break;
			    case 3:
			        $unite=1;
			        break;
			    case 4:
			        $unite=1;
			        break;
			    case 5:
			        $unite=1;
			        break;
			}

			//return $res[0]["AffNouv"];
			
			return number_format($res[0]["SortieContrats"]/$unite,$round,',','.');

		}else{
			return '-';
		}
		
	}

	public function getProductionNette(){
		global $connexion;
		$req = "SELECT  SUM(ProductionNette) AS`ProdNette` FROM  IndicateursProduits Join Filiales on Filiales.Nom = IndicateursProduits.Filiale WHERE ID_Filiale=:ID_Filiale AND Annee=:Annee AND MOIS=:Mois GROUP BY Filiale";
		
		$requete = $connexion->prepare($req);
		$tab=array("ID_Filiale"=>$this->ID_Filiale, "Annee"=>$this->Annee,"Mois"=>$this->Mois);
		
		$res=array();
		if($requete->execute($tab)){
			
			$res=$requete->fetchAll();
		}

		
		if($res){
			$id=$this->ID_Filiale;
			$unite=1;
			$round=0	;
			switch ($id) {
			    case 1:
			        $unite=1;
			        $round=0;
			        break;
			    case 2:
			        $unite=1;
			        $round=0;
			        break;
			    case 3:
			        $unite=1;
			        break;
			    case 4:
			        $unite=1;
			        break;
			    case 5:
			        $unite=1;
			        break;
			}

			//return $res[0]["AffNouv"];
			
			return number_format($res[0]["ProdNette"]/$unite,$round,',','.');
			
		}else{
			return  "-";
		}
		
	}

	public function getPortefeuille(){
		global $connexion;
		$req = "SELECT  SUM(Portefeuille) AS`Pu` FROM  IndicateursProduits Join Filiales on Filiales.Nom = IndicateursProduits.Filiale WHERE ID_Filiale=:ID_Filiale AND Annee=:Annee AND MOIS=:Mois GROUP BY Filiale";
		
		$requete = $connexion->prepare($req);
		$tab=array("ID_Filiale"=>$this->ID_Filiale, "Annee"=>$this->Annee,"Mois"=>$this->Mois);
		
		$res=array();
		if($requete->execute($tab)){
			
			$res=$requete->fetchAll();
		}

		if($res){
			$id=$this->ID_Filiale;
			$unite=1;
			$round=0;
			switch ($id) {
			    case 1:
			        $unite=1;
			        $round=0;
			        break;
			    case 2:
			        $unite=1;
			        $round=0;
			        break;
			    case 3:
			        $unite=1;
			        break;
			    case 4:
			        $unite=1;
			        break;
			    case 5:
			        $unite=1;
			        break;
			}

			//return $res[0]["AffNouv"];
			
			return number_format($res[0]["Pu"]/$unite,$round,',','.');
			return $res[0];
		}else{
			return "-";
		}

		
	}


}

?>