<?php 
class OperationsImpayes{
	// ATTRIBUTS
	protected $Annee;
	protected $Trimestre;
	protected $ID_Metier;
	protected $Metier;
	protected $ID_Offre;
	protected $Offre;
	protected $Operation;
	protected $Nombre;
	protected $PourcentageNombre;
	protected $Montant;
	protected $PourcentageMontant;

	public function __construct($tab=array()){
		if(!empty($tab)){
			foreach($tab as $key => $val)$tab["$key"]=htmlentities($val, ENT_QUOTES, "UTF-8");
			if(isset($tab["Offre"])){$this->Offre=$tab["Offre"];}
			if(isset($tab["Metier"])){$this->Metier=$tab["Metier"];}
			if(isset($tab["annee"])){$this->annee=$tab["annee"];}
			if(isset($tab["trimestre"])){$this->trimestre=$tab["trimestre"];}
			
		}
	}

	public function getListeOperations(){

		global $connexion;
		$req = "SELECT * FROM ImpayesOperations WHERE ID_Metier=:ID_Metier AND Trimestre=:Trimestre AND Annee=:Annee";
		$requete = $connexion->prepare($req);
		
		$requete->execute(array("ID_Metier"=>$this->ID_Metier,"Trimestre"=>$this->Trimestre,"Annee"=>$this->Annee));
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$tab = $requete->fetch();
		if (empty($tab)) {return false;}
	}


}
?>