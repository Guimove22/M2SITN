<?php
class offreImpayes{
	// ATTRIBUTS

	protected $ID; // PRIMARY KEY;
	protected $Nom;
	protected $nom_slug;

	protected $Offre;
	protected $Metier;
	protected $Annee;
	protected $Trimestre;

	public function __construct($tab=array()){
		if(!empty($tab)){
			foreach($tab as $key => $val)$tab["$key"]=htmlentities($val, ENT_QUOTES, "UTF-8");
			if(isset($tab["Offre"])){$this->Offre=$tab["Offre"];}
			if(isset($tab["Metier"])){$this->Metier=$tab["Metier"];}
			if(isset($tab["Annee"])){$this->Annee=$tab["Annee"];}
			if(isset($tab["Trimestre"])){$this->Trimestre=$tab["Trimestre"];}
			
		}
	}

	public function getListeOperations(){

		global $connexion;
		$req = "SELECT Offre,Operation,Nombre,PourcentageNombre,Montant,PourcentageMontant FROM ImpayesOperations WHERE Metier=:Metier AND Trimestre=:Trimestre AND Annee=:Annee And Offre=:Offre";
		$requete = $connexion->prepare($req);
		
		$requete->execute(array("Metier"=>$this->Metier,"Trimestre"=>$this->Trimestre,"Annee"=>$this->Annee,"Offre"=>$this->Offre));
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$return="";

		while($tab = $requete->fetch()){
			if (!empty($tab))
				$return[]=$tab;
		}
		
		return $return;
	}


}
	