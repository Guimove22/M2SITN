<?php
class IndicateursFilialesAuto{
	// ATTRIBUTS
	protected $ID_Filiale; 								// PRIMARY KEY;
	protected $Filiale;
	protected $Annee;									// PRIMARY KEY;
	protected $Mois;									// PRIMARY KEY;
	protected $ChiffresAffaires;
	protected $CommissionsDeCourtage;
	protected $ParticipationAuxBenefices;
	protected $PrimesAcquises;
	protected $Sinistres;
	protected $CommissionsApporteurs;
	protected $Reassurance;
	protected $ResultatFinancier;
	protected $ProduitNetAssurance;
	protected $ProduitNetBancaire;
	protected $CoutDuRisque;
	protected $ResultatExploitation;
	protected $ResultatNet;
	protected $ResultatNetParDuGroupe;
	protected $Charges;
	protected $ResultatBrutExploitation;
	protected $CoefficientExploitation;
	protected $Effectifs;
	protected $MeeDeCNP;
	protected $RatioSinistresSurPrimes;
	protected $RatioSsurPMoinsCumul;
	protected $Source;
	
	// CONSTRUCTEUR
	public function __construct($tab=array()){
		if(!empty($tab)){
			//foreach($tab as $key => $val)$tab["$key"]=htmlentities($val, ENT_QUOTES, "UTF-8");
			if(isset($tab["ID_Filiale"])){$this->ID_Filiale=$tab["ID_Filiale"];}
			if(isset($tab["Filiale"])){$this->Filiale=$tab["Filiale"];}
			if(isset($tab["Annee"])){$this->Annee=$tab["Annee"];}
			if(isset($tab["Mois"])){$this->Mois=$tab["Mois"];}
			if(isset($tab["ChiffresAffaires"])){$this->ChiffresAffaires=$tab["ChiffresAffaires"];}
			if(isset($tab["CommissionsDeCourtage"])){$this->CommissionsDeCourtage=$tab["CommissionsDeCourtage"];}
			if(isset($tab["ParticipationAuxBenefices"])){$this->ParticipationAuxBenefices=$tab["ParticipationAuxBenefices"];}
			if(isset($tab["PrimesAcquises"])){$this->PrimesAcquises=$tab["PrimesAcquises"];}
			if(isset($tab["Sinistres"])){$this->Sinistres=$tab["Sinistres"];}
			if(isset($tab["CommissionsApporteurs"])){$this->CommissionsApporteurs=$tab["CommissionsApporteurs"];}
			if(isset($tab["Reassurance"])){$this->Reassurance=$tab["Reassurance"];}
			if(isset($tab["ResultatFinancier"])){$this->ResultatFinancier=$tab["ResultatFinancier"];}
			if(isset($tab["ProduitNetAssurance"])){$this->ProduitNetAssurance=$tab["ProduitNetAssurance"];}
			if(isset($tab["ProduitNetBancaire"])){$this->ProduitNetBancaire=$tab["ProduitNetBancaire"];}
			if(isset($tab["CoutDuRisque"])){$this->CoutDuRisque=$tab["CoutDuRisque"];}
			if(isset($tab["ResultatExploitation"])){$this->ResultatExploitation=$tab["ResultatExploitation"];}
			if(isset($tab["ResultatNet"])){$this->ResultatNet=$tab["ResultatNet"];}
			if(isset($tab["ResultatNetParDuGroupe"])){$this->ResultatNetParDuGroupe=$tab["ResultatNetParDuGroupe"];}
			if(isset($tab["Charges"])){$this->Charges=$tab["Charges"];}
			if(isset($tab["ResultatBrutExploitation"])){$this->ResultatBrutExploitation=$tab["ResultatBrutExploitation"];}
			if(isset($tab["CoefficientExploitation"])){$this->CoefficientExploitation=$tab["CoefficientExploitation"];}
			if(isset($tab["Effectifs"])){$this->Effectifs=$tab["Effectifs"];}
			if(isset($tab["MeeDeCNP"])){$this->MeeDeCNP=$tab["MeeDeCNP"];}
			if(isset($tab["RatioSinistresSurPrimes"])){$this->RatioSinistresSurPrimes=$tab["RatioSinistresSurPrimes"];}
			if(isset($tab["RatioSsurPMoinsCumul"])){$this->RatioSsurPMoinsCumul=$tab["RatioSsurPMoinsCumul"];}
			if(isset($tab["Source"])){$this->Source=$tab["Source"];}
		}
	}

	//METHODE LOAD DB
	public function load_db(){
		global $connexion;
		//echo "<br>ID_Filiale : ".$this->ID_Filiale,"<br>annee : ".$this->Annee,"<br>mois" .$this->Mois."<br>"	;
		$req = "SELECT * FROM IndicateursFiliales WHERE ID_Filiale=:ID_Filiale AND Annee = :annee AND Mois = :mois";
		$requete = $connexion->prepare($req);
		$requete->execute(array("ID_Filiale"=>$this->ID_Filiale,"annee"=>$this->Annee,"mois" =>$this->Mois));
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$tab = $requete->fetch();
		if (empty($tab)) {
			if ($this->Annee > 2000){
				echo "Les données ".$this->Filiale." du ".$this->Mois."/".$this->Annee." sont indisponibles<br>";return false;
			}else{
				echo "Les données ".$this->Filiale." du budget ".$this->Mois."/".($this->Annee+1000)." sont indisponibles<br>";return false;

			}
		}
		

		$this->ID_Filiale=tofloat($tab["ID_Filiale"]); 				
		$this->Filiale=tofloat($tab["Filiale"]);
		$this->Annee=tofloat($tab["Annee"]);					
		$this->Mois=tofloat($tab["Mois"]);					
		
		if(($this->ID_Filiale==1)||($this->ID_Filiale==4)) {
			$this->ChiffresAffaires=tofloat($tab["ChiffresAffaires"])*1000000;
		}else{
			$this->ChiffresAffaires=tofloat($tab["ChiffresAffaires"]);
		}
		
		$this->CommissionsDeCourtage=tofloat($tab["CommissionsDeCourtage"]);
		$this->ParticipationAuxBenefices=tofloat($tab["ParticipationAuxBenefices"]);
		$this->PrimesAcquises=tofloat($tab["PrimesAcquises"]);
		$this->Sinistres=tofloat($tab["Sinistres"]);
		$this->CommissionsApporteurs=tofloat($tab["CommissionsApporteurs"]);
		$this->Reassurance=tofloat($tab["Reassurance"]);
		$this->ResultatFinancier=tofloat($tab["ResultatFinancier"]);
		$this->ProduitNetAssurance=tofloat($tab["ProduitNetAssurance"]);
		$this->ProduitNetBancaire=tofloat($tab["ProduitNetBancaire"]);
		$this->CoutDuRisque=tofloat($tab["CoutDuRisque"]);
		$this->ResultatExploitation=tofloat($tab["ResultatExploitation"]);
		$this->ResultatNet=tofloat($tab["ResultatNet"]);
		$this->ResultatNetParDuGroupe=tofloat($tab["ResultatNetParDuGroupe"]);
		$this->Charges=tofloat($tab["Charges"]);
		$this->ResultatBrutExploitation=tofloat($tab["ResultatBrutExploitation"]);
		$this->CoefficientExploitation=tofloat($tab["CoefficientExploitation"]);
		$this->Effectifs=tofloat($tab["Effectifs"]);
		$this->MeeDeCNP=tofloat($tab["MeeDeCNP"]);
		$this->RatioSinistresSurPrimes=tofloat($tab["RatioSinistresSurPrimes"]);
		$this->RatioSsurPMoinsCumul=tofloat($tab["RatioSsurPMoinsCumul"]);
		$this->Source=tofloat($tab["Source"]);
		return true;
	}
	
	// METHODE ADD DB
	public function add_db(){
		global $connexion;
		$req = "INSERT INTO IndicateursFiliales (
							ID_Filiale, 				
							Filiale,
							Annee,					
							Mois,					
							ChiffresAffaires,
							CommissionsDeCourtage,
							ParticipationAuxBenefices,			
							PrimesAcquises,
							Sinistres,
							CommissionsApporteurs,
							Reassurance,
							ResultatFinancier,
							ProduitNetAssurance,
							ProduitNetBancaire,
							CoutDuRisque,
							ResultatExploitation,
							ResultatNet,
							ResultatNetParDuGroupe,
							Charges,
							ResultatBrutExploitation,			
							CoefficientExploitation,
							Effectifs,
							MeeDeCNP,
							RatioSinistresSurPrimes,
							RatioSsurPMoinsCumul,
							Source
							)
							VALUES (
									:ID_Filiale, 				
									:Filiale,
									:Annee,					
									:Mois,					
									:ChiffresAffaires,
									:CommissionsDeCourtage,
									:ParticipationAuxBenefices,			
									:PrimesAcquises,
									:Sinistres,
									:CommissionsApporteurs,
									:Reassurance,
									:ResultatFinancier,
									:ProduitNetAssurance,
									:ProduitNetBancaire,
									:CoutDuRisque,
									:ResultatExploitation,
									:ResultatNet,
									:ResultatNetParDuGroupe,
									:Charges,
									:ResultatBrutExploitation,			
									:CoefficientExploitation,
									:Effectifs,
									:MeeDeCNP,
									:RatioSinistresSurPrimes,
									:RatioSsurPMoinsCumul,
									:Source)";
		$requete = $connexion->prepare($req);
		$tab=array(			"ID_Filiale"=>$this->ID_Filiale,
							"Filiale"=>$this->Filiale,
							"Annee"=>$this->Annee,
							"Mois"=>$this->Mois,
							"ChiffresAffaires"=>$this->ChiffresAffaires,
							"CommissionsDeCourtage"=>$this->CommissionsDeCourtage,
							"ParticipationAuxBenefices"=>$this->ParticipationAuxBenefices,			
							"PrimesAcquises"=>$this->PrimesAcquises,
							"Sinistres"=>$this->Sinistres,
							"CommissionsApporteurs"=>$this->CommissionsApporteurs,
							"Reassurance"=>$this->Reassurance,
							"ResultatFinancier"=>$this->ResultatFinancier,
							"ProduitNetAssurance"=>$this->ProduitNetAssurance,
							"ProduitNetBancaire"=>$this->ProduitNetBancaire,
							"CoutDuRisque"=>$this->CoutDuRisque,
							"ResultatExploitation"=>$this->ResultatExploitation,
							"ResultatNet"=>$this->ResultatNet,
							"ResultatNetParDuGroupe"=>$this->ResultatNetParDuGroupe,
							"Charges"=>$this->Charges,
							"ResultatBrutExploitation"=>$this->ResultatBrutExploitation,			
							"CoefficientExploitation"=>$this->CoefficientExploitation,
							"Effectifs"=>$this->Effectifs,
							"MeeDeCNP"=>$this->MeeDeCNP,
							"RatioSinistresSurPrimes"=>$this->RatioSinistresSurPrimes,
							"RatioSsurPMoinsCumul"=>$this->RatioSsurPMoinsCumul,
							"Source"=>$this->Source);
		if($requete->execute($tab)){
			$requete->CloseCursor();
			$this->ID_Filiale=$connexion->lastInsertId();
			return $this->ID_Filiale;
		}
		else
			return false;
	}
	
	// METHODE EDIT DB
	public function edit_db(){
		global $connexion;
		$req = "UPDATE IndicateursFiliales SET 
											ID_Filiale=:ID_Filiale,
											Filiale=:Filiale,
											Annee=:Annee,
											Mois=:Mois,
											ChiffresAffaires=:ChiffresAffaires,
											CommissionsDeCourtage=:CommissionsDeCourtage,
											ParticipationAuxBenefices=:ParticipationAuxBenefices,
											PrimesAcquises=:PrimesAcquises,
											Sinistres=:Sinistres,
											CommissionsApporteurs=:CommissionsApporteurs,
											Reassurance=:Reassurance,
											ResultatFinancier=:ResultatFinancier,
											ProduitNetAssurance=:ProduitNetAssurance,
											ProduitNetBancaire=:ProduitNetBancaire,
											CoutDuRisque=:CoutDuRisque,
											ResultatExploitation=:ResultatExploitation,
											ResultatNet=:ResultatNet,
											ResultatNetParDuGroupe=:ResultatNetParDuGroupe,
											Charges=:Charges,
											ResultatBrutExploitation=:ResultatBrutExploitation,
											CoefficientExploitation=:CoefficientExploitation,
											Effectifs=:Effectifs,
											MeeDeCNP=:MeeDeCNP,
											RatioSinistresSurPrimes=:RatioSinistresSurPrimes,
											RatioSsurPMoinsCumul=:RatioSsurPMoinsCumul,
											Source=:Source
											 WHERE ID_Filiale=:ID_Filiale AND Annee=:Annee AND Mois=:Mois";
		$requete = $connexion->prepare($req);
		$tab=array(			"ID_Filiale"=>$this->ID_Filiale,
							"Filiale"=>$this->Filiale,
							"Annee"=>$this->Annee,
							"Mois"=>$this->Mois,
							"ChiffresAffaires"=>$this->ChiffresAffaires,
							"CommissionsDeCourtage"=>$this->CommissionsDeCourtage,
							"ParticipationAuxBenefices"=>$this->ParticipationAuxBenefices,			
							"PrimesAcquises"=>$this->PrimesAcquises,
							"Sinistres"=>$this->Sinistres,
							"CommissionsApporteurs"=>$this->CommissionsApporteurs,
							"Reassurance"=>$this->Reassurance,
							"ResultatFinancier"=>$this->ResultatFinancier,
							"ProduitNetAssurance"=>$this->ProduitNetAssurance,
							"ProduitNetBancaire"=>$this->ProduitNetBancaire,
							"CoutDuRisque"=>$this->CoutDuRisque,
							"ResultatExploitation"=>$this->ResultatExploitation,
							"ResultatNet"=>$this->ResultatNet,
							"ResultatNetParDuGroupe"=>$this->ResultatNetParDuGroupe,
							"Charges"=>$this->Charges,
							"ResultatBrutExploitation"=>$this->ResultatBrutExploitation,			
							"CoefficientExploitation"=>$this->CoefficientExploitation,
							"Effectifs"=>$this->Effectifs,
							"MeeDeCNP"=>$this->MeeDeCNP,
							"RatioSinistresSurPrimes"=>$this->RatioSinistresSurPrimes,
							"RatioSsurPMoinsCumul"=>$this->RatioSsurPMoinsCumul,
							"Source"=>$this->Source);		if($requete->execute($tab)){
			$requete->CloseCursor();
			return true;
		}
		else
			return false;
	}
	
	// METHODE DELETE DB
	public function del_db(){
		global $connexion;
		$req = "DELETE FROM IndicateursFiliales WHERE ID_Filiale=:ID_Filiale AND Annee=:Annee AND Mois=:Mois";
		$requete = $connexion->prepare($req);
		$tab=array("ID_Filiale"=>$this->ID_Filiale, "Annee"=>$this->Annee,"Mois"=>$this->Mois);
		if($requete->execute($tab)){
			$requete->CloseCursor();
			return true;
		}
		else
			return false;
	}
	
	// EDIT_OBJECT
	public function edit_object($tab=array()){
		if(!empty($tab)){
			foreach($tab as $key => $val)$tab["$key"]=htmlentities($val, ENT_QUOTES, "UTF-8");
			if(isset($tab["ID_Filiale"]) && $tab["ID_Filiale"] != ""){$this->ID_Filiale=$tab["ID_Filiale"];}
			if(isset($tab["id_option"]) && $tab["id_option"] != ""){$this->id_option=$tab["id_option"];}
			if(isset($tab["Description"]) && $tab["Description"] != ""){$this->Description=$tab["Description"];}
			if(isset($tab["en_stock"]) && $tab["en_stock"] != ""){$this->en_stock=$tab["en_stock"];}
			if(isset($tab["prix"]) && $tab["prix"] != ""){$this->prix=$tab["prix"];}
			if(isset($tab["unite"]) && $tab["unite"] != ""){$this->unite=$tab["unite"];}
			if(isset($tab["ID_Filiale"]) && $tab["ID_Filiale"] != "")										{$this->ID_Filiale=$tab["ID_Filiale"];} 				
			if(isset($tab["Filiale"]) && $tab["Filiale"] != "")												{$this->Filiale=$tab["Filiale"];}
			if(isset($tab["Annee"]) && $tab["Annee"] != "")													{$this->Annee=$tab["Annee"];}					
			if(isset($tab["Mois"]) && $tab["Mois"] != "")													{$this->Mois=$tab["Mois"];}					
			if(isset($tab["ChiffresAffaires"]) && $tab["ChiffresAffaires"] != "")							{$this->ChiffresAffaires=$tab["ChiffresAffaires"];}
			if(isset($tab["CommissionsDeCourtage"]) && $tab["CommissionsDeCourtage"] != "")					{$this->CommissionsDeCourtage=$tab["CommissionsDeCourtage"];}
			if(isset($tab["ParticipationAuxBenefices"]) && $tab["ParticipationAuxBenefices"] != "")			{$this->ParticipationAuxBenefices		=$tab["ParticipationAuxBenefices		"];}		
			if(isset($tab["PrimesAcquises"]) && $tab["PrimesAcquises"] != "")								{$this->PrimesAcquises=$tab["PrimesAcquises"];}
			if(isset($tab["Sinistres"]) && $tab["Sinistres"] != "")											{$this->Sinistres=$tab["Sinistres"];}
			if(isset($tab["CommissionsApporteurs"]) && $tab["CommissionsApporteurs"] != "")					{$this->CommissionsApporteurs=$tab["CommissionsApporteurs"];}
			if(isset($tab["Reassurance"]) && $tab["Reassurance"] != "")										{$this->Reassurance=$tab["Reassurance"];}
			if(isset($tab["ResultatFinancier"]) && $tab["ResultatFinancier"] != "")							{$this->ResultatFinancier=$tab["ResultatFinancier"];}
			if(isset($tab["ProduitNetAssurance"]) && $tab["ProduitNetAssurance"] != "")						{$this->ProduitNetAssurance=$tab["ProduitNetAssurance"];}
			if(isset($tab["ProduitNetBancaire"]) && $tab["ProduitNetBancaire"] != "")						{$this->ProduitNetBancaire=$tab["ProduitNetBancaire"];}
			if(isset($tab["CoutDuRisque"]) && $tab["CoutDuRisque"] != "")									{$this->CoutDuRisque=$tab["CoutDuRisque"];}
			if(isset($tab["ResultatExploitation"]) && $tab["ResultatExploitation"] != "")					{$this->ResultatExploitation=$tab["ResultatExploitation"];}
			if(isset($tab["ResultatNet"]) && $tab["ResultatNet"] != "")										{$this->ResultatNet=$tab["ResultatNet"];}
			if(isset($tab["ResultatNetParDuGroupe"]) && $tab["ResultatNetParDuGroupe"] != "")				{$this->ResultatNetParDuGroupe=$tab["ResultatNetParDuGroupe"];}
			if(isset($tab["Charges"]) && $tab["Charges"] != "")												{$this->Charges=$tab["Charges"];}
			if(isset($tab["ResultatBrutExploitation"]) && $tab["ResultatBrutExploitation"] != "")			{$this->ResultatBrutExploitation		=$tab["ResultatBrutExploitation		"];}		
			if(isset($tab["CoefficientExploitation"]) && $tab["CoefficientExploitation"] != "")				{$this->CoefficientExploitation=$tab["CoefficientExploitation"];}
			if(isset($tab["Effectifs"]) && $tab["Effectifs"] != "")											{$this->Effectifs=$tab["Effectifs"];}
			if(isset($tab["MeeDeCNP"]) && $tab["MeeDeCNP"] != "")											{$this->MeeDeCNP=$tab["MeeDeCNP"];}
			if(isset($tab["RatioSinistresSurPrimes"]) && $tab["RatioSinistresSurPrimes"] != "")				{$this->RatioSinistresSurPrimes=$tab["RatioSinistresSurPrimes"];}
			if(isset($tab["RatioSsurPMoinsCumul"]) && $tab["RatioSsurPMoinsCumul"] != "")					{$this->RatioSsurPMoinsCumul=$tab["RatioSsurPMoinsCumul"];}
			if(isset($tab["Source"]) && $tab["Source"] != "")												{$this->Source=$tab["Source"];}
		}
	}

	// GETTERS
	
	public function getID_Filiale(){return html_entity_decode($this->ID_Filiale);}
	public function getFiliale(){return html_entity_decode($this->Filiale);}
	public function getAnnee(){return html_entity_decode($this->Annee);}
	public function getMois(){return html_entity_decode($this->Mois);}
	public function getChiffresAffaires(){return html_entity_decode($this->ChiffresAffaires);}
	public function getCommissionsDeCourtage(){return html_entity_decode($this->CommissionsDeCourtage);}
	public function getParticipationAuxBenefices(){return html_entity_decode($this->ParticipationAuxBenefices);}
	public function getPrimesAcquises(){return html_entity_decode($this->PrimesAcquises);}
	public function getSinistres(){return html_entity_decode($this->Sinistres);}
	public function getCommissionsApporteurs(){return html_entity_decode($this->CommissionsApporteurs);}
	public function getReassurance(){return html_entity_decode($this->Reassurance);}
	public function getResultatFinancier(){return html_entity_decode($this->ResultatFinancier);}
	public function getProduitNetAssurance(){return html_entity_decode($this->ProduitNetAssurance);}
	public function getProduitNetBancaire(){return html_entity_decode($this->ProduitNetBancaire);}
	public function getCoutDuRisque(){return html_entity_decode($this->CoutDuRisque);}
	public function getResultatExploitation(){return html_entity_decode($this->ResultatExploitation);}
	public function getResultatNet(){return html_entity_decode($this->ResultatNet);}
	public function getResultatNetParDuGroupe(){return html_entity_decode($this->ResultatNetParDuGroupe);}
	public function getCharges(){return html_entity_decode($this->Charges);}
	public function getResultatBrutExploitation(){return html_entity_decode($this->ResultatBrutExploitation);}
	public function getCoefficientExploitation(){return html_entity_decode($this->CoefficientExploitation);}
	public function getEffectifs(){return html_entity_decode($this->Effectifs);}
	public function getMeeDeCNP(){return html_entity_decode($this->MeeDeCNP);}
	public function getRatioSinistresSurPrimes(){return html_entity_decode($this->RatioSinistresSurPrimes);}
	public function getRatioSsurPMoinsCumul(){return html_entity_decode($this->RatioSsurPMoinsCumul);}
	public function getSource(){return html_entity_decode($this->Source);}

	// SETTERS
	
	public function setID_Filiale($a){$this->ID_Filiale=($a);}
	public function setFiliale($a){$this->Filiale=($a);}
	public function setAnnee($a){$this->Annee=($a);}
	public function setMois($a){$this->Mois=($a);}
	public function setChiffresAffaires($a){$this->ChiffresAffaires=($a);}
	public function setCommissionsDeCourtage($a){$this->CommissionsDeCourtage=($a);}
	public function setParticipationAuxBenefices($a){$this->ParticipationAuxBenefices=($a);}
	public function setPrimesAcquises($a){$this->PrimesAcquises=($a);}
	public function setSinistres($a){$this->Sinistres=($a);}
	public function setCommissionsApporteurs($a){$this->CommissionsApporteurs=($a);}
	public function setReassurance($a){$this->Reassurance=($a);}
	public function setResultatFinancier($a){$this->ResultatFinancier=($a);}
	public function setProduitNetAssurance($a){$this->ProduitNetAssurance=($a);}
	public function setProduitNetBancaire($a){$this->ProduitNetBancaire=($a);}
	public function setCoutDuRisque($a){$this->CoutDuRisque=($a);}
	public function setResultatExploitation($a){$this->ResultatExploitation=($a);}
	public function setResultatNet($a){$this->ResultatNet=($a);}
	public function setResultatNetParDuGroupe($a){$this->ResultatNetParDuGroupe=($a);}
	public function setCharges($a){$this->Charges=($a);}
	public function setResultatBrutExploitation($a){$this->ResultatBrutExploitation=($a);}
	public function setCoefficientExploitation($a){$this->CoefficientExploitation=($a);}
	public function setEffectifs($a){$this->Effectifs=($a);}
	public function setMeeDeCNP($a){$this->MeeDeCNP=($a);}
	public function setRatioSinistresSurPrimes($a){$this->RatioSinistresSurPrimes=($a);}
	public function setRatioSsurPMoinsCumul($a){$this->RatioSsurPMoinsCumul=($a);}
	public function setSource($a){$this->Source=($a);}

	// INPUTS
	public function getIdInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input type="hidden" name="ID_Filiale" '.$attributs.' value="'.$this->ID_Filiale.'" />';}
	public function getIdOptionInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="id_option" '.$attributs.' value="'.$this->id_option.'" />';}
	public function getDescriptionInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="Description" '.$attributs.' value="'.$this->Description.'" />';}
	public function getEnStockInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="en_stock" '.$attributs.' value="'.$this->en_stock.'" />';}
	public function getPrixInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="prix" '.$attributs.' value="'.$this->prix.'" />';}
	public function getUniteInput($attr){if(empty($attr)){$attr=array();$attr["type"]="text";}$attributs = "";foreach($attr as $key => $val)$attributs .= $key.'="'.$val.'" ';return '<input name="unite" '.$attributs.' value="'.$this->unite.'" />';}
}
?>