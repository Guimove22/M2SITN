<?php
class Site{
	
	
	/* ----- LISTE DES FILIALES ----- */
	public static function getListeFiliales(){
		global $connexion;



		$req="SELECT * FROM Filiales WHERE ID_Filiale <5 ";
		$requete = $connexion->prepare($req);

		$requete->execute();
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$return=array();
		while($tab = $requete->fetch()){
			$res=new Filiale($tab);
			$res->load_db();
			$return[]=$res;
		}
		return $return;
	}

	/* ----- LISTES DES SLUGS EXISTANTS PAR CLASSE ----- */
	public static function getSlugListeCategories(){
		global $connexion;
		$req="SELECT nom_slug FROM boiscab_categories" ;
		$requete = $connexion->prepare($req);
		$requete->execute();
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$return=array();
		while($tab = $requete->fetch()){
			$return[]=$tab["nom_slug"];
		}
		return $return;
	}
	public static function getSlugListeSousCategories(){
		global $connexion;
		$req="SELECT nom_slug FROM boiscab_sous_categories" ;
		$requete = $connexion->prepare($req);
		$requete->execute();
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$return=array();
		while($tab = $requete->fetch()){
			$return[]=$tab["nom_slug"];
		}
		return $return;
	}
	public static function getSlugListeProduits(){
		global $connexion;
		$req="SELECT nom_slug FROM boiscab_produi" ;
		$requete = $connexion->prepare($req);
		$requete->execute();
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$return=array();
		while($tab = $requete->fetch()){
			$return[]=$tab["nom_slug"];
		}
		return $return;
	}
	
	public static function getSlider($i){
		global $connexion;
		$req="SELECT * FROM boiscab_slideshow WHERE type_slider = :type_slider ORDER BY position" ;
		$requete = $connexion->prepare($req);
		$requete->execute(array('type_slider'=>$i));
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$return=array();
		while($tab = $requete->fetch()){
			$return[] = new Slide($tab);
		}
		return $return;
	}
	/* ---------- */
	public static function getListeServices($type = NULL){
		global $connexion;
		$req="SELECT * FROM boiscab_services ORDER BY id" ;
		$requete = $connexion->prepare($req);
		$requete->execute();
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$return=array();
		while($tab = $requete->fetch()){
			$return[]=new Service($tab);
		}
		return $return;
	
	}
	
	public static function getListeCategories($type = NULL){
		global $connexion;
		if(is_null($type))$req="SELECT * FROM boiscab_categories WHERE ID < 4" ;
		else $req="SELECT * FROM boiscab_categories WHERE ID > 3" ;
		$requete = $connexion->prepare($req);
		$requete->execute();
		$requete->setFetchMode(PDO::FETCH_ASSOC);
		$return=array();
		while($tab = $requete->fetch()){
			$return[]=new Categorie($tab);
		}
		return $return;
	
	}
	
	public static function verif_doublon($str, $tableauVerif){
		foreach($tableauVerif as $val){
			if($str==$val){
				$der = substr($str, -1);
				if(is_numeric($der)){
					$str = substr($str, 0, strlen($str)-1) . $der++;
					$str = substr($str, 0, strlen($str)-1) . $der;
				}
				else
					$str = $str . 1; 
			}
		}
		return $str;
		
	}
	public static function slugMe($str, $type, $replace=array(), $delimiter='-') {
		$str = html_entity_decode($str);
		if( !empty($replace) ) {
			$str = str_replace((array)$replace, ' ', $str);
		}
		setlocale(LC_ALL, 'en_US.UTF8');
		$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $str);
		$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
		$clean = strtolower(trim($clean, '-'));
		$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
		
		if($type="categorie") $tab = Site::getSlugListeCategories();
		if($type="souscategorie") $tab = Site::getSlugListeSousCategories();
		if($type="produit") $tab = Site::getSlugListeProduits();
		
		return Site::verif_doublon($clean,$tab);
	}
	
	public static function getPathSite(){
		return "/homepages/44/d473360403/htdocs";
	}
	
}