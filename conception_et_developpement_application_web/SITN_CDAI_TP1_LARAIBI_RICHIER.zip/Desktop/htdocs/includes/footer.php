<footer class="bs-docs-footer muted " >
	<div id="footer">
		<div class="container credits">
			<p>
				<!--Interface créée par <a href="http://www.axelrichier.com">Axel Richier</a> pour--> La Banque Postale - <a href="?p=infosArcad">À Propos</a></br>
				Currently v1.1 - 2014 
			</p>

		</div>
	</div>

</footer>