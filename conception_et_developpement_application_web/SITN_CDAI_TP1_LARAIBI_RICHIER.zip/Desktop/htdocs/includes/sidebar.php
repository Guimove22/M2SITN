<nav class="col-lg-2 mainSidebar" data-spy="affix" data-offset-top="60" data-offset-bottom="200">
   <div class="list-group">
    <a href="#" class="list-group-item">
    	Rachats
    </a>
    <a href="#" class="list-group-item">
    	Réclamations
    </a>
    <a href="#" class="list-group-item">
    	Portefeuille
    </a>
    <a href="#" class="list-group-item">
    	Canaux de souscription
    </a>
    <a href="#" class="list-group-item">
    	Données Financières
    </a>
    
  
    </a>
  </div>
</div>
</nav>