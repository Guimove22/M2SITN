<?php

	

	importerBug($_POST["titre"],$_POST["description"],"Nouveau",$_POST["date"]);
	header('Location: ../index.php?p=bugs-report'); 
			
	function importerBug($titre,$description,$etat,$date){
	    echo $titre.$description.$etat;
		//$dbh = new PDO('sqlite:D:\Documents and Settings\vytg315\Mes documents\sqlite\SQLBDD1');
		//$connexion = new PDO('sqlite:D:\Documents and Settings\vytg315\Mes documents\sqlite\SQL290714');
		$connexion = new PDO('sqlite:C:\xampp\BDD_SQLite\SQL290714');
	    
	    

	    //$req="SELECT DISTINCT(Mois) AS Mois FROM EncoursCNPParOffre WHERE Annee=:Annee" ;
	    $req="INSERT INTO Bugs (titre,datebug,description,etat) VALUES (:Titre,:laDate,:Description,:Etat)";

	    $requete = $connexion->prepare($req);
	    $requete->execute(array("Titre"=>$titre,
	    						"Description"=>$description,
	    						"Etat"=>$etat,
	    						"laDate"=>$date));
	        

        
        $tab = $requete->fetch();
    }   




?>