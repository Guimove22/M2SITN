<?php

$caseRequeteEnCoursGroupeeparOffre ='CASE
                                                            WHEN LibelleOffre LIKE "%Ascendo%"   THEN "Ascendo"
                                                            WHEN LibelleOffre LIKE "%Assurdix%"   THEN "Assurdix"
                                                            WHEN LibelleOffre LIKE "%Assurimmo%"   THEN "Assurimmo"
                                                            WHEN LibelleOffre LIKE "%Assuravie%"   THEN "Assuravie"
                                                            WHEN LibelleOffre LIKE "%Plein Temps%"   THEN "Plein Temps"
                                                            WHEN LibelleOffre LIKE "%Poste Avenir%"   THEN "Poste Avenir"
                                                            WHEN LibelleOffre LIKE "%Aviposte%"   THEN "Aviposte"
                                                            WHEN LibelleOffre LIKE "%Avisys%"   THEN "Avisys"
                                                            WHEN LibelleOffre LIKE "%munys%"   THEN "Prémunys"
                                                            WHEN LibelleOffre LIKE "%Assurindex%" THEN "Assurindex"
                                                            WHEN LibelleOffre LIKE "%Compl%" THEN "Complétys"
                                                            WHEN LibelleOffre LIKE "%Terme%" THEN "Terme Fixe"
                                                            WHEN LibelleOffre LIKE "%Survie%" THEN "Rente Survie"
                                                            WHEN LibelleOffre LIKE "%Serenia%" THEN "Serenia"
                                                            WHEN LibelleOffre LIKE "%Ponctualys%" THEN "Ponctualys"
                                                            WHEN LibelleOffre LIKE "%vialys%" THEN "Prévialys"
                                                            WHEN LibelleOffre LIKE "%solys%" THEN "Résolys"
                                                            WHEN LibelleOffre LIKE "%Forfaitys%" THEN "Forfaitys"
                                                            WHEN LibelleOffre LIKE "%Futurys%" THEN "Futurys"
                                                            WHEN LibelleOffre LIKE "%Protectys%" THEN "Protectys"
                                                            WHEN LibelleOffre LIKE "%Seralys%" THEN "Seralys"
                                                            WHEN LibelleOffre LIKE "%Assuremprunt%"   THEN "Assuremprunt"
                                                            WHEN LibelleOffre LIKE "%Assur�tudes%"   THEN "Assurétudes"
                                                            WHEN LibelleOffre LIKE "%sio%"   THEN "Solésio"
                                                            WHEN LibelleOffre LIKE "%Enti%"   THEN "Vie Entière"
                                                                

                                                            WHEN LibelleOffre LIKE "%Capiposte%"   THEN "Capiposte"
                                                            WHEN LibelleOffre LIKE "%Assurimmo%"   THEN "Assurimmo"
                                                            WHEN LibelleOffre LIKE "%Cachemire%"   THEN "Cachemire"
                                                            WHEN LibelleOffre LIKE "%Exc�lius%"   THEN "Excélius"
                                                            WHEN LibelleOffre LIKE "%GMO%"   THEN "GMO"
                                                            WHEN LibelleOffre LIKE "%Vivaccio%"   THEN "Vivacio"
                                                            WHEN LibelleOffre LIKE "%Resolys%"   THEN "Resolys"
                                                            ELSE "Autres"

                                                            END';

 $caseRequeteEnCoursGroupeeParProduit ='CASE
                                                            
                                                           
                                                            WHEN categorieproduit LIKE "%ASC%" THEN "ASCENDO"
                                                            WHEN categorieproduit LIKE "%ASSURDIX_365_366_376_378_905%" THEN "ASSURDIX"
                                                            WHEN categorieproduit LIKE "%ASSUREPARGNE_460%" THEN "ASSUREPARGNE"
                                                            WHEN categorieproduit LIKE "%ASSURFONDS_160%" THEN "ASSURFONDS"
                                                            WHEN categorieproduit LIKE "%ASSURIMMO%" THEN "ASSURIMMO"
                                                            
                                                            WHEN categorieproduit LIKE "%CACH_079_246_212_931%" THEN "CACHEMIRE"
                                                            WHEN categorieproduit LIKE "%CAPIPOSTE_398_399_400_412%" THEN "CAPIPOSTE"
                                                            WHEN categorieproduit LIKE "%COMPLEA_339%" THEN "COMPLEA"
                                                            WHEN categorieproduit LIKE "%DIVERS%" THEN "DIVERS"
                                                            WHEN categorieproduit LIKE "%EXCELIUS%" THEN "EXCELIUS"
                                                            
                                                            
                                                            
                                                            WHEN categorieproduit LIKE "%GMO_965_969_977%" THEN "GMO"
                                                            WHEN categorieproduit LIKE "%PA_343_443%" THEN "PA"
                                                            WHEN categorieproduit LIKE "%PEP_POSTE%" THEN "PEP_POSTE"
                                                            
                                                            WHEN categorieproduit LIKE "%PEP_PU_922%" THEN "PEP_PU"
                                                            WHEN categorieproduit LIKE "%PER_900_910_915%" THEN "PER"
                                                            WHEN categorieproduit LIKE "%PLEIN_TEMPS%" THEN "PLEIN_TEMPS"
                                                            WHEN categorieproduit LIKE "%QUIETUDE_609%" THEN "QUIETUDE"
                                                            WHEN categorieproduit LIKE "%SELEXIO_161%" THEN "SELEXIO"
                                                            WHEN categorieproduit LIKE "%TOSC_298%" THEN "TOSC"
                                                            WHEN categorieproduit LIKE "%VIVA_012_500_625%" THEN "VIVA"

                                                            WHEN categorieproduit LIKE "%ASSURETUDES_249%" THEN "ASSURETUDES" 
                                                            WHEN categorieproduit LIKE "%ASSURINDEX_240%" THEN "ASSURINDEX"  
                                                            WHEN categorieproduit LIKE "%AVIPOSTE_332%" THEN "AVIPOSTE"    
                                                            WHEN categorieproduit LIKE "%AVISYS_228_227%" THEN "AVISYS"  
                                                            WHEN categorieproduit LIKE "%COMPLETYS_088%" THEN "COMPLETYS"   
                                                            WHEN categorieproduit LIKE "%DIVERS%" THEN "DIVERS"  
                                                            WHEN categorieproduit LIKE "%FORFAITYS_074%" THEN "FORFAITYS"   
                                                            WHEN categorieproduit LIKE "%FUTURYS_073_659%" THEN "FUTURYS" 
                                                            WHEN categorieproduit LIKE "%PONCTUALYS_058%" THEN "PONCTUALYS" 
                                                            WHEN categorieproduit LIKE "%PREMUNYS_057_197%" THEN "PREMUNYS"    
                                                            WHEN categorieproduit LIKE "%PREVIALYS_700_950%" THEN "PREVIALYS"   
                                                            WHEN categorieproduit LIKE "%PROTECTYS_846%" THEN "PROTECTYS"   
                                                            WHEN categorieproduit LIKE "%RESOLYS%" THEN "RESOLYS" 
                                                           
                                                            WHEN categorieproduit LIKE "%SERALYS_413_451%" THEN "SERALYS" 
                                                            WHEN categorieproduit LIKE "%SERENIA_295%" THEN "SERENIA"

                                                        
                                                            ELSE "Autres"

                                                            END';

      
function afficherSelecteurTrimestreImpayes($metier,$annee){

    global $connexion;
    if (($metier=="Prevoyance")||($metier=="Epargne")){
        
        $req = "SELECT Trimestre FROM ImpayesOperations WHERE Metier=:Metier AND Annee=:Annee GROUP BY Trimestre";
            
        
        $requete = $connexion->prepare($req);
        $requete->execute(array("Metier"=>$metier,"Annee"=>$annee));
        
    }
    if ($metier=="Partages"){
        $req = "SELECT Trimestre FROM ImpayesOperations WHERE (Metier='Epargne' OR Metier='Prevoyance') AND Annee=:Annee GROUP BY Trimestre";
            
        
        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee));

    }
        $return="";
        while($tab = $requete->fetch()){
            
                $return[]=$tab["Trimestre"];    
        }

        if (isset($_GET["trimestre"])){
            $trimestre=$_GET["trimestre"];
        }else{
            $trimestre=1;
        }
        

        echo    '<form method="get" action="index.php">'
            .'<input type="hidden" name="p" value="'.$_GET["p"].'">'
            .'<input type="hidden" name="metier" value="'.$metier.'">'
            .'<input type="hidden" name="annee" value="'.$annee.'">
            <div class="btn-group">';

         foreach ($return as $key => $value) {
           if($trimestre==$value){$info="info";}else{$info="default";}
            echo '<button type="submit" name="trimestre" class="btn btn-'.$info.'" value="'.$value.'"> Trimestre '.$value.'</button>';
        }

             echo '</div></form>';
        
        return $return;


}

function   afficherSelecteurTypeEncours($metier,$annee,$mois){

    echo    '<form method="get" action="index.php">'
            .'<input type="hidden" name="p" value="enCours">'
            .'<input type="hidden" name="metier" value="'.$metier.'">'
            .'<input type="hidden" name="annee" value="'.$annee.'">'
            .'<input type="hidden" name="mois" value="'.$mois.'">';

        
           
            echo '<div class="btn-group">
                    <button type="submit" name="type" class="btn btn-'; if(isset($_GET["type"])&&($_GET["type"]=="parOffre")){echo 'info';}else{echo 'default';} echo'" value="parOffre"> Par Offre</button>
                    <button type="submit" name="type" class="btn btn-'; if(isset($_GET["type"])&&($_GET["type"]=="parProduit")){echo 'info';}else{echo 'default';} echo'" value="parProduit"> Par Produit</button>
                    <button type="submit" name="type" class="btn btn-'; if(isset($_GET["type"])&&($_GET["type"]=="parSupport")){echo 'info';}else{echo 'default';} echo'" value="parSupport"> Par Support</button></div></form>';

}
function afficherSelecteurMetierImpayes(){
       $page="impayes";
    
    $t="";
    $a="";

    extract($_GET);

    if (isset($trimestre)){
        $t=$trimestre;
    }else{$t=1;}
     if (isset($annee)){
        $a=$annee;
    }else{$a=2014;}
    if (isset($metier)){
        $met=$metier;
    }else{$met="Epargne";}


    echo    '<form method="get" action="index.php">'
            .'<input type="hidden" name="p" value="'.$page.'">'
            .'<input type="hidden" name="annee" value="'.$a.'">'
            .'<input type="hidden" name="trimestre" value="'.$t.'">';

    
       
        echo '<div class="btn-group">
             <button type="submit" name="metier" class="btn btn-'; if($met=="Epargne"){echo 'info';}else{echo 'default';}
                    echo'" value="Epargne"> Assurance-Vie Retraite</button>';
        echo '<button type="submit" name="metier" class="btn btn-'; if($met=="Prevoyance"){echo 'info';}else{echo 'default';}
                echo'" value="Prevoyance"> Prévoyance </button>';
        echo '<button type="submit" name="metier" class="btn btn-'; if($met=="Partages"){echo 'info';}else{echo 'default';}
                echo'" value="Partages"> Les Deux </button>';
    

    echo '</div></form>';


}
function afficherSelecteurMetierEncours(){
    $page="enCours";
    
    $m="";
    $a="";
    $type="";

    extract($_GET);

    if (isset($mois)){
        $m=$mois;
    }else{$m=1;}
     if (isset($annee)){
        $a=$annee;
    }else{$a=2014;}
    if (isset($type)){
        $t=$type;
    }else{$a="Epargne";}
    if (isset($metier)){
        $met=$metier;
    }else{
        $met="Epargne";
    }


    echo    '<form method="get" action="index.php">'
            .'<input type="hidden" name="p" value="'.$page.'">'
            .'<input type="hidden" name="annee" value="'.$a.'">'
            .'<input type="hidden" name="mois" value="'.$m.'">'
            .'<input type="hidden" name="type" value="'.$t.'">';

        
       echo '<div class="btn-group">';
        echo '<button type="submit" name="metier" class="btn btn-'; if($met=="Epargne"){echo 'info';}else{echo 'default';}
        echo'" value="Epargne"> Épargne</button>';
        echo '<button type="submit" name="metier" class="btn btn-'; if($met=="Prevoyance"){echo 'info';}else{echo 'default';}
        echo'" value="Prevoyance"> Prévoyance </button>';
        echo '<button type="submit" name="metier" class="btn btn-'; if($met=="Retraite"){echo 'info';}else{echo 'default';}
        echo'" value="Retraite"> Retraite </button>';
    

    echo '</div></form>';


}
function afficherSelecteurAnneeImpayes($liste){
    $page="impayes";
    
    $t="";
    $a="";

    extract($_GET);

    if (isset($trimestre)){
        $t=$trimestre;
    }else{}
    if (isset($metier)){
        $met=$metier;
    }else{
        $met="Epargne";
    }if (!isset($annee)){
        $annee=date("Y");
    }


    echo    '<form method="get" action="index.php">'
            .'<input type="hidden" name="p" value="'.$page.'">'
            .'<input type="hidden" name="metier" value="'.$met.'">
                <div class="btn-group">';

     foreach ($liste as $key => $value) {
        if($annee==$value){$info="info";}else{$info="default";}
        echo '<button type="submit" name="annee" class="btn btn-'.$info.'" value="'.$value.'"> '.$value.'</button>';
    }

    echo '</div></form>';

                        
}
function afficherSelecteurAnneeEncours($liste){
   
    $page="enCours";
    
    $t="";
    $a="";

    extract($_GET);

    if (isset($trimestre)){
        $t=$trimestre;
    }else{}
    if (isset($metier)){
        $met=$metier;
    }else{
        $met="Epargne";
    }if (isset($_GET["type"])){
        $type=$_GET["type"];
    }else{
        $type="parOffre";
    }if (!isset($annee)){
        $annee=date("Y");
    }


    echo    '<form method="get" action="index.php">'
            .'<input type="hidden" name="p" value="'.$page.'">'
            .'<input type="hidden" name="metier" value="'.$met.'">'
            .'<input type="hidden" name="type" value="'.$type.'">';
            echo '<div class="btn-group">';
     foreach ($liste as $key => $value) {
        if($annee==$value){$info="info";}else{$info="default";}
        echo '<button type="submit" name="annee" class="btn btn-'.$info.'" value="'.$value.'"> '.$value.'</button>';
    }

    echo '</div></form>';

                        
}

function getListeOffreImpayes($metier,$annee,$trimestre){
     global $connexion;

        
        $req = "SELECT Offre FROM ImpayesOperations WHERE Metier=:Metier GROUP BY Offre";
            
        
        $requete = $connexion->prepare($req);
        $requete->execute(array("Metier"=>$metier));
        

        
        while($tab = $requete->fetch()){
            
                $return[]=$tab["Offre"];    
        }
        
        
        return $return;
    
    }


function tableauImpayesParMotif($metier,$annee,$trimestre){

    global $connexion;

        
        $req = 'SELECT SUM(Nombre) AS TNombre, SUM(Montant) AS TMontant FROM impayesdetails WHERE Annee=:Annee and Trimestre =:Trimestre and Metier=:Metier';
            
        
        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee,"Trimestre"=>$trimestre,"Metier"=>$metier));
        

        
        $tab = $requete->fetch();
            
        $TotalNombre=$tab["TNombre"];    
        $TotalMontant=$tab["TMontant"];    
        
        if ($metier=="Epargne"){
            $metierDisplay="Assurance-Vie Retraite";
        }else {$metierDisplay=$metier;}
        echo "<h3>Détail des Impayes ".$annee." du T".$trimestre." par offre du metier ".$metierDisplay.'</h3>';

        echo '<h4>total montant: '.$TotalMontant. '// TotalNombre : '.$TotalNombre.'</h4>';

        echo '<table class="table table-bordered table-striped table-hover">
          <thead>
            <tr>
              <th>Code Impaye</th>
              <th>Libellé Motif Impayé</th>
              <th>Nombre</th>
              <th>% Nombre</th>
              <th>Montant en €</th>
              <th>% montant</th>
            </tr>
          </thead>
          <tbody>';
        

        $req = 'SELECT CodeImpaye,LibelleMotifImpaye,SUM(Nombre) AS nb,SUM(Montant) AS Montant
                    FROM impayesdetails 
                        WHERE annee=:Annee
                            AND trimestre =:Trimestre 
                            AND metier =:Metier
                                GROUP BY libelleMotifimpaye 
                                ORDER BY CodeImpaye';
            
        
        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee,"Trimestre"=>$trimestre,"Metier"=>$metier));

        while($tab = $requete->fetch()){
            echo '<tr >
                     <td>'.$tab["CodeImpaye"].'</td>
                     <td>'.utf8_encode($tab["LibelleMotifImpaye"]).'</td>
                     <td class="eurosAdroite">'.round($tab["nb"],0).'</td>
                     <td class="eurosAdroite">'.round((($tab["nb"]/$TotalNombre)*100),1).' %</td>
                     <td class="eurosAdroite">'.number_format($tab["Montant"],2,',','.').' €</td>
                     <td class="eurosAdroite">'.round((($tab["Montant"]/$TotalMontant)*100),1).' %</td>
                     </tr>';
           
        }
        echo "</tbody></table>";
        
        
        

    
    }

function tableauImpayesSurPrelevement($metier,$annee,$trimestre){
    if ($metier=="Epargne"){
            $metierDisplay="Assurance-Vie Retraite";
        }else {$metierDisplay=$metier;}
    echo "<h3>Taux d'impayes sur Prélèvements ".$annee." au T".$trimestre." du metier ".$metierDisplay.'</h3>';

    echo '<table class="table table-bordered table-striped table-hover">
      <thead>
        <tr>
          <th>Offre</th>
          <th>Prélèvements</th>
          <th>Nombre</th>
          <th>% Nombre</th>
        </tr>
      </thead>
      <tbody>';

    global $connexion;
    $req= 'SELECT Offre,Presentes,(Impayes/Presentes) AS  pimp,Impayes,(Payes/Presentes) AS  ppay,Payes 
                FROM impayesOffre 
                    WHERE annee=:Annee 
                        AND Trimestre=:Trimestre 
                        AND Metier=:Metier
                            ORDER BY Offre';

    $requete = $connexion->prepare($req);
    $requete->execute(array("Annee"=>$annee,"Trimestre"=>$trimestre,"Metier"=>$metier));

    while($tab = $requete->fetch()){
        echo '<tr>
                 <td rowspan=3>'.$tab["Offre"].'</td>
                 <td>Prélèvements</td>
                 <td class="eurosAdroite">'.number_format((double)$tab["Presentes"],0,',','.').'</td>
                 <td class="eurosAdroite">100%</td>
              </tr>
              <tr>
                 <td>Impayes</td>
                 <td class="eurosAdroite">'.number_format((double)$tab["Impayes"],0,',','.').'</td>
                 <td class="eurosAdroite">'.round(($tab["pimp"]*100),2).'%</td>
              </tr>
              <tr>
                 <td>Payes</td>
                 <td class="eurosAdroite">'.number_format((double)$tab["Payes"],0,',','.').'</td>
                 <td class="eurosAdroite">'.round(($tab["ppay"]*100),2).'%</td>
              </tr>';
           
        }

    echo '</tbody></table>';


}
function tableauImpayesParOffreDetaillee($offre,$metier,$annee,$trimestre){
    global $connexion;

       $req= 'SELECT CodeImpaye, LibelleMotifImpaye, Nombre,PourcentageNombre,Montant,PourcentageMontant 
                FROM impayesDetails
                WHERE Annee=:Annee 
                AND Trimestre=:Trimestre
                AND Offre=:Offre';

    $requete = $connexion->prepare($req);
    $requete->execute(array("Annee"=>$annee,"Trimestre"=>$trimestre,"Offre"=>$offre));

    if($offre=="Ascendo")
        $active="active";
    else if($offre=="Avisys")
        $active="active";
    else
        $active="";
    
     echo '  <div class="tab-pane '.$active.' fade in" id="'.$offre.'">
                    <table class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                              <th>Code impayé</th>
                              <th>Libellé Motif impayé</th>
                              <th>Nombre</th>
                              <th>% Nombre</th>
                              <th>Montant en €</th>
                              <th>% montant</th>
                            </tr>

                        </thead>
                        <tbody>';
    
    while($tab = $requete->fetch()){
        
                        echo '<tr>
                            <td>'.$tab["CodeImpaye"].'</td>
                            <td >'.utf8_encode($tab["LibelleMotifImpaye"]).'</td>
                            <td class="eurosAdroite">'.round($tab["Nombre"],0).'</td>
                            <td class="eurosAdroite">'.round(($tab["PourcentageNombre"]*100),2).'%</td>
                            <td class="eurosAdroite">'.number_format((double)$tab["Montant"],1,',','.').' €</td>
                            <td class="eurosAdroite">'.round(($tab["PourcentageMontant"]*100),2).'%</td>
                            </tr>';

                    
    }
      echo '</tbody>
                </table>
            </div>';

}
function tableauDetailImpayesParOffre($metier,$annee,$trimestre){

    global $connexion;
    $req= 'SELECT Offre,Presentes,(Impayes/Presentes) AS  pimp,Impayes,(Payes/Presentes) AS  ppay,Payes 
                FROM impayesOffre 
                    WHERE annee=:Annee 
                        AND Trimestre=:Trimestre 
                        AND Metier=:Metier
                            ORDER BY Offre';

    $requete = $connexion->prepare($req);
    $requete->execute(array("Annee"=>$annee,"Trimestre"=>$trimestre,"Metier"=>$metier));

    if ($metier=="Epargne"){
            $metierDisplay="Assurance-Vie Retraite";
        }else {$metierDisplay=$metier;}
    echo "<h3>Détail des Impayes ".$annee." du T".$trimestre." par offre du metier ".$metierDisplay.'</h3>';

    echo' <ul class="nav nav-tabs nav-justified" role="tablist"> ';
    $listeOffre= array();
    while($tab = $requete->fetch()){
        $listeOffre[]=$tab["Offre"];
        echo '<li><a href="#'.$tab["Offre"].'" role="tab" data-toggle="tab">'.$tab["Offre"].'</a></li> ';
 /*'

<!-- Tab panes -->

  <div class="tab-pane active" id="home">...</div>
  <div class="tab-pane" id="profile">...</div>
  <div class="tab-pane" id="messages">...</div>
  <div class="tab-pane" id="settings">...</div>
</div>'//*/
        }
    echo '</ul>';
    echo '<div class="tab-content">';
    foreach ($listeOffre as $indice => $nomOffre) {
       tableauImpayesParOffreDetaillee($nomOffre,$metier,$annee,$trimestre);
    }
    echo '</div>';
    


}

function tableauImpayesParOffre($metier,$annee,$trimestre){
    if ($metier=="Epargne"){
            $metierDisplay="Assurance-Vie Retraite";
        }else {$metierDisplay=$metier;}
    echo "<h3>Impayes ".$annee." du T".$trimestre." par offre du metier ".$metierDisplay.'</h3>';
    
    
    $TotalNombre=0;
    $TotalPourcentageNombre=0;
    $TotalMontant=0;
    $TotalPourcentageMontant=0;

    $l=getListeOffreImpayes($metier,$annee,$trimestre);

    echo '<table id="impayesOffre" class="table table-bordered table-striped table-hover">
          <thead>
            <tr>
              <th>Offre</th>
              <th>Operation</th>
              <th>Nombre</th>
              <th>% Nombre</th>
              <th>Montant en €</th>
              <th>% montant</th>
            </tr>
          </thead>
          <tbody>';
    foreach ($l as $key => $value) {

        $offreImpayes= new offreImpayes(array("Offre"=>$value,"Metier"=>$metier,"Annee"=>$annee,"Trimestre"=>$trimestre));

        
        //var_dump($offreImpayes->getListeOperations());
        $listeOp=$offreImpayes->getListeOperations();
        /*echo'<br><br>'.$value.' :  ';
       var_dump($listeOp);
        echo'<br><br>';//*/
        if(!empty($listeOp)){
           
            $i=0;
            $nb=0; 
            $pnb=0;
            $mt=0; 
            $pmt=0;
            foreach ( $listeOp as $k=>$operation) {
                
                echo '<tr>';
                if($i==0){ 
                    $nb=0;  //Nombre par offre
                    $pnb=0; //% nb par offre
                    $mt=0;  //montant par offre
                    $pmt=0;   //% mt par offre
                    echo '<td rowspan='.(sizeof($listeOp)+1).'>'.$value.'</td>';

                }
                echo    '
                        <td>'.$operation["Operation"].'</td>
                        <td class="eurosAdroite">'.round($operation["Nombre"],0).'</td>
                        <td class="eurosAdroite">'.($operation["PourcentageNombre"]*100).'%</td>
                        <td class="eurosAdroite">'.number_format((double) $operation["Montant"],2,',','.').' €</td>
                        <td class="eurosAdroite">'.($operation["PourcentageMontant"]*100).'%</td>';
                
                    $nb+=$operation["Nombre"];
                    $pnb+=$operation["PourcentageNombre"];
                    $mt+=$operation["Montant"];
                    $pmt+=$operation["PourcentageMontant"];



                    $TotalNombre+=$operation["Nombre"];
                    $TotalPourcentageNombre+=$operation["PourcentageNombre"];
                    $TotalMontant+=$operation["Montant"];
                    $TotalPourcentageMontant+=$operation["PourcentageMontant"];


                    $i++;
            }
            echo '</tr><tr class="info">';
            echo'   <td>Total '.$value.'</td>
                    <td class="eurosAdroite">'.$nb.'</td> 
                    <td class="eurosAdroite">'.($pnb*100).'%</td>
                    <td class="eurosAdroite">'.number_format($mt,2,',','.').' €</td> 
                    <td class="eurosAdroite">'.($pmt*100).'%</td> ';
            echo '</tr>';
        }
     


    }
     echo    '<tr><td>Total</td>
                        <td></td>
                        <td class="eurosAdroite">'. number_format($TotalNombre,0,',','.').'</td>
                        <td class="eurosAdroite">'. round($TotalPourcentageNombre*100,0).'%</td>
                        <td class="eurosAdroite">'. number_format($TotalMontant,2,',','.').'</td>
                        <td class="eurosAdroite">'. round($TotalPourcentageMontant*100,0).'%</td>
                        </tr>';
    
     echo '</tbody>';
    echo '</table>';

}



function tableauImpayesParmotifPartages($metier,$annee,$trimestre){
    echo '<h3>PARTAGES :  Répartition des impayés par MOTIF en EPARGNE et PREVOYANCE</h3>';
    global $connexion;

        
        $req = 'SELECT  CodeImpaye,
                        LibelleMotifImpaye,
                        SUM(Nombre) AS SommeNombre,
                        ((SUM(Nombre)/TotalNombre)*100) AS TotalPourcentageNombre,
                        SUM(Montant) AS SommeMontant,
                        ((SUM(Montant)/TotalMontant)*100) AS TotalPourcentageMontant 
                            FROM ImpayesDetails 
                                CROSS JOIN (SELECT SUM(Nombre) as TotalNombre ,
                                            SUM(Montant) AS TotalMontant 
                                                FROM ImpayesOperations 
                                                    WHERE Annee=:Annee 
                                                    AND trimestre=:Trimestre)
                        WHERE Annee=:Annee
                        AND Trimestre=:Trimestre
                        Group By LibelleMotifImpaye
                        ORDER BY CodeImpaye';
            
        
        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee,"Trimestre"=>$trimestre));
        

        
       

        echo '<table class="table table-bordered table-striped table-hover">
          <thead>
            <tr>
              <th>Code Impaye</th>
              <th>Libellé Motif Impayé</th>
              <th>Nombre</th>
              <th>% Nombre</th>
              <th>Montant en €</th>
              <th>% montant</th>
            </tr>
          </thead>
          <tbody>';
        

     
            
        

        while($tab = $requete->fetch()){
            echo '<tr>
                     <td>'.$tab["CodeImpaye"].'</td>
                     <td>'.utf8_encode($tab["LibelleMotifImpaye"]).'</td>
                     <td class="eurosAdroite">'.number_format($tab["SommeNombre"],0,',','.').'</td>
                     <td class="eurosAdroite">'.round($tab["TotalPourcentageNombre"],1).'%</td>
                     <td class="eurosAdroite">'.number_format($tab["SommeMontant"],2,',','.').' €</td>
                     <td class="eurosAdroite">'.round($tab["TotalPourcentageMontant"],1).'%</td>
                     </tr>';
           
        }
        echo "</tbody></table><hr>";
        
        
        

    
    }

function tableauImpayesSurPrelevementPartages($metier,$annee,$trimestre){

    echo "<h3>Taux d'impayes sur Prélèvements ".$annee." au T".$trimestre." en Epargne et Prévoyance</h3>";

    echo '<table class="table table-bordered table-striped table-hover">
      <thead>
        <tr>
          
          <th>Prélèvements</th>
          <th>Nombre</th>
          <th>% Nombre</th>
        </tr>
      </thead>
      <tbody>';

    global $connexion;
    $req= 'SELECT   SUM(Presentes)AS Presentes,
                    SUM(impayes)AS Impayes,
                    ((SUM(Impayes)/SUM(Presentes))*100) AS PImpayes, 
                    SUM(Payes) AS Payes ,
                    ((SUM(Payes)/SUM(Presentes))*100) AS PPayes
                    FROM ImpayesGeneral 
                        WHERE Annee=:Annee 
                        AND Trimestre=:Trimestre';

    $requete = $connexion->prepare($req);
    $requete->execute(array("Annee"=>$annee,"Trimestre"=>$trimestre));

    while($tab = $requete->fetch()){
        echo '<tr>
                 
                 <td>Prélèvements</td>
                 <td class="eurosAdroite">'.number_format($tab["Presentes"],0,',','.').'</td>
                 <td class="eurosAdroite">100%</td>
              </tr>
              <tr>
                 <td>Impayes</td>
                 <td class="eurosAdroite">'.number_format($tab["Impayes"],0,',','.').'</td>
                 <td class="eurosAdroite">'.round($tab["PImpayes"],1).'%</td>
              </tr>
              <tr>
                 <td>Payes</td>
                 <td class="eurosAdroite">'.number_format($tab["Payes"],0,',','.').'</td>
                 <td class="eurosAdroite">'.round($tab["PPayes"],1).'%</td>
              </tr>';
           
        }

    echo '</tbody></table>';

}

function getAnneeImpayes(){
    global $connexion;

        
        $req = "SELECT Annee FROM ImpayesGeneral GROUP BY Annee";
            
        
        $requete = $connexion->prepare($req);
        $requete->execute();
        

        
        while($tab = $requete->fetch()){
            if($tab["Annee"]!="Annee")
                $return[]=$tab["Annee"];    
        }
        
        
        return $return;
    
    }
    function getAnneeEncours(){
    global $connexion;

        
        $req = "SELECT Annee FROM EncoursCNPParOffre GROUP BY Annee";
            
        
        $requete = $connexion->prepare($req);
        $requete->execute();
        

        
        while($tab = $requete->fetch()){
            if($tab["Annee"]!="Annee")
                $return[]=$tab["Annee"];    
        }
        
        
        return $return;
    
    }



function tofloat($num) {
    $dotPos = strrpos($num, '.');
    $commaPos = strrpos($num, ',');
    $sep = (($dotPos > $commaPos) && $dotPos) ? $dotPos : 
        ((($commaPos > $dotPos) && $commaPos) ? $commaPos : false);
   
    if (!$sep) {
        return floatval(preg_replace("/[^0-9]/", "", $num));
    } 

    return floatval(
        preg_replace("/[^0-9]/", "", substr($num, 0, $sep)) . '.' .
        preg_replace("/[^0-9]/", "", substr($num, $sep+1, strlen($num)))
    );
}

function truemod($num, $mod) {
  return ($mod + ($num % $mod)) % $mod;
}

function moisPrecedent($m){
    $res=truemod(($m-1),13);
    if($res==0){$res=12;}

    return $res;
}

function moisSuivant($m){
    $res=truemod(($m+1),13);
    if($res==0){$res++;}

    return $res;
}
function afficherTitre($s){
    echo "<h2>".$s."</h2>";
}


function dernierMoisDisponible($filiale,$annee){

    global $connexion;

        
        $req = "SELECT MAX(Mois) AS Mois From IndicateursFiliales WHERE Filiale=:Filiale AND ANNEE=:Annee";
            
        
        $requete = $connexion->prepare($req);
        $requete->execute(array("Filiale"=>strtoupper($filiale),"Annee"=>$annee));
        

        
        $tab = $requete->fetch();
        $return=$tab["Mois"];    
        
        
        
        return $return;
    

}

function afficherTableauRachats($type,$annee){

    $type_rachats="";

    if($type=="totaux"){
        $req = "SELECT * FROM RachatsTotaux ORDER BY DateEffetOperation";
    }else if($type=="partiels"){
        $req = "SELECT * FROM RachatsPartiels ORDER BY DateEffetOperation";
    }

    global $connexion;

        
        
            
        
        $requete = $connexion->prepare($req);
        $requete->execute();
        

        echo '<table id="Rachats'.$type.'"class="table table-striped table-hover cell-border">
          <thead>
            <tr>
                
                <th>Centre Clientèle</th>
                <th>Numéro Contrat</th>
                <th>Numéro Proposition</th>
                <th>Libellé </th>
                <th>Date d\'Effet Opération</th>
                <th>Canal</th>
                <th>Montant Net Operation</th>
                <th>Montant Net Euro</th>
                <th>Montant Net UC</th>
                <th>Date Production CNP</th>
                <th>Délai</th>
                
                  
            </tr>
          </thead>
          <tbody>';
        

        while($tab = $requete->fetch()){

           echo ' <tr>
                
                <td>'.$tab["CentreClientele"].'</td>
                <td>'.$tab["NumeroContrat"].'</td>
                <td>'.$tab["NumeroProposition"].'</td>
                <td>'.utf8_encode($tab["LibelleLong"]).'</td>
                <td>'.$tab["DateEffetOperation"].'</td>
                <td>'.$tab["CanalOperation"].'</td>
                <td class="eurosAdroite">'.number_format((double)$tab["MontantNetOperation"],2,',','.').'€</td>
                <td class="eurosAdroite">'.number_format((double)$tab["MontantNetEuro"],2,',','.').'€</td>
                <td class="eurosAdroite">'.number_format((double)$tab["MontantNetUC"],2,',','.').'€</td>
                <td>'.$tab["DateProductionCNP"].'</td>
                <td>'.round($tab["Delai"],0).'</td>
                
                  
            </tr>';

               
        }
        
        
        echo '</tbody></table>';
    }


function derniereAnneeRachat($type){

    global $connexion;
    $type_rachats="";

    if($type=="totaux"){
         $req = "SELECT MAX(DateEffetoperation) AS DateOp from RachatsTotaux";
    }else if($type=="partiels"){
         $req = "SELECT MAX(DateEffetoperation) AS DateOp from RachatsPartiels";
    }


        
       
            
        
        $requete = $connexion->prepare($req);
        $requete->execute();
        

      

        $tab = $requete->fetch();
        //$new_date = str_replace("/", "-", $tab["DateOp"]);
        
        $var = $tab["DateOp"];
        $date = str_replace('/', '-', $var);
        return date('Y', strtotime($date));

        //echo $new_date;
        //echo date("Y",$new_date);
         
        
        
        

}
function date_mois($i){
    
    $res="";
    switch ($i) {
        case 0:
            $res="janvier";
            break;
        case 1:
            $res="janvier";
            break;
        case 2:
            $res="février";
            break;
        case 3:
            $res="mars";
            break;
        case 4:
            $res="avril";
            break;
        case 5:
            $res="mai";
            break;
        case 6:
            $res="juin";
            break;
        case 7:
            $res="juillet";
            break;
        case 8:
            $res="août";
            break;
        case 9:
            $res="septembre";
            break;
        case 10:
            $res="octobre";
            break;
        case 11:
            $res="novembre";
            break;
        case 12:
            $res="décembre";
            break;
    
    }
    return $res;   
}
function date_mois_mini($i){
    
    $res="";
    switch ($i) {
        case 0:
            $res="jan.";
            break;
        case 1:
            $res="jan.";
            break;
        case 2:
            $res="fév.";
            break;
        case 3:
            $res="mars";
            break;
        case 4:
            $res="avr.";
            break;
        case 5:
            $res="mai";
            break;
        case 6:
            $res="juin";
            break;
        case 7:
            $res="juil.";
            break;
        case 8:
            $res="août";
            break;
        case 9:
            $res="sept.";
            break;
        case 10:
            $res="oct.";
            break;
        case 11:
            $res="nov.";
            break;
        case 12:
            $res="déc.";
            break;
    
    }
    return $res;   
}



 function afficherTotauxCommissionementCNP($type,$annee,$mois){

     global $connexion;
    
    if(($type=="CNP")||($type=="LBP_Prevoyance")||($type=="Previposte")){

        $req="SELECT * FROM CommissionementCNP WHERE ANNEE=:Annee AND MOIS=:Mois ORDER BY CodeProduit";

    

    }else if($type=="Ensemble"){
        $req="SELECT * FROM CommissionementEnsemble WHERE ANNEE=:Annee AND MOIS=:Mois ORDER BY CodeProduit";
    }


        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee,"Mois"=>$mois));
        
        
   
        while($tab = $requete->fetch()){ }
            




 }

function afficherSelecteurTypeCommissionement($annee,$mois){

    extract($_GET);

    if(!isset($type)){
        $type="CNP";
    }
    echo '<form action="index.php" method="get">
            <input type="hidden" name="p" value="commissionnementCNP">
            <input type="hidden" name="annee" value="'.$annee.'">
            <input type="hidden" name="mois" value="'.$mois.'">
            <div class="btn-group">
            <button class="btn btn-default btn-'; if ($type=="CNP" ){ echo "info";}else{echo "default";} echo '" name="type" value="CNP">CNP</button >
            <button class="btn btn-default btn-'; if ($type=="LBP_Prevoyance" ){ echo "info";}else{echo "default";} echo '" name="type" value="LBP_Prevoyance">LBP Prévoyance</button >
            <button class="btn btn-default btn-'; if ($type=="Previposte" ){ echo "info";}else{echo "default";} echo '" name="type" value="Previposte">PreviPoste</button>
            <button class="btn btn-default btn-'; if ($type=="Ensemble" ){ echo "info";}else{echo "default";} echo '" name="type" value="Ensemble">Ensemble</button>
            </div></form>';


}



function afficherCommissionement($type,$annee,$mois){
    global $connexion;

    
    if(($type=="CNP")||($type=="LBP_Prevoyance")||($type=="Previposte")){
       
        $req="SELECT * FROM CommissionementCNP WHERE ANNEE=:Annee AND MOIS=:Mois AND Assureur=:Assureur ORDER BY CodeProduit";
        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee,"Mois"=>$mois,"Assureur"=>$type));
 
        echo '<table id="CommissionementCNP" class="table compact table-striped table-hover cell-border">
          <thead>


            <tr>

                
                
                <th>Code Produit</th>
                <th>Catégorie de Produits</th>
                <th>Type Mouvements</th>
                <th>Nombre de Mouvements Commissionnés</th>
                <th>Montant de l\'assiette Commissionnée</th>
                <th>Commission Versée par la CNP</th>
                <th>Commission Calculée par le CNAH</th>
                <th>Ecart de Commission</th>
                
                
                  
            </tr>
          </thead>
          <tbody>';
      

        $i=0;
        $CodeProduit=0;
        $catProd="";
        $totalNbMvmtCom=0;
        $totalMtAssiette=0;
        $totalComVersee=0;
        $totalComCalculee=0;
        $totalEcart=0;
        while($tab = $requete->fetch()){

            if(($CodeProduit!=$tab["CodeProduit"]) && ($i!=0)){
                 echo '  <tr class="info">
                    
                    <td>'.$CodeProduit.'</td>
                    <td>'.$catProd.'</td>
                    <td>Total '.$CodeProduit.'</td>
                    <td  class="eurosAdroite">'.$totalNbMvmtCom.'</td>
                    <td  class="eurosAdroite">'.number_format($totalMtAssiette,2,',','.').'</td>
                    <td  class="eurosAdroite">'.number_format($totalComVersee,2,',','.').'</td>
                    <td  class="eurosAdroite">'.number_format($totalComCalculee,2,',','.').'</td>
                    <td  class="eurosAdroite">'.$totalEcart.'</td>
                    </tr>';
                    $totalNbMvmtCom=0;
                    $totalMtAssiette=0;
                    $totalComVersee=0;
                    $totalComCalculee=0;
                    $totalEcart=0;
            }
            

            echo '  <tr>
                    
                    <td>'.$tab["CodeProduit"].'</td>
                    <td>'.$tab["CategorieProduit"].'</td>
                    <td>'.utf8_encode($tab["TypeMouvement"]).'</td>
                    <td  class="eurosAdroite">'.round($tab["NbMouvementsCommissionnes"],0).'</td>
                    <td  class="eurosAdroite">'.number_format($tab["MtAssietteCommissionnee"],2,',','.').'</td>
                    <td  class="eurosAdroite">'.number_format($tab["CommissionVerseeParLaCNP"],2,',','.').'</td>
                    <td  class="eurosAdroite">'.number_format($tab["CommissionCalculeeParLeCNAH"],2,',','.').'</td>
                    <td  class="eurosAdroite">'.$tab["EcartDeCommission"].'</td>
                    </tr>';
           
        

            $CodeProduit = $tab["CodeProduit"];
            $catProd = $tab["CategorieProduit"];
            $totalNbMvmtCom += $tab["NbMouvementsCommissionnes"];
            $totalMtAssiette += $tab["MtAssietteCommissionnee"];
            $totalComVersee += $tab["CommissionVerseeParLaCNP"];
            $totalComCalculee += $tab["CommissionCalculeeParLeCNAH"];
            $totalEcart += $tab["EcartDeCommission"];

             $i++;
        }
        echo '  <tr class="info">
                    
                    <td>'.$CodeProduit.'</td>
                    <td>'.$catProd.'</td>
                    <td>Total '.$CodeProduit.'</td>
                    <td  class="eurosAdroite">'.$totalNbMvmtCom.'</td>
                    <td  class="eurosAdroite">'.number_format($totalMtAssiette,2,',','.').'</td>
                    <td  class="eurosAdroite">'.number_format($totalComVersee,2,',','.').'</td>
                    <td  class="eurosAdroite">'.number_format($totalComCalculee,2,',','.').'</td>
                    <td  class="eurosAdroite">'.$totalEcart.'</td>
                    </tr>';
                    $totalNbMvmtCom=0;
                    $totalMtAssiette=0;
                    $totalComVersee=0;
                    $totalComCalculee=0;
                    $totalEcart=0;

        echo '</tbody></table>';

    
   }else if($type=="Ensemble"){

        $req="SELECT * FROM CommissionementEnsemble WHERE ANNEE=:Annee AND MOIS=:Mois ORDER BY Assureur";
        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee,"Mois"=>$mois));



        
        echo '<table id="CommissionementCNP" class="table cell-border compact table-striped table-hover">
          <thead>
            <tr>
                
                
                <th>Assureur</th>
                <th>Produit-Code Produit</th>
                
                <th class="eurosAdroite">Nombre de Mouvements Commissionnés</th>
                <th class="eurosAdroite">Montant de l\'assiette Commissionnée</th>
                <th class="eurosAdroite">Commission Versée par la CNP</th>
                <th class="eurosAdroite">Commission Calculée par le CNAH</th>
                <th class="eurosAdroite">Ecart de Commission</th>
                
                
                  
            </tr>
          </thead>
          <tbody>';
      

        $i=0;
        $Assureur=0;
        $catProd="";
        $totalNbMvmtCom=0;
        $totalMtAssiette=0;
        $totalComVersee=0;
        $totalComCalculee=0;
        $totalEcart=0;
        while($tab = $requete->fetch()){

            if(($Assureur!=$tab["Assureur"]) && ($i!=0)){
                 echo '  <tr class="info">
                    
                    <td>'.$Assureur.'</td>
                    <td> Total '.$Assureur.'</td>
                    
                    <td align="right">'.number_format($totalNbMvmtCom,2,',','.').'</td>
                    <td align="right">'.number_format($totalMtAssiette,2,',','.').'</td>
                    <td align="right">'.number_format($totalComVersee,2,',','.').'</td>
                    <td align="right">'.number_format($totalComCalculee,2,',','.').'</td>
                    <td align="right">'.number_format($totalEcart,2,',','.').'</td>
                    </tr>';
                    $totalNbMvmtCom=0;
                    $totalMtAssiette=0;
                    $totalComVersee=0;
                    $totalComCalculee=0;
                    $totalEcart=0;
            }
            





            echo '  <tr>
                    
                    <td>'.$tab["Assureur"].'</td>
                    <td>'.$tab["ProduitCodeproduit"].'</td>
                    
                    <td align="right">'.round($tab["NbMouvementsCommissiones"],0).'</td>
                    <td align="right">'.number_format($tab["MtAssietteCommissionee"],2,',','.').'</td>
                    <td align="right">'.number_format($tab["CommissionVerseeParLaCNP"],2,',','.').'</td>
                    <td align="right">'.number_format($tab["CommissionCalculeeparLeCNAH"],2,',','.').'</td>
                    <td align="right">'.number_format($tab["EcartDeCommission"],2,',','.').'</td>
                    </tr>';
           
        

            $Assureur = $tab["Assureur"];
            $catProd = $tab["ProduitCodeproduit"];
            $totalNbMvmtCom += $tab["NbMouvementsCommissiones"];
            $totalMtAssiette += $tab["MtAssietteCommissionee"];
            $totalComVersee += $tab["CommissionVerseeParLaCNP"];
            $totalComCalculee += $tab["CommissionCalculeeparLeCNAH"];
            $totalEcart += $tab["EcartDeCommission"];

             $i++;
        }
        echo '  <tr class="info">
                    
                    <td>'.$Assureur.'</td>
                    <td> Total '.$Assureur.'</td>
                    
                    <td align="right">'.number_format($totalNbMvmtCom,2,',','.').'</td>
                    <td align="right">'.number_format($totalMtAssiette,2,',','.').'</td>
                    <td align="right">'.number_format($totalComVersee,2,',','.').'</td>
                    <td align="right">'.number_format($totalComCalculee,2,',','.').'</td>
                    <td align="right">'.number_format($totalEcart,2,',','.').'</td>
                    </tr>';
                    $totalNbMvmtCom=0;
                    $totalMtAssiette=0;
                    $totalComVersee=0;
                    $totalComCalculee=0;
                    $totalEcart=0;

        echo '</tbody></table>';
    }
        
        

}
function afficherSelecteurAnneeCommissionement($type){
    global $connexion;
    extract($_GET);

    if(!isset($annee)){
        $annee=lastAnneeCommissionementCNP($type);
    }
    
    if(($type=="CNP")||($type=="LBP_Prevoyance")||($type=="Previposte")){

        $req="SELECT DISTINCT(annee) AS Annee FROM CommissionementCNP";

    

    }else if($type=="Ensemble"){
        $req="SELECT DISTINCT(annee) AS Annee FROM CommissionementEnsemble";
    }


        $requete = $connexion->prepare($req);
        $requete->execute();
        
        

        echo '<form method="get" action="index.php">
                <input type="hidden" name="p" value ="commissionnementCNP">
                <input type="hidden" name="type" value ="'.$type.'">

                ';


       while($tab = $requete->fetch()){
        if($annee==$tab["Annee"]){$class="info";}else{$class="default";}
        echo    '<button class="btn btn-default btn-'.$class.'" type="submit" name="annee" value="'.  $tab["Annee"] . '" > '.  $tab["Annee"] . '</button>';
       }

        
        echo '</form>';
        


}
function lastAnneeCommissionementCNP($type){
    global $connexion;
    
    if(($type=="CNP")||($type=="LBP_Prevoyance")||($type=="Previposte")){

        $req="SELECT MAX(annee) AS Annee FROM CommissionementCNP";

    

    }else if($type=="Ensemble"){
        $req="SELECT MAX(annee) AS Annee FROM CommissionementEnsemble";
    }


        $requete = $connexion->prepare($req);
        $requete->execute();
        
        
        $tab = $requete->fetch();
      
      return $tab["Annee"];


}
function afficherSelecteurMoisCommissionement($type,$annee){
    global $connexion;
    extract ($_GET);
    if(!isset($mois)){
        $mois=1;
    }
    
    if(($type=="CNP")||($type=="LBP_Prevoyance")||($type=="Previposte")){

        $req="SELECT DISTINCT(Mois) AS Mois FROM CommissionementCNP WHERE Annee=:Annee" ;

    

    }else if($type=="Ensemble"){
        $req="SELECT DISTINCT(Mois) AS Mois FROM CommissionementEnsemble WHERE Annee=:Annee";
    }


        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee));
        
        

        echo '<form method="get" action="index.php">
                <input type="hidden" name="p" value ="commissionnementCNP">
                <input type="hidden" name="type" value ="'.$type.'">
                <input type="hidden" name="annee" value ="'.$annee.'">

                <div class="btn-group">';


       while($tab = $requete->fetch()){
        if($mois==$tab["Mois"]){$class="info";}else{$class="default";}
        echo    '<button class="btn btn-'.$class.'" type="submit" name="mois" value="'.  $tab["Mois"] . '" > '.  $tab["Mois"] . '</button>';
       }

        
        echo '</div></form><hr>';
        


}

function tableauEncoursParOffre($metier,$annee,$mois){

    echo '<h3>Encours par offre du métier '.$metier.' au '.$mois.'/'.$annee.'</h3><br>';

    global $connexion;
    $req = "SELECT * FROM EncoursCNPParOffre WHERE Domaine=:Domaine AND Annee=:Annee AND Mois=:Mois" ; 
    $requete = $connexion->prepare($req);
    $requete->execute(array("Annee"=>$annee,"Mois"=>$mois,"Domaine"=>strtoupper($metier)));


        echo '<table id="EncoursParOffre"class="table table-striped cell-border table-hover">
          <thead>
            <tr>
                
                

                <th class="hidden">Offre</th>   
                <th>Libellé de l\'offre</th>
                <th>Encours POINTS</th>   
                <th>Encours EUROS</th>
                <th>Encours UC</th>   
                <th>Encours TOTAL</th>
                <th>Nb Contrats</th>  
                <th>Part EURO</th>
                <th>Part UC</th>
            </tr>
          </thead>
          <tbody>';

          while($tab=$requete->fetch()){

            echo '<tr>
                            
                            
                            
                            <td class="hidden">'.$tab["Offre"].'</td>   
                            <td>'.utf8_encode($tab["LibelleOffre"]).'</td>
                            <td class="eurosAdroite">'.number_format($tab["EncoursPOINTS"],3,',','.').'</td>   
                            <td class="eurosAdroite">'.number_format($tab["EncoursEUROS"],0,',','.').'</td>
                            <td class="eurosAdroite">'.number_format($tab["EncoursUC"],0,',','.').'</td>   
                            <td class="eurosAdroite">'.number_format($tab["EncoursTOTAL"],0,',','.').'</td>
                            <td class="eurosAdroite">'.number_format($tab["NbContrats"],0,',','.').'</td>  
                            <td class="eurosAdroite">'.number_format($tab["PartEURO"],2,',','.').'</td>
                            <td class="eurosAdroite">'.number_format($tab["PartUC"],2,',','.').'</td>
                        </tr>'; 

          }

          echo '</tbody></table><hr>';

}

function tableauEncoursParOffreGroupee($metier,$annee,$mois){
    echo '<h3>Encours groupés par offre  du métier '.$metier.' au '.$mois.'/'.$annee.'</h3><br>';
    global $connexion;
    global $caseRequeteEnCoursGroupeeparOffre;
    $req = 'SELECT  SUM(NbContrats)AS TotalNbContrats, *,
                    SUM(EncoursPOINTS) AS TotalEncoursPOINTS,
                    SUM(EncoursEUROS) AS TotalEncoursEUROS,
                    SUM(EncoursUC) AS TotalEncoursUC,
                    SUM(EncoursTOTAL) AS TotalEncoursTOTAL,  '.$caseRequeteEnCoursGroupeeparOffre.'

    

                                                         AS ValeurGroupees 

                    FROM EncoursCNPParOffre WHERE Domaine=:Domaine AND Annee=:Annee AND Mois=:Mois

                    GROUP BY 
                   '.$caseRequeteEnCoursGroupeeparOffre.'

                    ORDER BY ValeurGroupees' ; 
    $requete = $connexion->prepare($req);
    $requete->execute(array("Annee"=>$annee,"Mois"=>$mois,"Domaine"=>strtoupper($metier)));


        echo '<table id="EncoursParOffreGroupee"class="table cell-border table-striped table-hover">
          <thead>
            <tr>
                
                

                  
                <th>Libellé de l\'offre</th>
                <th class="eurosAdroite">Encours POINTS</th>   
                <th class="eurosAdroite">Encours EUROS</th>
                <th class="eurosAdroite">Encours UC</th>   
                <th class="eurosAdroite">Encours TOTAL</th>
                <th class="eurosAdroite">Nb Contrats</th>  
                <th class="eurosAdroite">Part EURO</th>
                <th class="eurosAdroite">Part UC</th>
            </tr>
          </thead>
          <tbody>';

          while($tab=$requete->fetch()){

            echo '<tr>
                            
                            
                            
                            
                            <td>'.($tab["ValeurGroupees"]).'</td>
                            <td class="eurosAdroite">'.number_format($tab["TotalEncoursPOINTS"],2,',','.').'</td>   
                            <td class="eurosAdroite">'.number_format($tab["TotalEncoursEUROS"],2,',','.').'</td>
                            <td class="eurosAdroite">'.number_format($tab["TotalEncoursUC"],2,',','.').'</td>   
                            <td class="eurosAdroite">'.number_format($tab["TotalEncoursTOTAL"],2,',','.').'</td>
                            <td class="eurosAdroite">'.number_format($tab["TotalNbContrats"],2,',','.').'</td>  
                            <td class="eurosAdroite">'.number_format($tab["PartEURO"],2,',','.').'</td>
                            <td class="eurosAdroite">'.number_format($tab["PartUC"],2,',','.').'</td>
                        </tr>'; 
          }

          echo '</tbody></table><hr>';

}


function tableauEncoursParProduit($metier,$annee,$mois){

    echo '<h3>Encours  par produit du métier '.$metier.' au '.$mois.'/'.$annee.'</h3><br>';
      global $connexion;
      $req = "SELECT * FROM EncoursCNPParProduit WHERE Domaine=:Domaine AND Annee=:Annee AND Mois=:Mois" ;
      $requete = $connexion->prepare($req);
      $requete->execute(array("Annee"=>$annee,"Mois"=>$mois,"Domaine"=>strtoupper($metier)));


        echo '<table id="EncoursParOffre"class="table cell-border table-striped table-hover">
          <thead>
            <tr>
                
                
                
                
                <th>CategorieProduit</th>
                <th>EncoursPOINTS</th>
                <th>EncoursEUROS</th>
                <th>EncoursUC</th>
                <th>EncoursTOTAL</th>
                <th>NbContrats</th>
                <th>PartEURO</th>
                <th>PartUC</th>


            
                
                  
            </tr>
          </thead>
          <tbody>';

          while($tab=$requete->fetch()){

            echo '<tr>
                    
                    <td>'.$tab["categorieproduit"].'</td>
                    <td class="eurosAdroite">'.$tab["encourspoints"].'</td>
                    <td class="eurosAdroite">'.number_format($tab["encourseuros"],0,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["encoursuc"],0,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["encourstotal"],0,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["nbcontrats"],0,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["parteuro"],2,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["partuc"],2,',','.').'</td>
                </tr>

            ';

          }
          echo '</tbody></table><hr>';
}
function tableauEncoursParProduitGroupes($metier,$annee,$mois){

    echo '<h3>Encours groupés par produit  du métier '.$metier.' au '.$mois.'/'.$annee.'</h3><br>';
      global $connexion;
      global $caseRequeteEnCoursGroupeeParProduit;
     // $req = "SELECT * FROM EncoursCNPParProduit WHERE Domaine=:Domaine AND Annee=:Annee AND Mois=:Mois" ;


        $req = 'SELECT  SUM(NbContrats)AS TotalNbContrats, *,
                    SUM(EncoursPOINTS) AS TotalEncoursPOINTS,
                    SUM(EncoursEUROS) AS TotalEncoursEUROS,
                    SUM(EncoursUC) AS TotalEncoursUC,
                    SUM(EncoursTOTAL) AS TotalEncoursTOTAL,  '.$caseRequeteEnCoursGroupeeParProduit.'

    

                                                         AS ValeurGroupees 

                    FROM EncoursCNPParProduit WHERE Domaine=:Domaine AND Annee=:Annee AND Mois=:Mois

                    GROUP BY 
                   '.$caseRequeteEnCoursGroupeeParProduit.'

                    ORDER BY ValeurGroupees' ; 



      $requete = $connexion->prepare($req);
      $requete->execute(array("Annee"=>$annee,"Mois"=>$mois,"Domaine"=>strtoupper($metier)));


        echo '<table id="EncoursParOffreGroupee" class="table cell-border table-striped table-hover">
          <thead>
            <tr>
                <th>CategorieProduit</th>
                <th>EncoursPOINTS</th>
                <th>EncoursEUROS</th>
                <th>EncoursUC</th>
                <th>EncoursTOTAL</th>
                <th>NbContrats</th>
                <th>PartEURO</th>
                <th>PartUC</th>
            </tr>
          </thead>
          <tbody>';

          while($tab=$requete->fetch()){

            echo '<tr>
                    
                    <td>'.$tab["ValeurGroupees"].'</td>
                    <td class="eurosAdroite">'.number_format($tab["TotalEncoursPOINTS"],0,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["TotalEncoursEUROS"],0,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["TotalEncoursUC"],0,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["TotalEncoursTOTAL"],0,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["TotalNbContrats"],0,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["parteuro"],2,',','.').'</td>
                    <td class="eurosAdroite">'.number_format($tab["partuc"],2,',','.').'</td>
                </tr>

            ';

          }
          echo '</tbody></table>';
}

function tableauEncoursParSupport($metier,$annee,$mois){
    echo 'Encours  par support  du métier '.$metier.' au '.$mois.'/'.$annee.'<br>';
      global $connexion;
      $req = "SELECT * FROM EncoursCNPParSupport WHERE Annee=:Annee AND Mois=:Mois" ;
      $requete = $connexion->prepare($req);
      $requete->execute(array("Annee"=>$annee,"Mois"=>$mois));


        echo '<table id="EncoursParSupport" class="cell-border table table-striped table-hover">
          <thead>
            <tr>
                <th>Support</th>
                <th>Libellé Support</th>
                <th>Encours</th>
            </tr>
          </thead>
          <tbody>';

          while($tab=$requete->fetch()){
            echo'
                <tr>
                    <td>'.$tab["Support"].'</td>
                    <td>'.utf8_encode($tab["LibelleSupport"]).'</td>
                    <td class="eurosAdroite">'.number_format($tab["Encours"],0,',','.').'</td>
                </tr>';

          }
          echo '</tbody></table>';
}

function tableauEncoursParSupportGroupee($metier,$annee,$mois){
    echo 'Encours groupés par support  du métier '.$metier.' au '.$mois.'/'.$annee.'<br>';
      global $connexion;
      $req = "SELECT * FROM EncoursCNPParSupport WHERE Annee=:Annee AND Mois=:Mois" ;
      $requete = $connexion->prepare($req);
      $requete->execute(array("Annee"=>$annee,"Mois"=>$mois));


        echo '<table id="EncoursParSupport" class="table table-striped table-hover">
          <thead>
            <tr>
                
                
                
                
                <th>Support</th>
                <th>Libellé Support</th>
                <th>Encours</th>
                
                
                
                  
            </tr>
          </thead>
          <tbody>';

          while($tab=$requete->fetch()){
            echo'
                <tr>
                    <td>'.$tab["Support"].'</td>
                    <td>'.$tab["LibelleSupport"].'</td>
                    <td>'.$tab["Encours"].'</td>
                </tr>';

          }
          echo '</tbody></table>';
}

function afficherSelecteurMoisEncours($metier,$annee){
    global $connexion;
    
    

        $req="SELECT DISTINCT(Mois) AS Mois FROM EncoursCNPParOffre WHERE Annee=:Annee" ;

    

        if(isset($_GET["type"])){
            $type=$_GET["type"];
        }else{
            $type="parOffre";
        }  if(isset($_GET["mois"])){
            $mois=$_GET["mois"];
        }else{
            $mois=1;
        }
      

        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee));
        
        

        echo '<form method="get" action="index.php">
                <input type="hidden" name="p" value ="enCours">
                <input type="hidden" name="type" value ="'.$type.'">
                <input type="hidden" name="annee" value ="'.$annee.'">
                <input type="hidden" name="metier" value ="'.$metier.'">

                ';

                echo '<div class="btn-group">';
       while($tab = $requete->fetch()){
        if($mois==$tab["Mois"]){$info="info";}else{$info="default";}
        echo    '<button class="btn btn-'.$info.'" type="submit" name="mois" value="'.  $tab["Mois"] . '" > '.  $tab["Mois"] . '</button>';
       }

        
        echo '</div></form>';
        


}


function verificationBaseAJour(){
    global $connexion;

    $req='SELECT Valeur FROM InfosDiverses WHERE Variable="PlusVieuxFichierImporte"';
    $requete = $connexion->prepare($req);
    $requete->execute();

    $tab = $requete->fetch();


    $listeFichier = scandir ( "C:/xampp/Exports"  );
    
    $plusvieux=$tab["Valeur"];
    $Nouvelledate="";
    $fichier="";
    $listeFichierAMettreAJour=array();
    
    foreach ($listeFichier as $key => $filename) {
        $filenameComplet='C:/xampp/Exports/'.$filename;
        
        
        
        if ((file_exists($filenameComplet))&&$key>1) {

            

            if (date ("F d Y H:i:s.", filemtime($filenameComplet)) >= $plusvieux){

                $Nouvelledate = date ("F d Y H:i:s.", filemtime($filenameComplet));
                $fichier=$filename;
                $listeFichierAMettreAJour[]=$filename;
                
            }
        }
        # code...
    }

    //echo 'Le fichier le plus vieux est '.$fichier;

    

    if($tab["Valeur"]<$Nouvelledate){
        //echo 'Il y a des nouveaux fichiers à importer';
        
        //var_dump($listeFichierAMettreAJour);
        //miseAJourFichiers($listeFichierAMettreAJour);

        $req='UPDATE InfosDiverses SET Valeur = :NValeur WHERE Variable="PlusVieuxFichierImporte"';
        $requete = $connexion->prepare($req);
        $requete->execute(array("NValeur"=>$Nouvelledate));
        /*$tab = $requete->fetch();*/

    }else{
        //echo 'Tous les fichiers sont à jours.';
    }
    


}

function miseAJourFichiers($listeFichierAMettreAJour){
    global $connexion;
    //echo '<br> les fichiers à mettre à jour sont: <br>';
    foreach ($listeFichierAMettreAJour as $key => $value) {
       // echo $value.'<br>';
        $table= preg_replace('/\.[^.]+$/','',$value);
        //import_csv_to_sqlite($connexion,'D:\Documents and Settings\vytg315\Mes documents\dev\\'.$value,array("table"=>$table,"fields"=>getFields($value)));       # code...
        //import_csv_to_sqlite($dbh,'D:\Documents and Settings\vytg315\Mes documents\exportCSV_BDD1\\'.$value,array("table"=>$table,"fields"=>getFields($value)));      # code...
        //import_csv_to_sqlite($dbh,'O:\_ASSURANCE\_RISQUES_ASSURANCE\ARCAD\BDD\\'.$value,array("table"=>$table,"fields"=>getFields($value)));      # code...
        import_csv_to_sqlite($connexion,'C:\xampp\Exports\\'.$value,array("table"=>$table,"fields"=>getFields($value)));      # code..
        
    }
}

function getFields($value){
        

        $fields_ListeFiliales = array(  "Nom",
                                        "ID_Filiale",
                                        "nom_slug");

        $fields_ImpayesDetails = array( "Annee",
                                        "Trimestre",
                                        "Metier",
                                        "ID_Offre",
                                        "Offre",
                                        "CodeImpaye",
                                        "LibelleMotifImpaye",
                                        "Nombre",
                                        "PourcentageNombre",
                                        "Montant",
                                        "PourcentageMontant");

        $fields_ImpayesOffre = array(   "Annee",
                                        "Trimestre",
                                        "ID_Metier",
                                        "Metier",
                                        "ID_Offre",
                                        "Offre",
                                        "Presentes",
                                        "Impayes",
                                        "Payes");

        $fields_ImpayesOperations=array("Annee",
                                        "Trimestre",
                                        "ID_Metier",
                                        "Metier",
                                        "ID_Offre",
                                        "Offre",
                                        "Operation",
                                        "Nombre",
                                        "PourcentageNombre",
                                        "Montant",
                                        "PourcentageMontant");

        $fields_ImpayesGeneral = array( "Annee",
                                        "Trimestre",
                                        "ID_Metier",
                                        "Metier",
                                        "nom_slug",
                                        "Presentes",
                                        "Impayes",
                                        "Payes");

        $fields_RachatsPartiels = array("ID_Filiale",
                                        "CentreClientele",
                                        "NumeroContrat",
                                        "NumeroProposition",
                                        "LibelleLong",
                                        "DateEffetOperation",
                                        "CanalOperation",
                                        "MontantNetOperation",
                                        "MontantNetEuro",
                                        "MontantNetUC",
                                        "DateProductionCNP",
                                        "Delai",
                                        "Source");

        $fields_RachatsTotaux = array(  "ID_Filiale",
                                        "CentreClientele",
                                        "NumeroContrat",
                                        "NumeroProposition",
                                        "LibelleLong",
                                        "DateEffetOperation",
                                        "CanalOperation",
                                        "MontantNetOperation",
                                        "MontantNetEuro",
                                        "MontantNetUC",
                                        "DateProductionCNP",
                                        "Delai",
                                        "Source");

        $fields_IndicateursFiliales =array( "ID_Filiale",
                                        "Filiale",
                                        "Annee",
                                        "Mois",
                                        "ChiffresAffaires",
                                        "CommissionsDeCourtage",
                                        "ParticipationAuxBenefices",
                                        "PrimesAcquises",
                                        "Sinistres",
                                        "CommissionsApporteurs",
                                        "Reassurance",
                                        "ResultatFinancier", 
                                        "ProduitNetAssurance",
                                        "ProduitNetBancaire",
                                        "CoutDuRisque",
                                        "ResultatExploitation",
                                        "ResultatNet",
                                        "ResultatNetParDuGroupe",
                                        "Charges",
                                        "ResultatBrutExploitation",
                                        "CoefficientExploitation",
                                        "Effectifs",
                                        "MeeDeCNP",
                                        "RatioSinistresSurPrimes",
                                        "RatioSsurPMoinsCumul",
                                        "Source");

    $fields_IndicateursProduits = array("Filiale",
                                        "Produit",
                                        "ID_Produit",
                                        "Mois",
                                        "Annee",
                                        "ChiffresAffaires",
                                        "AffairesNouvelles",
                                        "SortieDeContrats",
                                        "ProductionNette",
                                        "Portefeuille",
                                        "SinistreSurPrime",
                                        "Source");

    $fields_CanalSouscription = array(  "ID_Filiale",
                                        "Filiale",
                                        "Annee",
                                        "Mois",
                                        "CentresFinanciers",
                                        "Enseigne",
                                        "Telephone",
                                        "Internet",
                                        "Source");

    $fields_PerformanceRendement= array("ID_Filiale",
                                        "Filiale",
                                        "Annee",
                                        "Mois",
                                        "Indicateur",
                                        "Performance",
                                        "Rendement",
                                        "Benchmark",
                                        "PVLatentes",
                                        "Source",
                                        );
    $fields_CommissionementEnsemble= array("Annee",
                                            "Mois",
                                            "Assureur",
                                            "ProduitCodeProduit",
                                            "NbMouvementsCommissiones",
                                            "MtAssietteCommissionee",
                                            "CommissionVerseeParLaCNP",
                                            "CommissionCalculeeParLeCNAH",
                                            "EcartDeCommission"
                                );
    $fields_CommissionementCNP= array(      "Annee",
                                            "Mois",
                                            "Assureur",
                                            "CodeProduit",
                                            "CategorieProduit",
                                            "TypeMouvement",
                                            "NbMouvementsCommissionnes",
                                            "MtAssietteCommissionnee",
                                            "CommissionVerseeParLaCNP",
                                            "CommissionCalculeeParLeCNAH",
                                            "EcartDeCommission"
                                );

    $fields_EnCoursCNPParOffre= array(  "Annee",
                                        "Mois",
                                        "Domaine",
                                        "Offre",
                                        "LibelleOffre",
                                        "EncoursPOINTS",
                                        "EncoursEUROS",
                                        "EncoursUC",
                                        "EncoursTOTAL",
                                        "NbContrats",   
                                        "PartEURO", 
                                        "PartUC"
                                );

    $fields_EnCoursCNPParSupport= array("Annee",
                                        "Mois",
                                        "Support",
                                        "LibbelleSupport",
                                        "Encours"
                                );


    if     (preg_match('/IndicateursFiliales/',$value)) { return $fields_IndicateursFiliales;}
    elseif (preg_match('/Filiales/',$value))        { return $fields_ListeFiliales;}
    
    elseif (preg_match('/IndicateursProduits/',$value)) { return $fields_IndicateursProduits;}
    elseif (preg_match('/CommissionementEnsemble/',$value)) { return $fields_CommissionementEnsemble;}
    elseif (preg_match('/CommissionementCNP/',$value)) { return $fields_CommissionementCNP;}
    elseif (preg_match('/CanalSouscription/',$value))   { return $fields_CanalSouscription;}
    elseif (preg_match('/PerformanceRendement/',$value)){ return $fields_PerformanceRendement;}
    elseif (preg_match('/RachatsPartiels/',$value))     { return $fields_RachatsPartiels;}
    elseif (preg_match('/RachatsTotaux/',$value))       { return $fields_RachatsTotaux;}
    elseif (preg_match('/EnCoursCNPParOffre/',$value))  { return $fields_EnCoursCNPParOffre;}
    elseif (preg_match('/ImpayesOffre/',$value))        { return $fields_ImpayesOffre;      }
    elseif (preg_match('/ImpayesGeneral/',$value))      { return $fields_ImpayesGeneral;        }
    elseif (preg_match('/ImpayesDetails/',$value))      { return $fields_ImpayesDetails;        }
    elseif (preg_match('/ImpayesOperations/',$value))   { return $fields_ImpayesOperations;}
    else{
        echo "Erreur de reconnaissance du nom du fichier : ".$value."<br>";
    }
}

function import_csv_to_sqlite(&$pdo, $csv_path, $options = array())
{

    extract($options);
    
    if (($csv_handle = fopen($csv_path, "r")) === FALSE)
        throw new Exception('Cannot open CSV file');
        
    if(!(isset($delimiter)))
        $delimiter = ',';
        
    if(!(isset($table)))
        $table = preg_replace("/[^A-Z0-9]/i", '', basename($csv_path));
    
    if(!(isset($fields))){
        $fields = array_map(function ($field){
            return strtolower(preg_replace("/[^A-Z0-9]/i", '', $field));
        }, fgetcsv($csv_handle, 0, $delimiter));
    }
    
    $create_fields_str = join(', ', array_map(function ($field){
        return "$field TEXT NULL";
    }, $fields));
    //echo $table."<br>";
    //var_dump($fields);
    $pdo->beginTransaction();
    
    $create_table_sql = "CREATE TABLE IF NOT EXISTS $table ($create_fields_str)";
    $pdo->exec($create_table_sql);
 

    $insert_fields_str = join(', ', $fields);
    $insert_values_str = join(', ', array_fill(0, count($fields),  '?'));
    $insert_sql = "INSERT INTO $table ($insert_fields_str) VALUES ($insert_values_str)";
    $insert_sth = $pdo->prepare($insert_sql);
    
    //echo $insert_sql."<br>";
    
    $inserted_rows = 0;
    //var_dump(fgetcsv($csv_handle, 0, $delimiter));
    while (($data = fgetcsv($csv_handle, 0, $delimiter)) !== FALSE) {
    //var_dump( $data);
    //echo "<br><br>";
        try{
            $insert_sth->execute($data);
            $inserted_rows++;
        }catch(PDOException $e){;}
        
    }//*/
    
    $pdo->commit();
    
    fclose($csv_handle);
    

    return array(
            'table' => $table,
            'fields' => $fields,
            'insert' => $insert_sth,
            'inserted_rows' => $inserted_rows
        );
 
} 


function SelecteurAnneeFReporting($cumul,$annee,$mois,$metier){
      global $connexion;
    
    

        $req="SELECT DISTINCT(Annee) AS Annee FROM FreportingObsCA " ;

    

       
      

        $requete = $connexion->prepare($req);
        $requete->execute();
        
        

        echo '<form method="get" action="index.php">
                <input type="hidden" name="p" value ="freporting">
                <input type="hidden" name="cumul" value ="'.$cumul.'">
                <input type="hidden" name="mois" value ="'.$mois.'">
                <input type="hidden" name="metier" value ="'.$metier.'">
                

                ';
        while($tab = $requete->fetch()){
            if($annee==$tab["Annee"]){$class="info";}else{$class="default";}
        echo    '<button class="btn btn-'.$class.'" type="submit" name="annee" value="'.  $tab["Annee"] . '" > '.  $tab["Annee"] . '</button>';
       }
        echo '</form>';

}
function SelecteurMoisFReporting($cumul,$annee,$mois,$metier){
    global $connexion;
    
    

        $req="SELECT DISTINCT(Mois) AS Mois FROM FreportingObsCA WHERE Annee=:Annee" ;

    

       
      

        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee));
        
        

        echo '<form method="get" action="index.php">
                <input type="hidden" name="p" value ="freporting">
                <input type="hidden" name="cumul" value ="'.$cumul.'">
                <input type="hidden" name="annee" value ="'.$annee.'">
                <input type="hidden" name="metier" value ="'.$metier.'">
                

                ';
        while($tab = $requete->fetch()){
             if($mois==$tab["Mois"]){$class="info";}else{$class="default";}
        echo    '<button class="btn btn-'.$class.'" type="submit" name="mois" value="'.  $tab["Mois"] . '" > '.  $tab["Mois"] . '</button>';
       }
        echo '</form>';

}
function SelecteurMetierFReporting($cumul,$annee,$mois,$metier){
    global $connexion;
    
    

        $req="SELECT DISTINCT(METIER) AS Metier FROM FreportingObsCA WHERE Annee=:Annee AND Mois=:Mois" ;

    

       
      

        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee,"Mois"=>$mois));
        
        

        echo '<form method="get" action="index.php">
                <input type="hidden" name="p" value ="freporting">
                <input type="hidden" name="cumul" value ="'.$cumul.'">
                <input type="hidden" name="annee" value ="'.$annee.'">
                <input type="hidden" name="mois" value ="'.$mois.'">
                

                ';
        while($tab = $requete->fetch()){
             if($metier==$tab["Metier"]){$class="info";}else{$class="default";}
        echo    '<button class="btn btn-'.$class.'" type="submit" name="metier" value="'.  $tab["Metier"] . '" > '.  $tab["Metier"] . '</button>';
       }
        echo '</form>';

}
function SelecteurCumulReporting($cumul,$annee,$mois,$metier){
    global $connexion;
    
    

        $req='SELECT DISTINCT(Cumul) AS Cumul FROM FreportingObsCA WHERE Annee=:Annee AND Mois=:Mois' ;

    

       
      

        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee,"Mois"=>$mois));
        
        

        echo '<form method="get" action="index.php">
                <input type="hidden" name="p" value ="freporting">
                <input type="hidden" name="metier" value ="'.$metier.'">
                <input type="hidden" name="annee" value ="'.$annee.'">
                <input type="hidden" name="mois" value ="'.$mois.'">
                

                ';
        while($tab = $requete->fetch()){
            if($tab["Cumul"]==1){
                $cumuls="Cumulé";
            }if($tab["Cumul"]==0){
                $cumuls="Non Cumulé";             
            }
            if($cumul==$tab["Cumul"]){$class="info";}else{$class="default";}
        echo    '<button class="btn btn-'.$class.'" type="submit" name="cumul" value="'. $tab["Cumul"] . '" > '.  $cumuls . '</button>';
       }
        echo '</form>';

}

function AfficherTableauFReportingCA($cumul,$annee,$mois,$metier){
    if($cumul==1){
                $cumulString="Cumulée";
            }if($cumul==0){
                $cumulString="Mensuelles ";             
            }
    echo 'Chiffres d\'Affaires Données '.$cumulString.' '.$metier.' au '.$mois.'/'.$annee.'<br>';

    global $connexion;
    $req = "SELECT * FROM FreportingObsCA WHERE Metier=:Metier AND Annee=:Annee AND Mois=:Mois AND CUMUL=:Cumul 

        ORDER BY CASE WHEN Part = 'Euros' THEN 0 
              WHEN Part = 'UC' THEN 1 
              WHEN Part = 'Euros_UC' THEN 2 END, Part,Offre" ; 
    $requete = $connexion->prepare($req);
    $requete->execute(array("Annee"=>$annee,"Mois"=>$mois,"Cumul"=>$cumul,"Metier"=>strtoupper($metier)));


        echo '<table id="reportingParOffre"class="table compact cell-border  table-striped table-hover">
          <thead>
            <tr>
                
                
                
                <th>Part</th>    
                <th>Offre</th>   
                <th>Affaires Nouvelles Hors Partages</th>   
                <th>Affaires Nouvelles Partages</th>   
                <th>Redress. Affaires Nouvelles</th>    
                <th>Renonciation Tous Canaux</th>  
                <th>Sans Effet, Sans Suite Hors Partages</th>  
                <th>TOTAL Affaires Nouvelles</th>  
               


                
            </tr>
          </thead>
          <tbody>';

          while($tab=$requete->fetch()){
            if($tab["Part"]=="Euros_UC"){
                $tab["Part"]="UC + €";
                $class="";
            }
             if($tab["Part"]=="UC"){
                $class="info";
            }
             if($tab["Part"]=="Euros"){
                $class="success";
            }
             if($tab["Offre"]!="Total"){
                $tab["Offre"]='<span style="display:none">_</span>'. $tab["Offre"];
                $gras="";
            }else{
                $tab["Offre"]= $tab["Offre"];
                $gras='style="font-weight: 800 !important"';
            }
            echo '<tr '.$gras.'>
                            
                            
                            
                            <td class='.$class.'>'.$tab["Part"].'</td>    
                            <td class='.$class.'>'.$tab["Offre"].'</td>   
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["AffairesNouvellesHorsPartages"],0,',','.').'</td>   
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["AffairesNouvellesPartages"],0,',','.').'</td>   
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["RedressAffairesNouvelles"],0,',','.').'</td>    
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["RenonciationTousCanaux"],0,',','.').'</td>  
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["SansEffetSansSuiteHorsPartages"],0,',','.').'</td>  
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["TOTALAffairesNouvelles"],0,',','.').'</td>  

                        </tr>';

          }

          echo '</tbody></table><hr>';

}
function AfficherTableauFReportingCAVersements($cumul,$annee,$mois,$metier){
    if($cumul==1){
                $cumulString="Cumulée";
            }if($cumul==0){
                $cumulString="Mensuelles ";             
            }
    echo '<h3>Chiffres d\'Affaires/Versements Données '.$cumulString.' '.$metier.' au '.$mois.'/'.$annee.'</h3><br>';

    global $connexion;
    $req = "SELECT * FROM FreportingObsCA WHERE Metier=:Metier AND Annee=:Annee AND Mois=:Mois AND CUMUL=:Cumul 

        ORDER BY CASE WHEN Part = 'Euros' THEN 0 
              WHEN Part = 'UC' THEN 1 
              WHEN Part = 'Euros_UC' THEN 2 END, Part,Offre" ; 
    $requete = $connexion->prepare($req);
    $requete->execute(array("Annee"=>$annee,"Mois"=>$mois,"Cumul"=>$cumul,"Metier"=>strtoupper($metier)));


        echo '<table id="reportingParOffreVersements" class="table compact cell-border  table-striped table-hover">
          <thead>
            <tr>
                
                
                
                <th>Part</th>    
                <th>Offre</th>   
                <th>Versement Libre Hors Partages</th>  
                <th>Versement Libre Partages</th>  
                <th>Redress Versements Libres</th> 
                <th>TOTAL Versements Libres</th>   
                <th>Versements Reguliers Hors Partages</th> 
                <th>Redress Versements Reguliers Hors Partages</th>  
                <th>TOTAL Versements Reguliers</th>    
                <th>CA Brut TOTAL</th> 
                <th>dont UC Temp</th>  
                <th>dont UC Perm</th>


                
            </tr>
          </thead>
          <tbody>';

          while($tab=$requete->fetch()){
            if($tab["Part"]=="Euros_UC"){
                $tab["Part"]="UC + €";
                $class="";
            }
             if($tab["Part"]=="UC"){
                $class="info";
            }
             if($tab["Part"]=="Euros"){
                $class="success";
            }
            
            echo '<tr>
                            
                            
                            
                            <td class='.$class.'>'.$tab["Part"].'</td>    
                            <td class='.$class.'>'.$tab["Offre"].'</td>   
  
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["VersementLibreHorsPartages"],0,',','.').'</td>  
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["VersementLibrePartages"],0,',','.').'</td>  
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["RedressVersementsLibres"],0,',','.').'</td> 
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["TOTALVersementsLibres"],0,',','.').'</td>   
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["VersementsReguliersHorsPartages"],0,',','.').'</td> 
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["RedressVersementsReguliersHorsPartages"],0,',','.').'</td>  
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["TOTALVersementsReguliers"],0,',','.').'</td>    
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["CABrutTOTAL"],0,',','.').'</td> 
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["dontUCTemp"],2,',','.').'</td>  
                            <td class="eurosAdroite '.$class.'">'.number_format((double)$tab["dontUCPerm"],2,',','.').'</td>
                        </tr>';

          }

          echo '</tbody></table>';
}

function AfficherTableauFReportingSC($cumul,$annee,$mois,$metier){
    if($cumul==1){
                $cumulString="Cumulée";
            }if($cumul==0){
                $cumulString="Mensuelles ";             
            }

    echo '<h3>Sorties de Capitaux / Affaires Nouvelles: Données '.$cumulString.' '.$metier.' au '.$mois.'/'.$annee.'</h3><br>';

    global $connexion;
    $req = "SELECT * FROM FreportingObsCA WHERE Metier=:Metier AND Annee=:Annee AND Mois=:Mois AND CUMUL=:Cumul" ; 
    $requete = $connexion->prepare($req);
    $requete->execute(array("Annee"=>$annee,"Mois"=>$mois,"Cumul"=>$cumul,"Metier"=>strtoupper($metier)));


        echo '<table id="reportingParOffre" class="table cell-border table-striped table-hover">
          <thead>
            <tr>
                
                
                
                <th>Part</th>    
                <th>Offre</th>   
                <th>Affaires Nouvelles Hors Partages</th>   
                <th>Affaires Nouvelles Partages</th>   
                <th>Redress. Affaires Nouvelles</th>    
                <th>Renonciation Tous Canaux</th>  
                <th>Sans Effet, Sans Suite Hors Partages</th>  
                <th>TOTAL Affaires Nouvelles</th>  



                
            </tr>
          </thead>
          <tbody>';

          while($tab=$requete->fetch()){

            echo '<tr>
                            
                            
                            
                            <td>'.$tab["Part"].'</td>    
                            <td>'.$tab["Offre"].'</td>   
                            <td>'.$tab["AffairesNouvellesHorsPartages"].'</td>   
                            <td>'.$tab["AffairesNouvellesPartages"].'</td>   
                            <td>'.$tab["RedressAffairesNouvelles"].'</td>    
                            <td>'.$tab["RenonciationTousCanaux"].'</td>  
                            <td>'.$tab["SansEffetSansSuiteHorsPartages"].'</td>  
                            <td>'.$tab["TOTALAffairesNouvelles"].'</td>  
                    
                        </tr>';

          }

          echo '</tbody></table><hr>';

}

function AfficherTableauFReportingSCVersements($cumul,$annee,$mois,$metier){
    if($cumul==1){
                $cumulString="Cumulée";
            }if($cumul==0){
                $cumulString="Mensuelles ";             
            }

    echo '<h2>Sorties de Capitaux /Versements : Données '.$cumulString.' '.$metier.' au '.$mois.'/'.$annee.'</h2><br>';

    global $connexion;
    $req = "SELECT * FROM FreportingObsCA WHERE Metier=:Metier AND Annee=:Annee AND Mois=:Mois AND CUMUL=:Cumul" ; 
    $requete = $connexion->prepare($req);
    $requete->execute(array("Annee"=>$annee,"Mois"=>$mois,"Cumul"=>$cumul,"Metier"=>strtoupper($metier)));


        echo '<table id="reportingParOffreVersements"class="table cell-border table-striped table-hover">
          <thead>
            <tr>
                
                
                
                <th>Part</th>    
                <th>Offre</th>   
                
                <th>Versement Libre Hors Partages</th>  
                <th>Versement Libre Partages</th>  
                <th>Redress Versements Libres</th> 
                <th>TOTAL Versements Libres</th>   
                <th>Versements Reguliers Hors Partages</th> 
                <th>Redress Versements Reguliers Hors Partages</th>  
                <th>TOTAL Versements Reguliers</th>    
                <th>CA Brut TOTAL</th> 
                <th>dont UC Temp</th>  
                <th>dont UC Perm</th>


                
            </tr>
          </thead>
          <tbody>';

          while($tab=$requete->fetch()){

            echo '<tr>
                            
                            
                            
                            <td>'.$tab["Part"].'</td>    
                            <td>'.$tab["Offre"].'</td>   
                            
                            <td>'.$tab["VersementLibreHorsPartages"].'</td>  
                            <td>'.$tab["VersementLibrePartages"].'</td>  
                            <td>'.$tab["RedressVersementsLibres"].'</td> 
                            <td>'.$tab["TOTALVersementsLibres"].'</td>   
                            <td>'.$tab["VersementsReguliersHorsPartages"].'</td> 
                            <td>'.$tab["RedressVersementsReguliersHorsPartages"].'</td>  
                            <td>'.$tab["TOTALVersementsReguliers"].'</td>    
                            <td>'.$tab["CABrutTOTAL"].'</td> 
                            <td>'.$tab["dontUCTemp"].'</td>  
                            <td>'.$tab["dontUCPerm"].'</td>
                        </tr>';

          }

          echo '</tbody></table>';

}

?>
