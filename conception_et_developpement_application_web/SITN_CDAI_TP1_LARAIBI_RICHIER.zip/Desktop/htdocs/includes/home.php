


	<div class="container principal col-lg-7 col-lg-offset-1"  >
		<div class ="row"> 

			<ul class="nav nav-pills nav-justified">

				<?php 
				$i=0;
				if (isset($_GET["annee"])){
					$annee = $_GET["annee"];
				}else{
					$annee=2014;
				}
				if (isset($_GET["mois"])){
					$mois = $_GET["mois"];
				}else{
					$mois=5;
				}
				foreach(Site::getListeFiliales() as $Fil){
						
					if($i==0){
					$config=array("ID_Filiale"=>$Fil->getID(),"Annee"=>$annee,"Mois"=>$mois);
					$Indic = new IndicateursFiliales($config);
					$Indic->load_db();

					
					}
					$i++;
				}
				?>
				<?php 
				$i=0;
				foreach(Site::getListeFiliales() as $Fil){
						
					echo '<li';
					if($i==0){echo ' class="active"';}
					echo '><a href="#'.$Fil->getNomSlug().'" data-toggle="tab">'.$Fil->getNom().'</a></li>';
					$i++;
				}
				?>

			</ul>
			<div class="tab-content">

				<?php
				$i=0;
				foreach(Site::getListeFiliales() as $Fil){
					
					echo '<div class="tab-pane fade';
					if($i==0){echo ' active in';}
					echo '" id="'.$Fil->getNomSlug().'"> DONNEES '.$Fil->getNom() .$Fil->tableauRecap($annee,$mois).'</div>';
					$i++;
					?>
					
						
						
				
				
				<?php
				}
				
				?>
				<button type="button" class="btn btn-info	">Source</button>
			</div>
			
				
			
			
		</div>
	</div>
	
<?php
//Ensemble de fonctions à intégrer dans un fichie fonctions.php




?>