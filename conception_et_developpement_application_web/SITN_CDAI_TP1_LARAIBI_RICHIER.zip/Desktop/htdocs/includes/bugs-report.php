<div class="container principal col-lg-offset-1 col-lg-10 "  >
	<div class ="row"> 

	<table id="bugs" class="table table-striped table-hover">
        <thead>
            <tr>
                
                
                <th>Bug n°</th>
                <th>Date </th>
                <th>Titre </th>
                
                <th>Description</th>
                <th>Etat</th>
                
                
                  
            </tr>
        </thead>
        <tbody>
        <?php
			afficherBugs();
		?>
		</tbody>
		<tfoo>
			<form action="/includes/importBug.php" method="post">
			<input type="hidden" name="p" value="importBug">
			
				<tr><td>Nouveau Bug</td>
					<td><input type="text" name="date" value=<?php echo '"'.date("d.m.y").'"';?>placeholder=<?php echo '"'.date("d.m.y").'"';?> disabled></td>
					<td><input type="text" name="titre"></td>
					<td><textarea name="description"class="form-control" rows="3"></textarea> </td>
					<td><button type="submit" class="btn">Nouveau</button></td>

						
					</td>
				</tr>
			</form>
		</tfoo>
	</table>
	</div>
</div>

<?php function afficherBugs(){
    global $connexion;
    
    $req="SELECT * FROM Bugs";


        $requete = $connexion->prepare($req);
        $requete->execute();
        
        

        
      


       while($tab = $requete->fetch()){
       	if ($tab["etat"]=="Nouveau"){
       		$etat="info";
       	}
       	if ($tab["etat"]=="En Cours"){
       		$etat="warning";
       	}
       	if ($tab["etat"]=="Reglé"){
       		$etat="success";
       	}
        echo    '<tr>
        			<td>'.$tab["ID_BUG"].'</td>
        			<td>'.$tab["datebug"].'</td>
        			<td>'.$tab["titre"].'</td>
        			<td>'.$tab["description"].'</td>
        			<td class="'.$etat.'">'.$tab["etat"].'</td>
        		</tr>';
       }

        
       
        


}

?>