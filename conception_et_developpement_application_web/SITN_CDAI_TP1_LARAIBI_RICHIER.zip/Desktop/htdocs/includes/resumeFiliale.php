<div style="max-width:80%"class="container principal  arcad"  >
		<div class ="row arcad-row" > 
		<div class="col-lg-12">
		
			<?php 

				$filiale="";
				$annee="";
				$mois="";

				if (isset($_GET["filiale"])){
					$filiale=$_GET["filiale"];
				}else{
					$filiale='lbpp';
				}
				if (isset($_GET["p"])){
					$p=$_GET["p"];
				}else{
					$_GET["p"]='resumeFiliale';
				}
				if (isset($_GET["annee"])){
					$annee=$_GET["annee"];
				}else{
					$annee=date("Y");
				}
				if (isset($_GET["mois"])){
					$mois=$_GET["mois"];
				}else{
					//$mois=date('m', strtotime('-2 month'));	
					
					//$mois=date('m')-2;	
					$mois=dernierMoisDisponible($filiale,$annee);

				}

				


				$config = array('nom_slug' => $filiale );
				$Fil=new Filiale($config);
				$Fil->load_db();
				
				$config=array("ID_Filiale"=>$Fil->getID(),"Annee"=>$annee,"Mois"=>5);
				$Indic = new IndicateursFiliales($config);
				$Indic->load_db();

				include 'menuAutresFiliales.php';
				
				echo '</div></div><hr><div class="col-lg-8 col-lg-offset-2"><h3>Aperçu des données '.$Fil->getNom().' du mois de '.date_mois($mois).' '.$annee.'</h3>';
				echo $Fil->tableauRecap($annee,$mois)."<br>";
				echo '<a class="btn btn-info" href="?p=donneesFiliales&f='.$Fil->getnomSlug().'&mois='.$mois.'&annee='.$annee.'" > + de détails </a>';
				echo '</div>';

			?>
			</div>
		</div>
	</div>