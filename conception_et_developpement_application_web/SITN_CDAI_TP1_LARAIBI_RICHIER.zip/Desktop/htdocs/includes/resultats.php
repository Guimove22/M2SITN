<div class="container principal arcad "  >
	<div class ="row arcad-row">

	
		<form method="get" action="index.php">
                <input type="hidden" name="p" value ="resultats">
                <div class="btn-group">
	                <button class="btn btn-default" type="submit" name="annee" value="2012" > 2012</button>
	                <button class="btn btn-default" type="submit" name="annee" value="2013" > 2013</button>
	                <button class="btn btn-default" type="submit" name="annee" value="2014" > 2014</button>
                </div>
		</form>
		<?php $annee;
			if (isset($_GET["annee"])){
				$annee=$_GET["annee"];
			}else{
				$annee=date('Y');
			}
			if($annee == date('Y')){
				$mois= date('m');
				$mois=dernierMoisDisponible("LBPP",$annee);
			}else{
				$mois=12;
			}
		

		//Variables LBPP
		$LBPP_contratsNets=number_format( requeteSQL('AN',"SELECT SUM(AffairesNouvelles) AS AN from IndicateursProduits where filiale = 'LBPP' and mois = $mois And Annee=$annee") ,0,',',  " " );
		$LBPP_contratsNetsCDG= number_format( requeteSQL('AN','SELECT SUM(AffairesNouvelles) AS AN from IndicateursProduits where filiale = "LBPP" and mois = '.$mois. ' And Annee='.$annee.' and (Produit="Obseques" OR Produit ="Deces" OR Produit ="Dependance" )') ,0,',',  " " );
		$LBPP_centresFinanciers= number_format( requeteSQL('AN','SELECT (CentresFinanciers*100) AS AN from CanalSouscription where filiale = "LBPP" and mois = '.$mois. ' And Annee='.$annee.' ') ,1,',',  " " );;
		$LBPP_bureaux= number_format( requeteSQL('AN','SELECT (Enseigne*100) AS AN from CanalSouscription where filiale = "LBPP" and mois = '.$mois. ' And Annee='.$annee.' ') ,1,',',  " " );
		
		$LBPP_SP = number_format( requeteSQL('AN','SELECT (-Sinistres/ChiffresAffaires)*100 AS AN from indicateursFiliales where filiale = "LBPP" and mois = '.$mois. ' And Annee='.$annee.' ') ,1,',',  " " );
		$LBPP_CA = number_format( requeteSQL('AN',"SELECT SUM(ChiffresAffaires) AS AN from IndicateursProduits where filiale = 'LBPP' and mois = $mois And Annee=$annee") ,2,',',  " " );
		$LBPP_CAPrev = number_format( requeteSQL('AN','SELECT SUM(ChiffresAffaires) AS AN from IndicateursProduits where filiale = "LBPP" and (produit="Obseques" or produit="Deces" OR produit="Dependance" OR produit="GAV" OR produit="Sante") and mois = '.$mois.' And Annee='.$annee) ,1,',',  " " );
		$LBPP_CAEmpr = number_format( requeteSQL('AN','SELECT ChiffresAffaires AS AN from IndicateursProduits where filiale = "LBPP" and id_produit=19 and mois = '.$mois.' And Annee='.$annee) ,1,',',  " " );
		$LBPP_CACCP = number_format( requeteSQL('AN','SELECT ChiffresAffaires AS AN from IndicateursProduits where filiale = "LBPP" and id_produit=20 and mois = '.$mois.' And Annee='.$annee) ,1,',',  " " );
		$LBPP_CACreditConso = number_format( requeteSQL('AN','SELECT ChiffresAffaires AS AN from IndicateursProduits where filiale = "LBPP" and id_produit=22 and mois = '.$mois.' And Annee='.$annee) ,1,',',  " " )*0.65;
		$LBPP_Commission = number_format( requeteSQL('AN','SELECT -CommissionsApporteurs AS AN from IndicateursFiliales where filiale = "LBPP"  and mois = '.$mois.' And Annee='.$annee) ,1,',',  " " );
	

		


				?>

	<h1>Résultats Assurance <small>au <?php if($annee < date("Y")){echo $mois .'/'. $annee;}else{echo date("d/m/Y");}	 ?></small></h1>
	
		<div style="margin-right:12px;padding:0px !important"class="col-md-5 panel panel-info">
		  	<div class="panel-heading">LBPP</div>
		  	<div class="panel-body">
			  	<ul class="list-unstyled">
			  	
					<li><?php echo $LBPP_contratsNets; ?> contrats nets souscrits <small>(dont <?php echo $LBPP_contratsNetsCDG; ?> en cœur de gamme*)</small></li>
					<ul>
						<li><?php echo $LBPP_centresFinanciers; ?>% par les centres financiers </li>
						<li><?php echo $LBPP_bureaux; ?>% par les bureaux </li>
					</ul>
					<li>S/P : <?php echo $LBPP_SP; ?>%</li>
					<li><?php echo $LBPP_CA; ?> millions d’€ de chiffre d’affaire dont </li>
					<ul>
						<li><?php echo $LBPP_CAPrev; ?> millions d’€ pour la prévoyance individuelle, </li>
						<li><?php echo $LBPP_CAEmpr; ?> millions d’€ pour l’emprunteur</li>
						<li><?php echo $LBPP_CACCP; ?> millions d’€ pour le contrat collectif Personnel La Poste en réassurance LMG</li>
						<li><?php echo $LBPP_CACreditConso; ?> millions d’€ pour le crédit à la consommation (réassurance en quôte part à 65%)</li>
					</ul>
					<li>XX millions de résultat net norme IFRS" </li>
					<li><?php echo $LBPP_Commission; ?> millions d’€ de commission de distribution.</li>
				  	
		  </ul>
		    <small>Coeur de gamme  : Avisys, Sérénia, Prémunys, Résolys Obsèques, Protectys</small>

		  </div>
		</div>
		
		<?php

		//VARIABLES LBPAI

		$LBPAI_Portefeuille = requeteSQLTab('Portefeuille','Produit',"SELECT Produit,Portefeuille  from IndicateursProduits where filiale = 'LBPAI' and mois = $mois And Annee=$annee");
		
		
		$LBPAI_PortefeuilleAuto=number_format($LBPAI_Portefeuille['Automobile']  ,0,',',  " " );
		$LBPAI_PortefeuilleMRH =number_format($LBPAI_Portefeuille['MultirisqueHabitation']  ,0,',',  " " );
		$LBPAI_PortefeuillePJ  =number_format($LBPAI_Portefeuille['ProtectionJuridique']  ,0,',',  " " );
		if($annee>=2013)$LBPAI_PortefeuilleOLS =number_format($LBPAI_Portefeuille['Autres(LBPAI)']  ,0,',',  " " );
		if($annee<2013)$LBPAI_PortefeuilleOLS =0;

		$LBPAI_Portefeuille= number_format($LBPAI_Portefeuille['Automobile'] + $LBPAI_Portefeuille['MultirisqueHabitation'] + $LBPAI_Portefeuille['ProtectionJuridique']  + $LBPAI_PortefeuilleOLS,0,',',  " " ) ;

		$LBPAI_centresFinanciers= number_format( requeteSQL('AN','SELECT (CentresFinanciers*100) AS AN from CanalSouscription where filiale = "LBPAI" and mois = '.$mois. ' And Annee='.$annee.' ') ,1,',',  " " );;
		$LBPAI_bureaux= number_format( requeteSQL('AN','SELECT (Enseigne*100) AS AN from CanalSouscription where filiale = "LBPAI" and mois = '.$mois. ' And Annee='.$annee.' ') ,1,',',  " " );
		$LBPAI_Internet= number_format( requeteSQL('AN','SELECT (Internet*100) AS AN from CanalSouscription where filiale = "LBPAI" and mois = '.$mois. ' And Annee='.$annee.' ') ,1,',',  " " );
		$LBPAI_CRC= number_format( requeteSQL('AN','SELECT (Telephone*100) AS AN from CanalSouscription where filiale = "LBPAI" and mois = '.$mois. ' And Annee='.$annee.' ') ,1,',',  " " );
		$LBPAI_SPAuto= number_format( requeteSQL('SinistreSurPrime','SELECT (sinistresurprime*100) AS SinistreSurPrime  from indicateursProduits where filiale = "LBPAI" and produit="Automobile" and mois = '.$mois. ' And Annee='.$annee.' ') ,0,',',  " " );
		$LBPAI_SPMRH= number_format( requeteSQL('SinistreSurPrime','SELECT (sinistresurprime*100 ) AS SinistreSurPrime from indicateursProduits where filiale = "LBPAI" and produit="MultirisqueHabitation" and mois = '.$mois. ' And Annee='.$annee.' ') ,0,',',  " " );

		?>



		<div style="margin-right:12px;padding:0px !important"class="col-md-5 panel panel-info">
		  	<div class="panel-heading">LBPIARD, dommages</div>
		  	<div class="panel-body">
			  	<ul class="list-unstyled">
			  	
					<li>527.800 affaires nouvelles brutes et <?php echo $LBPAI_Portefeuille; ?>   contrats en portefeuille</li>
					<ul>
						<li><?php echo $LBPAI_PortefeuilleAuto; ?> Auto (<?php echo round(($LBPAI_PortefeuilleAuto/$LBPAI_Portefeuille)*100,1); ?>%), prime moyenne 346€</li>
						<li><?php echo $LBPAI_PortefeuilleMRH; ?> Habitation (<?php echo round(($LBPAI_PortefeuilleMRH/$LBPAI_Portefeuille)*100,1); ?>%), prime moyenne 191€</li>
						<li><?php echo $LBPAI_PortefeuillePJ; ?> PJ (<?php echo round(($LBPAI_PortefeuillePJ/$LBPAI_Portefeuille)*100,1); ?>%), prime moyenne 59€</li>
						<li><?php echo $LBPAI_PortefeuilleOLS; ?> OLS/PPI (<?php echo round(($LBPAI_PortefeuilleOLS/$LBPAI_Portefeuille)*100,1); ?>%), prime moyenne 98€</li>

						
					</ul>
					<li>Répartition par Canal des Affaires Nouvelles</li>
					
					<ul>
						<li>Internet : <?php echo $LBPAI_Internet; ?>%</li>
						<li>Bureaux de Poste : <?php echo $LBPAI_bureaux; ?>%</li>
						<li>Centres Financiers : <?php echo $LBPAI_centresFinanciers; ?>%</li>
						<li>CRC : <?php echo $LBPAI_CRC; ?>%</li>
					</ul>
					<li>S/P Auto : <?php echo $LBPAI_SPAuto; ?>%</li>
					<li>S/P MRH : <?php echo $LBPAI_SPMRH; ?>%</li>
					<li><?php echo $LBPP_Commission; ?> millions d’€ de commission de distribution.</li>
				  	
			  </ul>
		    

		  </div>
		</div>


		<!--<div style="margin-right:12px;padding:0px !important" class="col-md-5 panel panel-info">
		  <div class="panel-heading">LBPAS</div>
		  <div class="panel-body">
		    
		  </div>
		</div>-->


	</div>
</div>

<?php 
function requeteSQL($i,$req){
	global $connexion;
	$requete = $connexion->prepare($req);
    $requete->execute();
	$tab = $requete->fetch();
	
	return $tab[$i];
}


function requeteSQLTab($i,$j,$req){
	global $connexion;

	$requete = $connexion->prepare($req);
    $requete->execute();
    $return= array();

    while($tab = $requete->fetch()){
    	
    	$return[$tab[$j]] = $tab[$i];
    }
	
	return $return;
}


?>