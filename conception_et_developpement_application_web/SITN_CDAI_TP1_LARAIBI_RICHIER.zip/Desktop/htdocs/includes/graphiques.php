<?php 

$annee;
$filiale;
if (isset($_GET["annee"])){
	$annee=$_GET["annee"];
}else{
	$annee=date('Y');
}
if (isset($_GET["filiale"])){
	$filiale=$_GET["filiale"];
}else{
	$filiale="LBPP";
}
?>
<div class="container principal arcad "  >
	<div class ="row arcad-row">

		<form method="get" action="index.php">
                <input type="hidden" name="p" value ="graphiques">
                <input type="hidden" name="filiale" value =<?php echo '"'.$filiale.'"'?>>
                <div class="btn-group">
	                <button class="btn btn-<?php if($annee==2012){echo 'info';}else{echo 'default';} ?>" type="submit" name="annee" value="2012" > 2012</button>
	                <button class="btn btn-<?php if($annee==2013){echo 'info';}else{echo 'default';} ?>" type="submit" name="annee" value="2013" > 2013</button>
	                <button class="btn btn-<?php if($annee==2014){echo 'info';}else{echo 'default';} ?>" type="submit" name="annee" value="2014" > 2014</button>
                </div>
		</form>
				<form method="get" action="index.php">
                <input type="hidden" name="p" value ="graphiques">
                <input type="hidden" name="annee" value =<?php echo '"'.$annee.'"'?>>
                <div class="btn-group">
	                <button class="btn btn-<?php if($filiale=="LBPAI"){echo 'info';}else{echo 'default';} ?>" type="submit" name="filiale" value="LBPAI" > LBPAI</button>
	                <button class="btn btn-<?php if($filiale=="LBPAS"){echo 'info';}else{echo 'default';} ?>" type="submit" name="filiale" value="LBPAS" > LBPAS</button>
	                <button class="btn btn-<?php if($filiale=="LBPCA"){echo 'info';}else{echo 'default';} ?>" type="submit" name="filiale" value="LBPCA" > LBPCA</button>
	                <button class="btn btn-<?php if($filiale=="LBPP"){echo 'info';}else{echo 'default';} ?>" type="submit" name="filiale" value="LBPP" > LBPP</button>
                </div>
		</form>
		<?php if(($filiale=="LBPP")||($filiale=="LBPAI")){
			$divCA=8;
		}else{$divCA=12;}
		?>
		
		<div class="row">
		<div id="graphCA" class="col-lg-<?php echo $divCA;?>"style=" height:400px;"></div><!---->
		
		
		<?php if(($filiale=="LBPP")||($filiale=="LBPAI")){
			echo '<div class="col-lg-4" style="height:300px" id="graphCanalSous'.$filiale.'"  ></div>';
		}
		?>
		</div>
		
		<hr><br><hr>
		<div class="col-lg-12" style="height:600px ;;" id="GraphPortefeuille" ></div><!---->
		<script>
		$(function () {
	    $('#GraphPortefeuille').highcharts({
	        chart: {
	            type: 'column'
	        },
	        title: {
	            text: 'Portefeuille'
	        },
	        xAxis: {
	            categories: ['Janvier', 'Fevrier', 'Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre']
	        },
	       yAxis: {
	            min: 0,
	            title: {
	                text: 'Portefeuille'
	            },
	            stackLabels: {
	                enabled: true,
	                style: {
	                    fontWeight: 'bold',
	                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray',
	                    
	                },
	                formatter: function () {
			        return Highcharts.numberFormat((this.total/1000),0)  + ' M';
			    },	
	            },
	                    
	        },

	        legend: {
	            
	            x: 0,
	            verticalAlign: 'bottom',
	            y: 0,
	            floating: false,
	            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
	            borderColor: '#CCC',
	            borderWidth: 1,
	            shadow: false,

	        },

	        tooltip: {
	            formatter: function () {
	                return '<b>' + this.x + '</b><br/>' +
	                    this.series.name + ': ' + Highcharts.numberFormat((this.y/1000),0) + ' M <br/>' +
	                    'Total: ' + Highcharts.numberFormat((this.point.stackTotal/1000),0) + ' M';
	            },
	        },
	        plotOptions: {
	            column: {
	                stacking: 'normal',
	                dataLabels: {
	                    enabled: true,
	                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
	                    style: {
	                        textShadow: '0 0 3px black, 0 0 3px black'
	                    },
	                    formatter: function () {
			                return  Highcharts.numberFormat((this.y/1000),0) + ' M';
			            },

	                }
	            },
	        },



	        series: [ <?php genererSeries('IndicateursProduit','Portefeuille',$filiale,$annee); ?>]
	    });
});

		$(function () { 
		    $('#graphCA').highcharts({
		        chart: {
		            type: 'column'
		        },
		        <?php 
		        	$indicateur="ChiffresAffaires";
		        	$titre = 'Chiffres d’Affaires';
		        	if(($filiale=="LBPAI")){
		        		$indicateur="PrimesAcquises";
		        		$titre = "Primes Acquises";
		        	}
		        ?>
		        title: {
		            text: <?php echo "'".$titre."'";?>
		        },
		        xAxis: {
		            categories: ['Janvier', 'Fevrier', 'Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre']
		        },
		        yAxis: {
		            title: {
		                text: 'en Millions €'
		            }
		        },
		        series: [
		        
		        {
		            name: <?php echo "'".$filiale." N'"; ?>,
		            data: <?php graphiqueFiliale($indicateur,$filiale,$annee);?>
		        }, 
		        {
		            name: <?php echo "'".$filiale." N-1'" ;?>,
		            data:<?php graphiqueFiliale($indicateur,$filiale,($annee-1));?>
		        },
		        {
		            name: <?php echo "'".$filiale." Budget N'";?>,
		            data:<?php graphiqueFiliale($indicateur,$filiale,($annee-1000));?>
		        }
		        ]
		    });
		});

		$(function () { 
		    $('#graphCanalSousLBPAI').highcharts({
		        chart: {
		            type: 'pie'
		        },
		        title: {
		            text: 'Canal Souscription LBPAI'
		        },
		         tooltip: {
               		pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
           		 },
		        
		        series: [{
		            name: 'Test',
		            data: <?php graphiqueCanalSouscription("LBPAI",$annee);?>
		        }
		        ]
		    });
		});

		$(function () { 
		    $('#graphCanalSousLBPP').highcharts({
		        chart: {
		            type: 'pie'
		        },
		        title: {
		            text: 'Canal Souscription LBPP'
		        },
		        tooltip: {
               		pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
           		 },
		        series: [{
		            name: 'Test',
		            data: <?php graphiqueCanalSouscription("LBPP",$annee);?>
		        }
		        ]
		    });
		});



		(function (Highcharts) {

	var defaultOptions = Highcharts.getOptions(),
		symbols = Highcharts.Renderer.prototype.symbols,
		extend = Highcharts.extend,
		merge = Highcharts.merge;

	// Add language keys
	extend(defaultOptions.lang, {
		exportButtonTitle: 'Télécharger le graphique',
		printButtonTitle: 'Imprimer le graphique'
	});

	// The old button look
	defaultOptions.navigation.buttonOptions = merge(defaultOptions.navigation.buttonOptions, {
		
		borderColor: '#B0B0B0',
		height: 20,
		theme: {
			fill: {
				linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
				stops: [
					[0, '#FFF'],
					[1, '#DDD']
				]
			},
			stroke: '#BBB'
		},
		symbolSize: 12,
		symbolStroke: '#A0A0A0',
		symbolStrokeWidth: 1
	});
	
	// Add the buttons to default options
	extend(defaultOptions.exporting.buttons, {
		exportButton: {
			//enabled: true,
			symbol: 'exportIcon',
			x: -10,
			symbolFill: '#A8BF77',
			_id: 'exportButton',
			_titleKey: 'exportButtonTitle',
			menuItems: defaultOptions.exporting.buttons.contextButton.menuItems.splice(2, 4)

		},
		printButton: {
			//enabled: true,
			symbol: 'printIcon',
			x: -36,
			symbolFill: '#B5C9DF',
			_id: 'printButton',
			_titleKey: 'printButtonTitle',
			onclick: function () {
				this.print();
			}
		}
	});
	delete defaultOptions.exporting.buttons.contextButton;

	/**
	 * Crisp for 1px stroke width, which is default. In the future, consider a smarter,
	 * global function.
	 */
	function crisp(arr) {
		var i = arr.length;
		while (i--) {
			if (typeof arr[i] === 'number') {
				arr[i] = Math.round(arr[i]) - 0.5;		
			}
		}
		return arr;
	}

	// Create the export icon
	symbols.exportIcon = function (x, y, width, height) {
		return crisp([
			'M', // the disk
			x, y + width,
			'L',
			x + width, y + height,
			x + width, y + height * 0.8,
			x, y + height * 0.8,
			'Z',
			'M', // the arrow
			x + width * 0.5, y + height * 0.8,
			'L',
			x + width * 0.8, y + height * 0.4,
			x + width * 0.4, y + height * 0.4,
			x + width * 0.4, y,
			x + width * 0.6, y,
			x + width * 0.6, y + height * 0.4,
			x + width * 0.2, y + height * 0.4,
			'Z'
		]);
	};
	// Create the print icon
	symbols.printIcon = function (x, y, width, height) {
		return crisp([
			'M', // the printer
			x, y + height * 0.7,
			'L',
			x + width, y + height * 0.7,
			x + width, y + height * 0.4,
			x, y + height * 0.4,
			'Z',
			'M', // the upper sheet
			x + width * 0.2, y + height * 0.4,
			'L',
			x + width * 0.2, y,
			x + width * 0.8, y,
			x + width * 0.8, y + height * 0.4,
			'Z',
			'M', // the lower sheet
			x + width * 0.2, y + height * 0.7,
			'L',
			x, y + height,
			x + width, y + height,
			x + width * 0.8, y + height * 0.7,
			'Z'
		]);
	};


}(Highcharts));
		</script>
	</div>
</div>

<?php 
function genererSeries($table,$indicateur,$filiale,$annee){
	global $connexion;
	$req='SELECT Produit,'.$indicateur.' FROM IndicateursProduits WHERE Annee=:Annee AND Filiale=:Filiale order by produit,mois';
	$requete = $connexion->prepare($req);
    $requete->execute(array("Filiale"=>$filiale,"Annee"=>$annee));

    $nomProd="";
    $i=0;
    $res=array();
    while($tab=$requete->fetch()){
    		if(!$tab[$indicateur]){$tmp=0;}
    		else{
	    		$tmp=$tab[$indicateur];
    		}

    		if($tab["Produit"]!=$nomProd){
    			if     (preg_match('/Autres/',$tab["Produit"]))	{ $tab["Produit"]="Autres";}
    			$res[$tab["Produit"]][]=$tmp;
    			$tmp="";
    		}

    		/*if(($i!=0)||($tab["Produit"]==$nomProd)){echo ',';}
    		if($tab["Produit"]!=$nomProd){
    			if($i!=0){ echo ']},';}
    			echo '
    			{ name : \''.$tab["Produit"].'\', 
				  data :[';
    			$i++;
    			$nomProd=$tab["Produit"];

    		}	//var_dump($tab);
              echo $tab[$indicateur];//*/
              
	}
	$j=1;
	foreach ($res as $produit => $mois) {
		$i=1;
		
		echo "
			{ name : '".$produit."',
			  data : [";
			  foreach ($mois as $key => $value) {
			  	echo $value;
			  	if ($i<sizeof($mois)){
			  		echo ',';
			  	}
			  	$i++;
			  	# code...
			  }
			  echo  ']}';
		
		
		if ($j<sizeof($res)){
			  		echo ',';
		}
		$j++;
	}

	# code...

	//var_dump($res);
	//echo ']}';

          /*{ name : Obseques
          		data : [jan,fev]}//*/
}
function graphiqueFiliale($indicateur,$filiale,$annee){

  
  global $connexion;
      $req = 'select '.$indicateur.' from indicateursFiliales where filiale=:Filiale and annee=:Annee order by annee, mois' ;
      $requete = $connexion->prepare($req);
      $requete->execute(array("Filiale"=>$filiale,"Annee"=>$annee));

      echo "[";
      $res=array();
      while($tab=$requete->fetch()){
      			if(!$tab[$indicateur]){$res[]=0;}
      			else{$res[]= $tab[$indicateur];}
          }
      
      $i=1;
      foreach ($res as $key => $value) {
      	echo $value;
      	if($i<sizeof($res)){echo',';}
      }
      echo ']';
        


}

function graphiqueCanalSouscription($filiale,$annee){

 
  global $connexion;
      $req = 'select Annee,MAX(mois),* from canalSouscription WHERE Annee=:Annee AND Filiale=:Filiale' ;
      $requete = $connexion->prepare($req);
      $requete->execute(array("Filiale"=>$filiale,"Annee"=>$annee));

      echo "[";
      while($tab=$requete->fetch()){
              if($filiale=="LBPAI"){
              	echo 	"['Centres Financiers',".$tab['CentresFinanciers']."]
              		,['Enseigne',".$tab['Enseigne']."]
              		,['Téléphone',".$tab['Telephone']."]
              		,['Internet',".$tab['Internet']."]";
              	}
              	if($filiale=="LBPP"){
              	echo 	"['Centres Financiers',".$tab['CentresFinanciers']."]
              		,['Enseigne',".$tab['Enseigne']."]";
              	}
          }
      echo ']';
        


}


?>

