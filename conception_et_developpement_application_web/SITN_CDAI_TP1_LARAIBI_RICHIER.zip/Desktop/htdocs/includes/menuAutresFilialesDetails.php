	
<div class="btn-group" role="toolbar">
	<?php 

		echo    '<form method="get" action="index.php">'
				            .'<input type="hidden" name="p" value="'.$_GET["p"].'">'
				            .'<input type="hidden" name="mois" value="'.$mois.'">
				           '
				            
				            .'<input type="hidden" name="annee" value="'.$annee.'"> <div class="btn-group">';

				            
				        	
	foreach(Site::getListeFiliales() as $Filiale){
		//if ($Filiale->getNomSlug() !=$filiale)
				if($_GET["f"]==$Filiale->getNomSlug()){$class="info";}else{$class="default";}
				echo '<button type="submit" name="f" value="'.$Filiale->getNomSlug().'"class="btn btn-'.$class.'">'.$Filiale->getNom().'</button>';
	}

	echo '</div></form>';
	?>
</div>