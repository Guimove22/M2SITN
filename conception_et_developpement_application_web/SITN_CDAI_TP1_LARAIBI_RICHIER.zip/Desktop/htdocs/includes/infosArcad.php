<div class="container principal ">

	<div class="row" style="width: 60%;
margin: 0px auto 0px auto">
		<div class="col-lg-12">
			
				<a href="#" class="thumbnail">
			      <img src="img/arcadV2.jpg" data-src="holder.js/100%x180" alt="...">
				</a>
			<div style="text-align:center">
			<h4 >Application de Reporting et de Centralisation Automatique des Données</h4>
			<p>Développée par <a href="mailto:hello@axelrichier.com">Axel Richier</a></p>
				
			</div>
			
			
		</div>
	</div>
</div>