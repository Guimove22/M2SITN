<div class="container principal  arcad"  >
	<div class ="row arcad-row"> 
	<?php
	if(isset($_GET["type"])){
		$type=$_GET["type"];

		if(isset($_GET["annee"])){$annee=$_GET["annee"];}else{$annee=derniereAnneeRachat($type);}
		
		afficherTableauRachats($type,$annee);

	}else{

		echo "Erreur : Pas de Type de rachats selectionné.";
	}
	
	?>

	</div>
</div>