<div class="container principal arcad "  >
	<div class ="row arcad-row"> 
	<?php
	$type="";
	$annee="";
	$mois="";
	if(isset($_GET["type"])){
	 	$type=$_GET["type"];
	}else{
		$type="CNP";
	}
	if(isset($_GET["annee"])){
	 	$annee=$_GET["annee"];
	}else{
		$annee=lastAnneeCommissionementCNP($type);
	}
	if(isset($_GET["mois"])){
	 	$mois=$_GET["mois"];
	}else{
		$mois=12;
	}

	afficherSelecteurTypeCommissionement($annee,$mois);

	afficherSelecteurAnneeCommissionement($type);
	afficherSelecteurMoisCommissionement($type,$annee);

	//afficherTotauxCommissionementCNP($type,$annee,$mois);
	afficherCommissionement($type,$annee,$mois);


	?>
	
	</div>
</div>