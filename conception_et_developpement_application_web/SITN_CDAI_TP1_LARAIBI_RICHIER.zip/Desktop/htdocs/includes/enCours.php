<div class="container principal arcad   "  >
	<div class ="row arcad-row"> 

	
	<?php 

		$metier;
		$annee;
		$trimestre;
		$type;
		

		if(isset($_GET["metier"])){
			$metier=$_GET["metier"];
		}else{
			$metier="Epargne";
		}

		if(isset($_GET["annee"])){
			$annee=$_GET["annee"];
		}else{
			$annee=date("Y");
		}
		if(isset($_GET["mois"])){
			$mois=$_GET["mois"];
		}else{
			$mois=1;
		}

		if(isset($_GET["type"])){
			$type=$_GET["type"];
		}else{
			$type="parOffre";
		}

		afficherTitre("Encours");

		afficherSelecteurMetierEncours();
		afficherSelecteurAnneeEncours(getAnneeEncours());
		//echo $metier.$annee;
		afficherSelecteurMoisEncours($metier,$annee);

		
		if ($type!=""){

			

			afficherSelecteurTypeEncours($metier,$annee,$mois);

			
			if($type=="parOffre"){
				//tableauEncoursParOffre($metier,$annee,$mois);
				tableauEncoursParOffreGroupee($metier,$annee,$mois);
				
				
			}

			if($type=="parProduit"){

				//tableauEncoursParProduit($metier,$annee,$mois);
				tableauEncoursParProduitGroupes($metier,$annee,$mois);
			}
			if($type=="parSupport"){
				tableauEncoursParSupport($metier,$annee,$mois);
			}

				
					
			}else{
				
			}
	
		

			
		

		
	?>





	</div>
</div>
