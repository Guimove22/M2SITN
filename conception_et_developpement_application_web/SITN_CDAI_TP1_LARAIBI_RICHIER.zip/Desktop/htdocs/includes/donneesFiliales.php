<div class="container arcad principal "  >
		<div class ="row arcad-row"> <div class="container"><div class="row"><div class="col-lg-4">

			<?php 

				$filiale="";
				$annee="";
				$mois="";

				if ((isset($_GET["f"]))&&(isset($_GET["annee"]))&&(isset($_GET["mois"]))){
					$filiale=$_GET["f"];
				
					$annee=$_GET["annee"];
					
					$mois=$_GET["mois"];
					if($mois==0){$mois++;}
					
					

				
					$config = array('nom_slug' => $filiale );
					$Fil=new Filiale($config);
					$Fil->load_db();
					$config=array("ID_Filiale"=>$Fil->getID(),"Annee"=>$annee,"Mois"=>$mois);
					$Indic = new IndicateursFiliales($config);
					$Indic->load_db();
					include 'menuAutresFilialesDetails.php';
					echo '</div><div class="col-lg-8"><form method="get" action="index.php">'
						.'<input type="hidden" name="p" value="donneesFiliales">'
						.'<input type="hidden" name="f"  value="'.$filiale.'">'
						.'<input type="hidden" name="mois" value="'.$mois.'">
						<div class="btn-group">';

					//SELECTEUR ANNEE
					$req = "SELECT DISTINCT(annee) AS Annee FROM indicateursFiliales WHERE annee>2000 AND Filiale=:Filiale";
			        $requete = $connexion->prepare($req);
			        $requete->execute(array("Filiale"=>strtoupper($filiale)));
			        $listeAnnee=array();
			        while($tab = $requete->fetch()){
			            
			                $listeAnnee[]=$tab["Annee"];    
			        }	
								
					foreach ($listeAnnee as $cle => $valeur) {
			           if($valeur==$annee){$class="info";}else{$class="default";}
			            echo '<button type="submit" name="annee" class="btn btn-'.$class.'" value="'.$valeur.'"> '.$valeur.'</button>';
			        
			        }
					echo '</div></form>';
					 //SELECTEUR MOIS
				        $req = "SELECT DISTINCT(mois) AS Mois FROM indicateursFiliales WHERE annee=:Annee AND Filiale=:Filiale";
				        $requete = $connexion->prepare($req);
				        $requete->execute(array("Annee"=>$annee,"Filiale"=>strtoupper($filiale) ));
				        $listeMois=array();

				        while($tab = $requete->fetch()){
				            
				                $listeMois[]=$tab["Mois"];    
				        }

				        


							echo    '<form method="get" action="index.php">'
				            .'<input type="hidden" name="p" value="'.$_GET["p"].'">'
				            .'<input type="hidden" name="f" value="'.$filiale.'">
				           '
				            
				            .'<input type="hidden" name="annee" value="'.$annee.'"> <div class="btn-group">';

				            foreach ($listeMois as $cle => $valeur) {
				            if($valeur==$mois){$class="info";}else{$class="default";}
				            echo '<button type="submit" name="mois" class="btn btn-'.$class.'" value="'.$valeur.'">'.date_mois_mini($valeur).'</button>';
				        }
				        	echo '</div></form></div></div></div>';

					
					echo '<h3>Détails des données '.$Fil->getNom().' du mois de '.date_mois($mois).' '.$annee.'</h3>';
					


					$i=0;
					$ListeProd=$Fil->getListeProduits($annee,$mois);
						if($ListeProd!="-"){
						foreach ($Fil->getListeProduits($annee,$mois) as $key => $Details) {
							//var_dump($Details);
							$ID_Produit=$Details["ID_Produit"];
							
							//echo '<br>ID :'.$ID_Produit.'<br>Annee '.$annee.'<br>Mois'.$mois.'<br>';
							
							$config = array('ID_Produit' => $ID_Produit, 'Annee'=> $annee , 'Mois'=> $mois);
							$prod= new IndicateursProduits($config);
							$prod->load_db();
							$listeIndicateursProduits=$prod->getListeIndicateurs();

							//Affichage de l'entete du tableau
							if ($i==0){
								?>
								<table class="table table-bordered table-striped table-hover">
		      					<thead>
		        					<tr>
		        						<?php

		        							echo '	<th>Produit</th>
		        									<th>Chiffre d\'affaires</th>
		        									<th>Affaires Nouvelles</th>
		        									<th>Sorties de Contrats</th>
		        									<th>Production Nette</th>
		        									<th>Portefeuille</th>
		        									<th>S/P</th>
		        									';//*/
		        							/*foreach ($listeIndicateursProduits as $cle => $ind) {
		        								if ($ind != "Source"){

		        									echo '<th>'.$ind.'</th>';
		        								}
		        							}//*/
		        						?>
		        					</tr>
		      					</thead>
		      					<tbody>

		      					<?php

							}

							echo '<tr>';
							
							foreach ($listeIndicateursProduits as $cle => $ind) {
								if ($ind != "Source"){
									if(is_numeric($prod->getIndic($ind))){
										$class=' class="eurosAdroite" ';
										$round=0;
										if($ind=="ChiffresAffaires"){$round=2;}
										echo '<td'.$class.'>'.number_format($prod->getIndic($ind),$round,',','.').'</td>';
									}else{
										$class="";
										echo '<td'.$class.'>'.$prod->getIndic($ind).'</td>';
									}
									
								}
							}
							/*echo "<br><br>produit : ".$prod->getProduit();
							echo "<br>mois :".$mois;
							echo "<br>annee : ".$annee;
							echo "<br>Affaires nouvelles : " .$prod->getAffairesNouvelles();//*/
							echo '</tr>';
							$i++;
							
						}
					}else{
							echo '<div class="alert alert-danger" role="alert">Données indisponibles ou non existantes.</div>';
						}	# code... ?>

					</tbody>	
   					</table>

					<?php
					
/*          <th>#</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Username</th>
        
      <tbody>
        <tr>
          <td>1</td>
          <td>Mark</td>
          <td>Otto</td>
          <td>@mdo</td>
        </tr>
        <tr>
          <td>2</td>
          <td>Jacob</td>
          <td>Thornton</td>
          <td>@fat</td>
        </tr>
        <tr>
          <td>3</td>
          <td colspan="2">Larry the Bird</td>
          <td>@twitter</td>
        </tr>
      </tbody>
    </table>//*/
					//echo $Fil->tableauRecap($annee,$mois)."<br>";
					//echo '<a class="btn btn-info" href="?p=donneesFiliales&f='.$Fil->getID().'" > + de détails </a>';
					
				}else{
					echo "Erreur";
				}


			?>



		</div>
	</div>