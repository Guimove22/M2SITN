<?php if (!(isset($_GET["p"]))){$_GET["p"]="resumeFiliale";}  ?><div class="navbar navbar-default navbar-fixed-top" role="navigation">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" style="font-size:25px" href="index.php">ARCAD</a>
    </div>
    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav">
        <li <?php if ($_GET["p"]=="resumeFiliale"){echo 'class="active"'; }?>><a href="?p=resumeFiliale">Filiales LBP</a></li>
         <li class="dropdown"> 
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">CNP <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="?p=impayes">Impayés</a></li>
            <li class="divider"></li>

            <li class="dropdown-header">Encours</li>
            <li><a href="?p=enCours&type=parOffre">Par Offre</a></li>
            <li><a href="?p=enCours&type=parProduit">Par Produit</a></li>
            <li><a href="?p=enCours&type=parSupport">Par Support</a></li>
            <li class="divider"></li>

            <li><a href="?p=commissionnementCNP">Commissionement CNP</a></li>
            <li class="divider"></li>

            <li class="dropdown-header">Rachats</li>
            <li><a href="?p=rachats&type=partiels">Rachats Partiels</a></li>
            <li><a href="?p=rachats&type=totaux">Rachats Totaux</a></li>
             <li class="divider"></li>

            <li class="dropdown-header">F-Reporting</li>
            <li><a href="?p=freporting&type=CA">Chiffre d'Affaires</a></li>
            <li><a href="?p=freporting&type=SC">Sortie de Contrats</a></li>

            
          </ul>
        </li>
        <li class="dropdown"> 
          <a href="#" <?php echo 'class="dropdown-toggle ';if ($_GET["p"]=="freporting"){echo 'active'; } echo '"'; ?> data-toggle="dropdown">FReporting <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="?p=freporting&type=CA">Chiffre d'Affaires</a></li>
            <li><a href="?p=freporting&type=SC">Sortie de Contrats</a></li>
            <li><a href="#">Collecte Nette</a></li> <!-- ?p=freporting&type=CN --> 
           

            
          </ul>
        </li>
        <li <?php if ($_GET["p"]=="resultats"){echo 'class="active"'; }?>><a href="?p=resultats">Résultats</a></li>
        
        
        <!--<li <?php if ($_GET["p"]=="impayes"){echo 'class="active"'; }?> class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Impayés <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="?p=impayes&type=parOffre">Par Offre</a></li>
            <li><a href="?p=impayes&type=parMotif">Par Motif</a></li>
            
            <li class="divider"></li>
            
            <li><a href="?p=impayes">Tout</a></li>
            
          </ul>
        </li>

        <li <?php if ($_GET["p"]=="enCours"){echo 'class="active"'; }?> class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Encours <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="?p=enCours&type=parOffre">Par Offre</a></li>
            <li><a href="?p=enCours&type=parProduit">Par Produit</a></li>
            <li><a href="?p=enCours&type=parSupport">Par Support</a></li>
            
            <li class="divider"></li>
            
            <li><a href="?p=enCours">Tout</a></li>
            
          </ul>
        </li>

        <li <?php if ($_GET["p"]=="commissionnementCNP"){echo 'class="active"'; }?>><a href="?p=commissionnementCNP">Commissionement CNP</a></li>

       
       
       
        <li  <?php if ($_GET["p"]=="rachats"){echo 'class="dropdown active"'; }else{ echo 'class="dropdown"';}?>>
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Rachats <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="?p=rachats&type=partiels">Partiels</a></li>
            <li><a href="?p=rachats&type=totaux">Totaux</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Indicateurs <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="#">S/P</a></li>
            <li><a href="#">Autre ratio</a></li>
            <li class="divider"></li>
            <li class="dropdown-header">Nav header</li>
            <li><a href="#">Test</a></li>
            
          </ul>
        </li>-->
      </ul>
      <ul class="nav navbar-nav navbar-right">
        
        <li ><a href="?p=graphiques">Graphiques</a></li>
        <li ><a href="#">Doc</a></li>
        <!--<li ><a href="?p=bugs-report">Bugs</a></li>-->
        <li><form action="index.php"><input type="hidden" name="p" value="import"><button type="submit" class="btn btn-default navbar-btn btn-info">Importer</button></form></li>
      </ul>
    </div><!--/.nav-collapse -->
  </div>
</div>