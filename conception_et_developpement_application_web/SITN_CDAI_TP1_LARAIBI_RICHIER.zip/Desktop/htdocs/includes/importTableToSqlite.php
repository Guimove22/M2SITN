<?php


	header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	//var_dump($_POST);

	global $connexion;
	//$dbh = new PDO('sqlite:D:\Documents and Settings\vytg315\Mes documents\sqlite\SQLBDD1');
	//$dbh = new PDO('sqlite:D:\Documents and Settings\vytg315\Mes documents\sqlite\SQL290714');
	$dbh = new PDO('sqlite:C:\xampp\BDD_SQLite\SQL290714');

	//$dbh=$connexion;

	foreach ($_POST["upload"] as $key => $value) {
		echo $value."<br>";
		$table= preg_replace('/\.[^.]+$/','',$value);
		//import_csv_to_sqlite($connexion,'D:\Documents and Settings\vytg315\Mes documents\dev\\'.$value,array("table"=>$table,"fields"=>getFields($value)));		# code...
		//import_csv_to_sqlite($dbh,'D:\Documents and Settings\vytg315\Mes documents\exportCSV_BDD1\\'.$value,array("table"=>$table,"fields"=>getFields($value)));		# code...
		//import_csv_to_sqlite($dbh,'O:\_ASSURANCE\_RISQUES_ASSURANCE\ARCAD\BDD\\'.$value,array("table"=>$table,"fields"=>getFields($value)));		# code...
		import_csv_to_sqlite($dbh,'C:\xampp\Exports\\'.$value,array("table"=>$table,"fields"=>getFields($value)));		# code...
		
	}


function getFields($value){
		

		$fields_ListeFiliales = array(	"Nom",
										"ID_Filiale",
										"nom_slug");

		$fields_ImpayesDetails = array(	"Annee",
										"Trimestre",
										"Metier",
										"ID_Offre",
										"Offre",
										"CodeImpaye",
										"LibelleMotifImpaye",
										"Nombre",
										"PourcentageNombre",
										"Montant",
										"PourcentageMontant");

		$fields_ImpayesOffre = array(	"Annee",
										"Trimestre",
										"ID_Metier",
										"Metier",
										"ID_Offre",
										"Offre",
										"Presentes",
										"Impayes",
										"Payes");

		$fields_ImpayesOperations=array("Annee",
										"Trimestre",
										"ID_Metier",
										"Metier",
										"ID_Offre",
										"Offre",
										"Operation",
										"Nombre",
										"PourcentageNombre",
										"Montant",
										"PourcentageMontant");

		$fields_ImpayesGeneral = array(	"Annee",
										"Trimestre",
										"ID_Metier",
										"Metier",
										"nom_slug",
										"Presentes",
										"Impayes",
										"Payes");

		$fields_RachatsPartiels = array("ID_Filiale",
										"CentreClientele",
										"NumeroContrat",
										"NumeroProposition",
										"LibelleLong",
										"DateEffetOperation",
										"CanalOperation",
										"MontantNetOperation",
										"MontantNetEuro",
										"MontantNetUC",
										"DateProductionCNP",
										"Delai",
										"Source");

		$fields_RachatsTotaux = array(	"ID_Filiale",
										"CentreClientele",
										"NumeroContrat",
										"NumeroProposition",
										"LibelleLong",
										"DateEffetOperation",
										"CanalOperation",
										"MontantNetOperation",
										"MontantNetEuro",
										"MontantNetUC",
										"DateProductionCNP",
										"Delai",
										"Source");

		$fields_IndicateursFiliales =array(	"ID_Filiale",
										"Filiale",
										"Annee",
										"Mois",
										"ChiffresAffaires",
										"CommissionsDeCourtage",
										"ParticipationAuxBenefices",
										"PrimesAcquises",
										"Sinistres",
										"CommissionsApporteurs",
										"Reassurance",
										"ResultatFinancier", 
										"ProduitNetAssurance",
										"ProduitNetBancaire",
										"CoutDuRisque",
										"ResultatExploitation",
										"ResultatNet",
										"ResultatNetParDuGroupe",
										"Charges",
										"ResultatBrutExploitation",
										"CoefficientExploitation",
										"Effectifs",
										"MeeDeCNP",
										"RatioSinistresSurPrimes",
										"RatioSsurPMoinsCumul",
										"Source");

	$fields_IndicateursProduits = array("Filiale",
										"Produit",
										"ID_Produit",
										"Mois",
										"Annee",
										"ChiffresAffaires",
										"AffairesNouvelles",
										"SortieDeContrats",
										"ProductionNette",
										"Portefeuille",
										"SinistreSurPrime",
										"Source");

	$fields_CanalSouscription = array(	"ID_Filiale",
										"Filiale",
										"Annee",
										"Mois",
										"CentresFinanciers",
										"Enseigne",
										"Telephone",
										"Internet",
										"Source");

	$fields_PerformanceRendement= array("ID_Filiale",
										"Filiale",
										"Annee",
										"Mois",
										"Indicateur",
										"Performance",
										"Rendement",
										"Benchmark",
										"PVLatentes",
										"Source",
										);
	$fields_CommissionementEnsemble= array("Annee",
											"Mois",
											"Assureur",
											"ProduitCodeProduit",
											"NbMouvementsCommissiones",
											"MtAssietteCommissionee",
											"CommissionVerseeParLaCNP",
											"CommissionCalculeeParLeCNAH",
											"EcartDeCommission"
								);

	$fields_EnCoursCNPParOffre= array(	"Annee",
										"Mois",
										"Domaine",
										"Offre",
										"LibelleOffre",
										"EncoursPOINTS",
										"EncoursEUROS",
										"EncoursUC",
										"EncoursTOTAL",
										"NbContrats",	
										"PartEURO",	
										"PartUC"
								);

	$fields_CommissionementCNP= array(      "Annee",
                                            "Mois",
                                            "Assureur",
                                            "CodeProduit",
                                            "CategorieProduit",
                                            "TypeMouvement",
                                            "NbMouvementsCommissionnes",
                                            "MtAssietteCommissionnee",
                                            "CommissionVerseeParLaCNP",
                                            "CommissionCalculeeParLeCNAH",
                                            "EcartDeCommission"
                                );
	$fields_EnCoursCNPParSupport= array("Annee",
										"Mois",
										"Support",
										"LibbelleSupport",
										"Encours"
								);

	$fields_IndicateursCNP = array(		"Annee",
										"Mois",
										"CA_Budget",
										"CA_Provisoire",
										"CA_Realise",
										"CA_Cumule",
										"CA_dont_UC",
										"CA_Pourc_dont_UC",
										"CA_dont_UC_cumule",
										"CA_Pourc_dont_UC_Cumule",
										"CA_dont_euros",
										"Encours",
										"SC_Budget",
										"SC_Provisoire",
										"SC_Realise",
										"SC_Cumule",
										"SC_dont_UC",
										"SC_Pourc_dont_UC",
										"SC_dont_UC_cumule",
										"SC_Pourc_dont_UC_Cumule",
										"SC_dont_euros",
										"CN_Realise",
										"CN_Cumule",
										"CN_dont_UC",
										"CN_Pourc_dont_UC",
										"CN_dont_UC_cumule",
										"CN_Pourc_dont_UC_Cumule",
										"PDM",
										"Ecart_PDM"
										);

	$fields_FreportingObsCA = array(
										"Annee",
										"Mois",
										"CUMUL",
										"Metier",
										"Part",
										"Offre",
										"AffairesNouvellesHorsPartages",
										"AffairesNouvellesPartages",
										"RedressAffairesNouvelles", 
										"RenonciationTousCanaux",
										"SansEffetSansSuiteHorsPartages",
										"TOTALAffairesNouvelles",
										"VersementLibreHorsPartages", 
										"VersementLibrePartages",
										"RedressVersementsLibres",
										"TOTALVersementsLibres",
										"VersementsReguliersHorsPartages",
										"RedressVersementsReguliersHorsPartages",
										"TOTALVersementsReguliers",
										"CABrutTOTAL",
										"dontUCTemp",
										"dontUCPerm"

								);
	$fields_FreportingObsSC = array(

										"Annee",
										"Mois",
										"CUMUL",
										"Metier",
										"Part",
										"Offre",
										"IPA_DC_HorsPartages",
										"IPA_DC_Partages",
										"TOTAL_IPA_DC",
										"ArriveesEcheanceHorsPartages",
										"ArriveesEcheancePartages",
										"TOTALArriveesEcheance",
										"RachatTotalHorsPartages",
										"RachatTotalPartages",
										"TOTALRachatsTotaux",
										"RachatPartielHorsPartages",
										"RachatPartielPartages",
										"Revenus",
										"TOTALRachatsPartiels",
										"TOTALSorties",
										"dontUCTemp",
										"dontUCPerm"
										);

	$fields_FreportingObsCN = array(	"Annee",
										"Mois",
										"CUMUL",
										"Metier",
										"Part",
										"Offre",
										"CollecteNette",
										"dontUCTemp",
										"dontUCPerm"
		);






	if     (preg_match('/IndicateursFiliales/',$value))	{ return $fields_IndicateursFiliales;}
	elseif (preg_match('/Filiales/',$value))		{ return $fields_ListeFiliales;}
	
	elseif (preg_match('/IndicateursProduits/',$value))	{ return $fields_IndicateursProduits;}
	elseif (preg_match('/IndicateursCNP/',$value))	{ return $fields_IndicateursCNP;}
	elseif (preg_match('/CommissionementEnsemble/',$value))	{ return $fields_CommissionementEnsemble;}
	elseif (preg_match('/CommissionementCNP/',$value)) { return $fields_CommissionementCNP;}
	elseif (preg_match('/FreportingObsCA/',$value)) { return $fields_FreportingObsCA;}
	elseif (preg_match('/FreportingObsSC/',$value)) { return $fields_FreportingObsSC;}
	elseif (preg_match('/FreportingObsCN/',$value)) { return $fields_FreportingObsCN;}
	elseif (preg_match('/CanalSouscription/',$value))	{ return $fields_CanalSouscription;}
	elseif (preg_match('/PerformanceRendement/',$value)){ return $fields_PerformanceRendement;}
	elseif (preg_match('/RachatsPartiels/',$value))		{ return $fields_RachatsPartiels;}
	elseif (preg_match('/RachatsTotaux/',$value))		{ return $fields_RachatsTotaux;}
	elseif (preg_match('/EnCoursCNPParOffre/',$value))	{ return $fields_EnCoursCNPParOffre;}
	elseif (preg_match('/ImpayesOffre/',$value))		{ return $fields_ImpayesOffre;		}
	elseif (preg_match('/ImpayesGeneral/',$value))		{ return $fields_ImpayesGeneral;		}
	elseif (preg_match('/ImpayesDetails/',$value))		{ return $fields_ImpayesDetails;		}
	elseif (preg_match('/ImpayesOperations/',$value))	{ return $fields_ImpayesOperations;}
	else{
		echo "Erreur de reconnaissance du nom du fichier : ".$value."<br>";
	}
}
function import_csv_to_sqlite(&$pdo, $csv_path, $options = array())
{

	extract($options);
	
	if (($csv_handle = fopen($csv_path, "r")) === FALSE)
		throw new Exception('Cannot open CSV file');
		
	if(!(isset($delimiter)))
		$delimiter = ',';
		
	if(!(isset($table)))
		$table = preg_replace("/[^A-Z0-9]/i", '', basename($csv_path));
	
	if(!(isset($fields))){
		$fields = array_map(function ($field){
			return strtolower(preg_replace("/[^A-Z0-9]/i", '', $field));
		}, fgetcsv($csv_handle, 0, $delimiter));
	}
	
	$create_fields_str = join(', ', array_map(function ($field){
		return "$field TEXT NULL";
	}, $fields));
	//echo $table."<br>";
	//var_dump($fields);
	$pdo->beginTransaction();
	
	$create_table_sql = "CREATE TABLE IF NOT EXISTS $table ($create_fields_str)";
	$pdo->exec($create_table_sql);
 

	$insert_fields_str = join(', ', $fields);
	$insert_values_str = join(', ', array_fill(0, count($fields),  '?'));
	$insert_sql = "INSERT INTO $table ($insert_fields_str) VALUES ($insert_values_str)";
	$insert_sth = $pdo->prepare($insert_sql);
	
	echo $insert_sql."<br>";
	
	$inserted_rows = 0;
	//var_dump(fgetcsv($csv_handle, 0, $delimiter));
	while (($data = fgetcsv($csv_handle, 0, $delimiter)) !== FALSE) {
	//var_dump( $data);
	//echo "<br><br>";
		$insert_sth->execute($data);
		$inserted_rows++;
	}//*/
	
	$pdo->commit();
	
	fclose($csv_handle);
	

	return array(
			'table' => $table,
			'fields' => $fields,
			'insert' => $insert_sth,
			'inserted_rows' => $inserted_rows
		);
 
} 


header('Location: ../index.php'); 
?>