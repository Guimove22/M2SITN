<div class="container arcad principal  "  >
		<div class ="row arcad-row" > 

	
	<?php 

		$metier;
		$annee;
		$trimestre;
		

		if(isset($_GET["metier"])){
			$metier=$_GET["metier"];
		}else{
			$metier="Epargne";
		}
		if(isset($_GET["annee"])){
			$annee=$_GET["annee"];
		}else{
			$annee=date("Y");
		}
		if(isset($_GET["trimestre"])){
			$trimestre=$_GET["trimestre"];
		}else{
			$trimestre=1;
		}

		afficherTitre("Impayés");

		afficherSelecteurMetierImpayes();
		afficherSelecteurAnneeImpayes(getAnneeImpayes());
		

		if(($metier=="Epargne")||($metier=="Prevoyance")){

			afficherSelecteurTrimestreImpayes($metier,$annee);


			if (isset($_GET["type"])){

				$type=$_GET["type"];

			

				
				if($type=="parOffre"){
					tableauImpayesParOffre($metier,$annee,$trimestre);
					echo '<hr>';
					tableauImpayesSurPrelevement($metier,$annee,$trimestre);
					echo '<hr>';
					
				}

				if($type=="parMotif"){
					tableauImpayesParMotif($metier,$annee,$trimestre);echo '<hr>';
					tableauDetailImpayesParOffre($metier,$annee,$trimestre);echo '<hr>';
				}

				
					
			}else{
				tableauImpayesParOffre($metier,$annee,$trimestre);echo '<hr>';
				tableauDetailImpayesParOffre($metier,$annee,$trimestre);echo '<hr>';

				tableauImpayesParMotif($metier,$annee,$trimestre);echo '<hr>';
				tableauImpayesSurPrelevement($metier,$annee,$trimestre);echo '<hr>';
			}
	
		}if($metier=="Partages"){

			

			afficherSelecteurTrimestreImpayes($metier,$annee);	
			
			tableauImpayesParmotifPartages($metier,$annee,$trimestre);
			tableauImpayesSurPrelevementPartages($metier,$annee,$trimestre);

		

		}
	?>





	</div>
</div>

