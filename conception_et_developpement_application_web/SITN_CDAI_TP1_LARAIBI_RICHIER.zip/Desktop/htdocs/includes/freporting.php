<div style="max-width:92%"class="container principal arcad "  >
	<div class ="row arcad-row">
	<?php
	if(isset($_GET["annee"])){
		$annee=$_GET["annee"];
	}else{
		$annee = date("Y");
	}
	if(isset($_GET["mois"])){
		$mois=$_GET["mois"];
	}else{
		
		$mois = date("m")-3;
		
	}
	if(isset($_GET["type"])){
		$type=$_GET["type"];
	}else{
		
		$type = "CA";
		
	}
	if(isset($_GET["metier"])){
		$metier=$_GET["metier"];
	}else{
		$metier = "EPARGNE";
	}
	if(isset($_GET["cumul"])){
		$cumul=$_GET["cumul"];
	}else{
		$cumul = 0;
	}
	
	SelecteurAnneeFReporting($cumul,$annee,$mois,$metier);
	SelecteurMoisFReporting($cumul,$annee,$mois,$metier);
	SelecteurMetierFReporting($cumul,$annee,$mois,$metier);
	SelecteurCumulReporting($cumul,$annee,$mois,$metier);

	if($type=="CA"){
			AfficherTableauFReportingCA($cumul,$annee,$mois,$metier);
			AfficherTableauFReportingCAVersements($cumul,$annee,$mois,$metier);

	}
	if($type=="SC"){
			AfficherTableauFReportingSC($cumul,$annee,$mois,$metier);
			AfficherTableauFReportingSCVersements($cumul,$annee,$mois,$metier);

	}
	if($type=="CN"){
			AfficherTableauFReportingCN($cumul,$annee,$mois,$metier);

	}
	
	?>


	</div>
</div>