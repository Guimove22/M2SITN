	
<div class='row'>
	<?php 
	

	echo '<div class="col-lg-4" style="margin-top:15px">';
	echo    '<form method="get" action="index.php" >'
            .'<input type="hidden" name="p" value="'.$_GET["p"].'">'
            
            .'<input type="hidden" name="mois" value="'.$mois.'">
              <input type="hidden" name="annee" value="'.$annee.'">
              <div class="btn-group "  role="toolbar">';
             
	foreach(Site::getListeFiliales() as $Filiale){
		//if ($Filiale->getNomSlug() !=$filiale)
		
				if(!strcmp($filiale,$Filiale->getNomSlug())){$info="info";}else{$info="default";}
				echo '<button type="submit" name="filiale" value="'.$Filiale->getNomSlug().'"class="btn  btn-'.$info.'"> '.$Filiale->getNom().'</button>';


	}
	
	echo '</div></form>';
	echo '</div>';
	?><?php
		//SELECTEUR ANNEE
		$req = "SELECT DISTINCT(annee) AS Annee FROM indicateursFiliales WHERE annee>2000 AND Filiale=:Filiale";
        $requete = $connexion->prepare($req);
        $requete->execute(array("Filiale"=>strtoupper($filiale)));
        $listeAnnee=array();
        while($tab = $requete->fetch()){
            
                $listeAnnee[]=$tab["Annee"];    
        }




			echo    '<div class="col-lg-8"><form method="get" action="index.php">'
            .'<input type="hidden" name="p" value="'.$_GET["p"].'">'
            .'<input type="hidden" name="filiale" value="'.$filiale.'">
            <div class="btn-group">';
            
 //           .'<input type="hidden" name="mois" value="'.$mois.'">';

            foreach ($listeAnnee as $cle => $valeur) {
           if($valeur==$annee){$class="info";}else{$class="default";}
            echo '<button type="submit" name="annee" class="btn btn-'.$class.'" value="'.$valeur.'"> '.$valeur.'</button>';
        }
        	echo '</div></form>';




        //SELECTEUR MOIS
        $req = "SELECT DISTINCT(mois) AS Mois FROM indicateursFiliales WHERE annee=:Annee AND Filiale=:Filiale";
        $requete = $connexion->prepare($req);
        $requete->execute(array("Annee"=>$annee,"Filiale"=>strtoupper($filiale) ));
        $listeMois=array();

        while($tab = $requete->fetch()){
            
                $listeMois[]=$tab["Mois"];    
        }

        


			echo    '<form method="get" action="index.php">'
            .'<input type="hidden" name="p" value="'.$_GET["p"].'">'
            .'<input type="hidden" name="filiale" value="'.$filiale.'">
            <div class="btn-group">'
            
            .'<input type="hidden" name="annee" value="'.$annee.'">';

            foreach ($listeMois as $cle => $valeur) {
            if($valeur==$mois){$class="info";}else{$class="default";}
            echo '<button type="submit" name="mois" class="btn btn-'.$class.'" value="'.$valeur.'">'.date_mois_mini($valeur).'</button>';
        }
        	echo '</div></form></div></div>';





	?>
