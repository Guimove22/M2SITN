<div class="col-lg-8" style="margin-top:180px">

<form action="/includes/importTableToSqLite.php" method="post">
	<input type="file" name="upload[]" multiple="multiple" />
	
	<input type="submit" value="OK">
</form>
</div>

