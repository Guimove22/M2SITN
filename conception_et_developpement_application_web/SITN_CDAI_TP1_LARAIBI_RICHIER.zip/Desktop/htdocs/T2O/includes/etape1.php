<h2>Step 1 : Fill up the form !</h2>
<form action="" method="post">
    <p>
        <input type="file" name="host" />
        <!--<input type="text" name="host" value="db473480801.db.1and1.com" />-->
        : Db host
    </p>
   <!-- <p>
        <input type="text" name="port" value="3306" />
        : Db port
    </p>
    <p>
        <input type="text" name="db_name" value="db473480801" />
        : Db name
    </p>
    <p>
        <input type="text" name="db_user" value="dbo473480801" />
        : Db user
    </p>
    <p>
        <input type="password" name="password" value="1F2Gr6U1AbeYHcU" />
        : Db password
    </p>-->
    <p>
    	<input type="submit" name="etape1" value="Next" />
    	<input type="submit" name="cancel" value="Cancel" />
    </p>
</form>