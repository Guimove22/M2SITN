<?php 
	//Fichier de configuration de connexion à la base de données SQLite
	include("config/connect.inc.php");

	//Chargement des classes
	function mesClasses($classe) {
		if(file_exists('includes/classes/' . $classe . '.class.php')) {require_once 'includes/classes/' . $classe . '.class.php'; }
		if(file_exists('includes/classes/extends/' . $classe . '.class.php')) {require_once 'includes/classes/extends/' . $classe . '.class.php'; }
	}
	spl_autoload_register('mesClasses');
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>BDD Risque et Assurance</title>
        <link rel="icon" type="image/png" href="/img/logo.png" />




		<!-- Dernière version CSS Bootstrap 
		<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css"><!---->

		<!--  version Locale CSS Bootstrap  -->
		<link rel="stylesheet" href="/css/bootstrap.css">
		<link rel="stylesheet" href="/media/css/jquery.dataTables.css">
		<link rel="stylesheet" href="/js/extensions/ColReorder/css/dataTables.colReorder.min.css">
		<link rel="stylesheet" href="/js/extensions/ColVis/css/dataTables.colVis.css">
		<link rel="stylesheet" href="/js/extensions/TableTools/css/dataTables.tableTools.css">
		<link rel="stylesheet" href="/js/extensions/KeyTable/css/dataTables.keyTable.css">


		<!-- Optional theme 
		<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap-theme.min.css"><!---->
		
		<!-- Optional theme  -->
		<!--<link rel="stylesheet" href="/css/bootstrap-theme.min.css"><!---->

		<!-- Latest compiled and minified JavaScript 
		<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script><!---->

		<!-- Latest compiled and minified JavaScript -->
		 <script src="/js/jquery-2.1.1.js"></script>
    <script language="javascript" type="text/javascript" src="/js/bootstrap.js"></script><!---->
    <!--<script language="javascript" type="text/javascript" src="/js/jquery.dataTables.js"></script><!---->

    <script type="text/javascript" language="javascript" src="/media/js/jquery.js"></script>
	<script type="text/javascript" language="javascript" src="/media/js/jquery.dataTables.js"></script>
	<script language="javascript" type="text/javascript" src="/js/extensions/ColReorder/js/dataTables.colReorder.min.js"></script><!---->
	<script language="javascript" type="text/javascript" src="/js/extensions/ColVis/js/dataTables.colVis.js"></script><!---->
	<script language="javascript" type="text/javascript" src="/js/extensions/TableTools/js/dataTables.tableTools.js"></script><!---->
	<script language="javascript" type="text/javascript" src="/js/extensions/KeyTable/js/dataTables.keyTable.js"></script><!---->
	<script src="/js/highcharts.js"></script>
	<script src="/js/exporting.js"></script>
		
		
	<!--    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>-->



    </head>

    <body>		
   			<?php
   			include './includes/fonctions.php';
   			include './includes/menu.php';
   			//include '/includes/sidebar.php';
   			//verificationBaseAJour();

   			 if (isset($_GET["p"])){
   				include './includes/'.$_GET["p"].'.php';
   			}
   			else{
   				include './includes/resumeFiliale.php';
   			}
   			 include './includes/footer.php';?>

    </body>

	<script type="text/javascript" language="javascript" class="init">


		$(document).ready(function() {
			$('#CommissionementCNP').dataTable({
				"lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "Tout"]],
				"dom": 'C<"clear">RTlfrtip',
				"language": {
			            "decimal": ",",
			            "thousands": " "
			        },
			        "scrollY":        "500px",
        "scrollCollapse": true,
        "paging":         false,
				colReorder: {
		            realtime: true
		        },
		        tableTools: {
		            "sSwfPath": "./js/extensions/TableTools/swf/copy_csv_xls_pdf.swf"
		        }
		        
			});
		} );
		$(document).ready(function() {
		    var table = $('#reportingParOffre').DataTable({
		        "columnDefs": [
		            { "visible": false, "targets": 0},
		            {
            targets: [ 0 ],
            orderData: [ 0, 1 ]
        }, {
            targets: [ 1 ],
            orderData: [ 1, 0 ]
        }, {
            targets: [ 2 ],
            orderData: [ 2, 0 ]
        }
		        ],
		        "order": [[ 0, 'asc' ]],
		        "displayLength": 40,
		        "ordering": true,
		        "scrollY":        "600px",
			        "scrollCollapse": true,
			        "paging":         false,
			        "language": {
			            "decimal": ",",
			            "thousands": " "
			        },
		        "drawCallback": function ( settings ) {
		            var api = this.api();
		            var rows = api.rows( {page:'current'} ).nodes();
		            var last=null;
		 
		            api.column(0, {page:'current'} ).data().each( function ( group, i ) {
		                if ( last !== group ) {
		                    $(rows).eq( i ).before(
		                        '<tr class="group warning"><td colspan="17">'+group+'</td></tr>'
		                    );
		 
		                    last = group;
		                }
		            } );
		        }
		    } );

		 
		    // Order by the grouping
		    $('#reportingParOffre tbody').on( 'click', 'tr.group', function () {
		        var currentOrder = table.order()[0];
		        if ( currentOrder[0] === 2 && currentOrder[1] === 'asc' ) {
		            table.order( [ 0, 'desc' ] ).draw();
		        }
		        else {
		            table.order( [ 0, 'asc' ] ).draw();
		        }
		    } );
		} );
		$(document).ready(function() {
		    var table = $('#reportingParOffreVersements').DataTable({
		        "columnDefs": [
		            { "visible": false, "targets": 0}
		        ],
		        "order": [[ 0, 'asc' ]],
		        "displayLength": 40,
		        "ordering": false,
		        "scrollY":        "600px",
			        "scrollCollapse": true,
			        "paging":         false,
			        "language": {
			            "decimal": ",",
			            "thousands": " "
			        },
		        "drawCallback": function ( settings ) {
		            var api = this.api();
		            var rows = api.rows( {page:'current'} ).nodes();
		            var last=null;
		 
		            api.column(0, {page:'current'} ).data().each( function ( group, i ) {
		                if ( last !== group ) {
		                    $(rows).eq( i ).before(
		                        '<tr class="group warning"><td colspan="17">'+group+'</td></tr>'
		                    );
		 
		                    last = group;
		                }
		            } );
		        }
		    } );
		    
		 
		    // Order by the grouping
		    $('#reportingParOffreVersements tbody').on( 'click', 'tr.group', function () {
		        var currentOrder = table.order()[0];
		        if ( currentOrder[0] === 2 && currentOrder[1] === 'asc' ) {
		            table.order( [ 0, 'desc' ] ).draw();
		        }
		        else {
		            table.order( [ 0, 'asc' ] ).draw();
		        }
		    } );
		} );
	
	
		$(document).ready(function() {
			$('#Rachatstotaux').dataTable({
				"dom": 'C<"clear">RTlfrtip',
				colReorder: {
		            realtime: true
		        },
		        tableTools: {
		            "sSwfPath": "./js/extensions/TableTools/swf/copy_csv_xls_pdf.swf"
		        },
		        "language": {
			            "decimal": ",",
			            "thousands": "."
			        }

			});
		} );

		$(document).ready(function() {
			$('#Rachatspartiels').dataTable({
				"dom": 'C<"clear">RTlfrtip',
				"language": {
			            "decimal": ",",
			            "thousands": "."
			        },
				colReorder: {
		            realtime: true
		        },
		        tableTools: {
		            "sSwfPath": "./js/extensions/TableTools/swf/copy_csv_xls_pdf.swf"
		        }

			});
		} );
		$(document).ready(function() {
			$('#EncoursParOffre').dataTable({
				 "scrollY":        "400px",
			        "scrollCollapse": true,
			        "paging":         false,
			        "language": {
			            "decimal": ",",
			            "thousands": "."
			        }
			});
		} );
		$(document).ready(function() {
			$('#EncoursParSupport').dataTable({
				 "scrollY":        "400px",
			        "scrollCollapse": true,
			        "paging":         false,
			        "language": {
			            "decimal": ",",
			            "thousands": "."
			        }
			});
		} );
		$(document).ready(function() {
			$('#EncoursParOffreGroupee').dataTable({
				 "scrollY":        "400px",
			        "scrollCollapse": true,
			        "paging":         false,
			        "language": {
			            "decimal": ",",
			            "thousands": "."
			        }
			});
		} );
		$(document).ready(function() {
			$('#resportingParOffre').dataTable({
				"scrollY": 200,
		        "scrollX": false
				 
			});
		} );
    
    /* Effet de transition entre les pages */
    /*$(document).ready(function() {
	            $("body").css("display", "none");
	            $("body").fadeIn(100);
	    });
	$(document).ready(function() {
	    $("body").css("display", "none");
	 
	    $("body").fadeIn(100);
	 
	    $("a.transition").click(function(event){
	        event.preventDefault();
	        linkLocation = this.href;
	        $("body").fadeOut(100, redirectPage);      
	    });
	         
	    function redirectPage() {
	        window.location = linkLocation;
	    }
	});/**/


   
	</script>
</html>
