<!DOCTYPE html>
<html lang="fr">
  

<?php

try {
  $dbh = new PDO('sqlite:D:\Documents and Settings\vytg315\Mes documents\sqlite\SQLBDD1');

  $sth = $dbh->prepare("SELECT * FROM Filiales");
   $sth->execute();

  
  
  while ($donnees = $sth->fetch(PDO::FETCH_ASSOC)){
  	?> Filiale : <?php echo $donnees["Description"] ?> <br><?php 
  }
  $dbh = null;//*/
}
catch(PDOException $e) {
  echo $e->getMessage();
}

?>


</html>
