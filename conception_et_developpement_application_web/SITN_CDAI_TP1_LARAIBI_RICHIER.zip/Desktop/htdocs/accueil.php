<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>BDD Risque et Assurance</title>




		<!-- Dernière version CSS Bootstrap 
		<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css"><!---->

		<!--  version Locale CSS Bootstrap  -->
		<link rel="stylesheet" href="/css/bootstrap.css">
		<!-- Optional theme 
		<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap-theme.min.css"><!---->
		
		<!-- Optional theme  -->
		<link rel="stylesheet" href="/css/bootstrap-theme.min.css"><!---->

		<!-- Latest compiled and minified JavaScript 
		<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script><!---->

		<!-- Latest compiled and minified JavaScript -->
		
		<script src="/js/jquery-2.1.1.js"></script>
	<!--    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>-->
<script language="javascript" type="text/javascript" src="/js/bootstrap.js"></script><!---->


    </head>

    <body>		
   			 
   			<?php
   			include '/includes/menu.php';

   			 if (isset($_GET["p"])){
   				include '/includes/'.$_GET["p"].'.php';
   			}
   			else{
   				include '/includes/home.php';
   			}

   			 include '/includes/footer.php';?>
    </body>
</html>