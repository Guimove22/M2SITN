<?php
//$host = "D:\Documents and Settings\vytg315\Mes documents\sqlite\QLTest";

	try{
		//$connexion = new PDO('sqlite:'.$host.'');
		//$connexion = new PDO('sqlite:D:\Documents and Settings\vytg315\Mes documents\sqlite\SQLTest');
		//$connexion = new PDO('sqlite:D:\Documents and Settings\vytg315\Mes documents\sqlite\SQL290714');
		//$connexion = new PDO('sqlite:D:\Documents and Settings\vytg315\Mes documents\sqlite\SQL290714');
		//$connexion = new PDO('sqlite:C:\xampp\BDD_SQLite\SQL290714');
		$connexion = new PDO('sqlite:./BDD_SQLite/SQL290714');
		//$connexion = new PDO('sqlite:O:\_ASSURANCE\_RISQUES_ASSURANCE\REPORTING & TDB\Données & Analyses\ARCAD\SQL290714');
		//$connexion = new PDO('sqlite:O:\_ASSURANCE\_RISQUES_ASSURANCE\ARCAD\Installation\BDD_SQLite\SQL290714');

		
		$connexion->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    	$connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
		
	}
	catch(PDOException $e){
		echo $e;
	}
?>